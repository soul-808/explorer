import { existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn, spawnSync } from "node:child_process";

export const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
export const serviceDir = path.join(root, "services", "comparer");
export const venvPython = path.join(serviceDir, ".venv", process.platform === "win32" ? "Scripts/python.exe" : "bin/python");
if (existsSync(path.join(root, ".env"))) process.loadEnvFile(path.join(root, ".env"));
// Both children run in subfolders. Resolve configured filesystem paths from the ZIP root.
for (const key of ["COMPARER_CONFIG", "COMPARER_DATA_DIR", "COMPARER_STORE_PATH", "COMPARER_INBOX", "COMPARER_ARTIFACT_DIR"]) {
  if (process.env[key] && !path.isAbsolute(process.env[key])) process.env[key] = path.resolve(root, process.env[key]);
}

export function findPython(useVenv = true) {
  const candidates = [process.env.COMPARER_PYTHON, useVenv && existsSync(venvPython) && venvPython, "python3", "python"];
  for (const candidate of candidates.filter(Boolean)) {
    const probe = spawnSync(candidate, ["-c", "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)"], { stdio: "ignore" });
    if (probe.status === 0) return candidate;
  }
  throw new Error("Python 3.10+ is required. Install Python and add it to PATH, or set COMPARER_PYTHON to its executable path.");
}
export function run(command, args, cwd = serviceDir) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd, stdio: "inherit", env: process.env });
    child.on("error", reject);
    child.on("exit", (code, signal) => resolve(code ?? (signal ? 1 : 0)));
  });
}
async function main() {
  const [action = "health", profile = "common"] = process.argv.slice(2);
  if (action === "install") {
    if (!["common", "advanced"].includes(profile)) throw new Error("Use install common or install advanced.");
    if (!existsSync(venvPython)) {
      const code = await run(findPython(false), ["-m", "venv", path.join(serviceDir, ".venv")]);
      if (code) return code;
    }
    if (spawnSync(venvPython, ["-m", "pip", "--version"], { stdio: "ignore" }).status !== 0) {
      const code = await run(venvPython, ["-m", "ensurepip", "--upgrade"]);
      if (code) return code;
    }
    const extra = profile === "common" ? ".[recommended,ssim]" : ".[all]";
    console.log(`Installing the ${profile} optional comparison packages into services/comparer/.venv.`);
    return run(venvPython, ["-m", "pip", "install", "-e", extra]);
  }
  const python = findPython();
  if (action === "package") return run(python, [path.join(root, "scripts", "package.py")], root);
  if (action === "test") return run(python, ["-m", "unittest", "discover", "-s", "tests", "-v"]);
  if (!["serve", "health"].includes(action)) throw new Error(`Unknown action: ${action}`);
  return run(python, ["-m", "comparer", action]);
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().then(code => { process.exitCode = code; }).catch(error => { console.error(error.message); process.exitCode = 1; });
}
