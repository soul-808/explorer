import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const samples = path.join(root, "apps/web/public/samples");
const base = process.env.SMOKE_URL || "http://127.0.0.1:3100";
const checks = [];
async function check(name, fn) { await fn(); checks.push(name); console.log(`PASS ${name}`); }
async function compare(source, target, options = { engines: ["text"] }) {
  const body = new FormData();
  body.append("source", new Blob([await readFile(path.join(samples, source))]), source);
  body.append("target", new Blob([await readFile(path.join(samples, target))]), target);
  body.append("options", JSON.stringify(options));
  const response = await fetch(`${base}/api/compare`, { method: "POST", headers: { origin: new URL(base).origin }, body, signal: AbortSignal.timeout(180000) });
  const result = await response.json();
  assert.equal(response.status, 200, JSON.stringify(result));
  assert.ok(result.id && result.verdict && Array.isArray(result.findings));
  for (const f of result.findings) {
    for (const side of ["source", "target"]) {
      if (f[side]?.bbox) {
        const [x, y, w, h] = f[side].bbox;
        assert.ok([x,y,w,h].every(Number.isFinite));
        assert.ok(x >= 0 && y >= 0 && w > 0 && h > 0 && x + w <= 1.001 && y + h <= 1.001, `Invalid box in ${f.id}`);
      }
    }
  }
  return result;
}
const healthResponse = await fetch(`${base}/api/health`);
assert.equal(healthResponse.status, 200, "Start both services first with npm run dev.");
const health = await healthResponse.json();
const available = name => health.engines.some(e => e.name === name && e.status === "ok");

await check("identical TXT comparison", async () => {
  const r = await compare("approved-copy.txt", "approved-copy.txt");
  assert.equal(r.verdict.status, "match"); assert.equal(r.findings.length, 0);
});
await check("DOCX to DOCX differences", async () => {
  const r = await compare("approved-copy.docx", "produced-copy.docx");
  assert.equal(r.verdict.status, "mismatch");
  assert.ok(r.findings.some(f => f.message.includes("4.25")));
});
await check("DOCX to TXT equivalent copy", async () => {
  const r = await compare("approved-copy.docx", "approved-copy.txt");
  assert.equal(r.verdict.status, "match");
});
await check("no selected engine is inconclusive", async () => {
  const r = await compare("approved-copy.txt", "produced-copy.txt", { engines: [] });
  assert.equal(r.verdict.status, "inconclusive");
});
await check("rules preserve base findings and explain allowed CTA", async () => {
  const r = await compare("approved-copy.txt", "produced-copy.txt", { engines: ["text"], rules: [
    { id: "disclosure", type: "required_text", name: "Required disclosure", value: "APY is variable and may change. Terms and conditions apply.", compliance: true },
    { id: "cta", type: "allowed_change", name: "Approved app CTA", from: "Open an account", to: "Start saving" },
  ] });
  assert.equal(r.base_verdict.status, "mismatch");
  assert.equal(r.verdict.status, "mismatch");
  assert.ok(r.findings.some(f => f.disposition === "ignored" && f.rule_matches.some(m => m.rule_id === "cta")));
  assert.ok(r.findings.some(f => f.category === "rule_violation" && f.rule_matches.some(m => m.compliance)));
  assert.ok(r.base_findings.every(f => f.category !== "rule_violation"));
  assert.ok(r.source.pages[0].text.includes("4.25"));
});
await check("free-form guidance is explicitly unevaluated without vision", async () => {
  const r = await compare("approved-copy.txt", "produced-copy.txt", { engines: ["text"], rule_guidance: "Ignore the CTA change." });
  assert.equal(r.rules_report.guidance.status, "unevaluated");
  assert.ok(r.findings.every(f => f.disposition !== "ignored"));
});
if (available("pixel")) {
  await check("image to image and downloadable annotations", async () => {
    const r = await compare("approved-design.png", "produced-screen.png", { engines: ["pixel"] });
    assert.equal(r.verdict.status, "mismatch");
    assert.ok(r.findings.some(f => f.target?.bbox));
    const response = await fetch(`${base}${r.overlays.target[0].image_url}`);
    assert.equal(response.status, 200);
    assert.equal(response.headers.get("content-type"), "image/png");
    assert.ok((await response.arrayBuffer()).byteLength > 100);
  });
  await check("identical image comparison", async () => {
    const r = await compare("approved-design.png", "approved-design.png", { engines: ["pixel"] });
    assert.equal(r.verdict.status, "match");
  });
}
if (available("ocr")) {
  for (const [source, target] of [["approved-copy.docx", "produced-screen.png"], ["approved-design.png", "produced-copy.docx"]]) {
    await check(`${source.endsWith("docx") ? "document to image" : "image to document"} with OCR`, async () => {
      const r = await compare(source, target, { engines: ["ocr", "text"] });
      assert.equal(r.verdict.status, "mismatch");
      const nativeRate = source.endsWith("docx") ? "4.25" : "4.75";
      assert.ok(r.findings.some(f => f.category === "text_changed" && f.message.includes(nativeRate)), "The changed rate must be flagged even if OCR tokenizes the image differently.");
      assert.ok(r.findings.some(f => f.source?.bbox || f.target?.bbox));
    });
  }
}
await check("proxy rejects foreign-origin writes", async () => {
  const response = await fetch(`${base}/api/compare`, { method: "POST", headers: { origin: "https://unrelated.example", "content-type": "application/json" }, body: "{}" });
  assert.equal(response.status, 403);
});
await check("proxy preserves scheme and port boundaries", async () => {
  const url = new URL(base);
  const wrongScheme = new URL(url.origin); wrongScheme.protocol = url.protocol === "http:" ? "https:" : "http:";
  const wrongPort = new URL(url.origin); wrongPort.port = url.port === "9999" ? "9998" : "9999";
  for (const origin of [wrongScheme.origin, wrongPort.origin, "null", "https://unrelated.example"]) {
    const response = await fetch(`${base}/api/compare`, { method: "POST", headers: { origin, "sec-fetch-site": "same-origin", "content-type": "application/json" }, body: "{}" });
    assert.equal(response.status, 403, `Must reject ${origin} even with a misleading fetch-site header.`);
  }
});
await check("proxy rejects unexpected routes", async () => {
  const response = await fetch(`${base}/api/private-config`);
  assert.equal(response.status, 404);
});
console.log(`\n${checks.length} integration checks passed through ${base}. No external model called.`);
