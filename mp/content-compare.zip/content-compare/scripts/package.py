"""Create a portable source ZIP from an explicit list of distributable paths."""
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIRECTORIES = ["apps/web/src", "apps/web/public", "services/comparer/comparer", "services/comparer/tests", "scripts", "docs", "examples"]
FILES = ["README.md", "package.json", "package-lock.json", ".env.example", ".gitignore", "AGENTS.md", "CLAUDE.md", ".agent-bus.README.md", "apps/web/package.json", "apps/web/tsconfig.json", "apps/web/next-env.d.ts", "apps/web/next.config.ts", "services/comparer/pyproject.toml", "services/comparer/README.md", "services/comparer/API.md", "creative-proofing-primer.pdf"]
FILES += ["config/organization.example.json", "services/comparer/AUTOMATION_API.md", "services/comparer/.gitignore", "apps/web/AGENTS.md", "apps/web/CLAUDE.md"]
EXCLUDED = {"__pycache__", "node_modules", ".next", ".venv", ".artifacts", ".data", ".git", ".pytest_cache"}

def distributable_paths():
    paths = {ROOT / name for name in FILES if (ROOT / name).is_file()}
    for directory in DIRECTORIES:
        paths.update(p for p in (ROOT / directory).rglob("*") if p.is_file())
    for p in sorted(paths):
        rel = p.relative_to(ROOT)
        if p.is_symlink() or any(part in EXCLUDED for part in rel.parts) or any(part.startswith(".") for part in rel.parts[:-1]):
            continue
        if p.name.startswith(".env") and p.name != ".env.example":
            continue
        if p.suffix in (".pyc", ".pyo") or p.name == ".DS_Store" or any(part.endswith(".egg-info") for part in rel.parts):
            continue
        yield p

def main():
    output = ROOT / "dist" / "content-compare.zip"
    output.parent.mkdir(exist_ok=True)
    count = 0
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        for p in distributable_paths():
            rel = p.relative_to(ROOT)
            archive.write(p, Path("content-compare") / rel)
            count += 1
    with zipfile.ZipFile(output) as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"ZIP verification failed: {bad}")
    print(f"Created {output} ({count} files, {output.stat().st_size / 1024 / 1024:.2f} MB).")
    print("Source, lockfile, samples, and instructions only; credentials, uploads, Git history, and installed dependencies excluded.")

if __name__ == "__main__":
    main()
