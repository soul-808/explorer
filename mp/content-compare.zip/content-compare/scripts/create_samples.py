"""Generate fictional marketing fixtures. Pillow is optional at runtime, needed only here."""
from pathlib import Path
from xml.sax.saxutils import escape
import io
import zipfile
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "apps" / "web" / "public" / "samples"
APPROVED = ["WILLOW", "Personal banking", "Savings, with a little", "more possibility.", "Make your next chapter a little brighter.", "4.25%", "ANNUAL PERCENTAGE YIELD", "A better place for your everyday savings.", "No monthly fees. No minimum balance.", "Open an account", "Offer ends June 30, 2026.", "APY is variable and may change. Terms and conditions apply.", "Fictional sample. For demonstration only."]
PRODUCED = [line.replace("4.25%", "4.75%").replace("Open an account", "Start saving") for line in APPROVED if not line.startswith("APY is variable")]

def font(size):
    return ImageFont.load_default(size=size)

def card(target=False):
    im = Image.new("RGB", (1000, 740), "#ffffff")
    d = ImageDraw.Draw(im)
    d.rectangle((0, 0, 1000, 84), fill="#fafbf7")
    d.line((0, 84, 1000, 84), fill="#e4e8df", width=1)
    d.text((54, 26), "WILLOW", font=font(26), fill="#31553f")
    d.text((737, 32), "Personal banking", font=font(17), fill="#75826a")
    d.rounded_rectangle((46, 118, 954, 600), radius=12, fill="#f0f4e9")
    d.text((89, 155), "Savings, with a little", font=font(40), fill="#2a4b38")
    d.text((89, 204), "more possibility.", font=font(40), fill="#2a4b38")
    d.text((90, 267), "Make your next chapter a little brighter.", font=font(19), fill="#6e8063")
    d.text((88, 321), "4.75%" if target else "4.25%", font=font(79), fill="#315940")
    d.text((94, 418), "ANNUAL PERCENTAGE YIELD", font=font(12), fill="#829473")
    d.text((537, 345), "A better place for your", font=font(18), fill="#617756")
    d.text((537, 371), "everyday savings.", font=font(18), fill="#617756")
    d.text((537, 413), "No monthly fees.", font=font(17), fill="#849778")
    d.text((537, 438), "No minimum balance.", font=font(17), fill="#849778")
    d.rounded_rectangle((91, 490, 336, 548), radius=6, fill="#315940")
    d.text((118, 508), "Start saving" if target else "Open an account", font=font(20), fill="#ffffff")
    d.text((361, 512), "Offer ends June 30, 2026.", font=font(15), fill="#7d9070")
    if not target:
        d.text((54, 637), "APY is variable and may change. Terms and conditions apply.", font=font(16), fill="#7c8970")
    d.text((54, 695), "Fictional sample. For demonstration only.", font=font(13), fill="#98a18f")
    return im

def docx(lines):
    paragraphs = "".join(f'<w:p><w:r><w:t xml:space="preserve">{escape(line)}</w:t></w:r></w:p>' for line in lines)
    document = f'<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>{paragraphs}</w:body></w:document>'
    content_types = '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>'
    relationships = '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("word/document.xml", document)
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", relationships)
    return out.getvalue()

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    card().save(OUT / "approved-design.png")
    card(True).save(OUT / "produced-screen.png")
    (OUT / "approved-copy.docx").write_bytes(docx(APPROVED))
    (OUT / "produced-copy.docx").write_bytes(docx(PRODUCED))
    (OUT / "approved-copy.txt").write_text("\n".join(APPROVED), encoding="utf-8")
    (OUT / "produced-copy.txt").write_text("\n".join(PRODUCED), encoding="utf-8")
    print("Wrote fictional sample assets to", OUT)

if __name__ == "__main__":
    main()
