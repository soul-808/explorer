/** Live checks. Writes labelled synthetic runs/feedback to the selected service. */
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";

const base = (process.env.SMOKE_URL || "http://127.0.0.1:3100").replace(/\/$/, "");
const key = `smoke-${randomUUID()}`;
let checks = 0;
function check(label, fn) { fn(); console.log(`✓ ${label}`); checks++; }
async function request(route, body, method) {
  const response = await fetch(`${base}/api/${route}`, {
    method: method || (body ? "POST" : "GET"),
    headers: { origin: new URL(base).origin, ...(body ? { "content-type": "application/json" } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(60000),
  });
  const data = await response.json();
  assert.ok(response.ok, `${route}: ${response.status} ${JSON.stringify(data)}`);
  return data;
}
const payload = { source: { name: "approved.txt", content_base64: Buffer.from("Save 20%. Terms apply.").toString("base64") }, target: { name: "produced.txt", content_base64: Buffer.from("Save 25%.").toString("base64") }, options: { engines: ["text"], rule_guidance: "Test guidance with model disabled" }, labels: { suite: "automation-smoke", build: key }, idempotency_key: key };
const config = await request("config");
check("Public configuration is available without secret fields", () => { assert.ok(config.brand.name); assert.ok(config.store.kind); assert.ok(!Object.keys(config).includes("token")); });
const [a, b] = await Promise.all([request("jobs", payload), request("jobs", payload)]);
check("Concurrent duplicate submissions return one job", () => assert.equal(a.job.id, b.job.id));
let job;
const deadline = Date.now() + 60000;
do {
  job = await request(`jobs/${a.job.id}`);
  if (["done", "failed", "cancelled"].includes(job.status)) break;
  await new Promise(resolve => setTimeout(resolve, 250));
} while (Date.now() < deadline);
check("Background job finishes and links to a saved run", () => { assert.equal(job.status, "done", JSON.stringify(job)); assert.ok(job.run_id); });
const run = await request(`runs/${job.run_id}`);
check("History preserves inputs, options, labels, and evidence", () => { assert.equal(run.origin, "job"); assert.equal(run.labels.build, key); assert.equal(run.result.verdict.status, "mismatch"); assert.ok(run.result.findings.length); assert.equal(run.result.run_id, run.id); assert.deepEqual(run.options.engines, ["text"]); });
check("Guidance respects disabled model selection", () => assert.notEqual(run.result.rules_report?.guidance.status, "evaluated"));
const history = await request("runs?limit=1&origin=job&status=mismatch");
check("Proxy preserves history query filters", () => { assert.equal(history.runs.length, 1); assert.equal(history.runs[0].origin, "job"); assert.equal(history.runs[0].verdict.status, "mismatch"); });
const matching = await request("runs?origin=job&status=match");
check("Verdict filter excludes mismatching run", () => assert.ok(!matching.runs.some(r => r.id === run.id)));
const finding = run.result.findings[0];
const feedback = await request(`runs/${run.id}/feedback`, { finding_id: finding.id, verdict: "acceptable_difference", comment: "Synthetic smoke review: intentional campaign change.", reviewer: "Automated smoke fixture" });
const reopened = await request(`runs/${run.id}`);
check("Feedback survives reopening and retains finding evidence", () => { assert.ok(reopened.feedback.some(f => f.id === feedback.id)); assert.ok(reopened.feedback_count > 0); });
const exportResponse = await fetch(`${base}/api/feedback/export?format=jsonl`);
assert.ok(exportResponse.ok);
const rows = (await exportResponse.text()).trim().split("\n").filter(Boolean).map(JSON.parse);
const row = rows.find(r => r.feedback_id === feedback.id);
check("Dataset export includes provenance and content hashes", () => { assert.ok(row); assert.equal(row.finding.id, finding.id); assert.ok(row.provenance.source_sha256); assert.deepEqual(row.provenance.options.engines, ["text"]); });
const manual = await request("compare", { ...payload, options: { engines: ["text"], labels: { suite: "automation-smoke", build: key } } });
check("Manual comparisons also persist", () => assert.ok(manual.run_id));
const scratch = await request("compare", { ...payload, options: { engines: ["text"], persist: false } });
check("Scratch comparison can opt out of persistence", () => assert.ok(!scratch.run_id));
const cleanup = await request("automation/cleanup?dry_run=1", undefined, "POST");
check("Cleanup preview reports policy removals without applying them", () => { assert.equal(cleanup.dry_run, true); assert.ok(Array.isArray(cleanup.runs_pruned)); });
const denied = await fetch(`${base}/api/jobs`, { method: "POST", headers: { origin: "https://unrelated.example", "content-type": "application/json", "sec-fetch-site": "same-origin" }, body: JSON.stringify(payload) });
check("Automation submissions preserve browser origin protection", () => assert.equal(denied.status, 403));
console.log(`\n${checks} automation checks passed. Synthetic review: ${base}/?run=${run.id}`);
