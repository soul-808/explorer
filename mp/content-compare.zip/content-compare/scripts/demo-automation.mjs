/** Submit synthetic fixtures, or publish a folder manifest atomically. */
import { copyFile, mkdir, readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { root } from "./python.mjs"; // loads optional root .env
import { CompareClient } from "../examples/submit-job.mjs";

const batch = `demo-${Date.now()}-${randomUUID().slice(0, 8)}`;
const samples = path.join(root, "apps/web/public/samples");
const sourcePath = path.join(samples, "approved-design.png");
const targetPath = path.join(samples, "produced-screen.png");
const options = { engines: ["text", "ocr", "pixel"], render_overlays: true };
const labels = { suite: "sample-campaign", build: batch, producer: "demo" };
try {
  if (process.argv.includes("--inbox")) {
    let inbox = process.env.COMPARER_INBOX;
    if (!inbox && process.env.COMPARER_CONFIG) {
      const config = JSON.parse(await readFile(process.env.COMPARER_CONFIG, "utf8"));
      inbox = config.inbox;
      if (inbox && !path.isAbsolute(inbox)) throw new Error("Use an absolute inbox path in your organization config.");
    }
    if (!inbox) throw new Error("Set COMPARER_INBOX to an absolute folder in .env, restart npm run dev, then rerun with --inbox.");
    const pairDir = path.join(inbox, batch);
    await mkdir(pairDir, { recursive: true });
    await copyFile(sourcePath, path.join(pairDir, "approved.png"));
    await copyFile(targetPath, path.join(pairDir, "actual.png"));
    const manifest = { batch, idempotency_prefix: batch, pairs: [{ source: `${batch}/approved.png`, target: `${batch}/actual.png`, options, labels }] };
    const temporary = path.join(inbox, `${batch}.pending`);
    await writeFile(temporary, JSON.stringify(manifest, null, 2), { flag: "wx" });
    await rename(temporary, path.join(inbox, `${batch}.json`));
    console.log(`Published one manifest in ${inbox}. The service will pick it up at the next scan.\nOpen Connections to follow it, then History to review.`);
  } else {
    const client = new CompareClient({ baseUrl: process.env.COMPARER_URL || `http://127.0.0.1:${process.env.COMPARER_PORT || "8765"}`, token: process.env.COMPARER_TOKEN });
    const submitted = await client.submit({ sourcePath, targetPath, options, labels, idempotencyKey: batch });
    console.log(`Queued ${submitted.job.id}. Watching for a result…`);
    const job = await client.wait(submitted.job.id);
    if (job.status !== "done") throw new Error(`${job.status}: ${job.error || job.id}`);
    console.log(`Review: http://127.0.0.1:${process.env.WEB_PORT || "3100"}/?run=${job.run_id}\nThe result is also available in History.`);
  }
} catch (e) { console.error(e.message); process.exitCode = 1; }
