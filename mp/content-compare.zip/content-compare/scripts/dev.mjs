import { spawn } from "node:child_process";
import { createRequire } from "node:module";
import path from "node:path";
import { findPython, root, serviceDir } from "./python.mjs";

const require = createRequire(import.meta.url);
process.env.COMPARER_URL ||= `http://127.0.0.1:${process.env.COMPARER_PORT || "8765"}`;
const production = process.argv.includes("--production");
const webOnly = process.argv.includes("--web-only");
let stopping = false;
const children = [];
function stop(code = 0) {
  if (stopping) return;
  stopping = true; process.exitCode = code;
  for (const child of children) {
    if (child.exitCode !== null) continue;
    try {
      if (process.platform !== "win32") process.kill(-child.pid, "SIGTERM");
      else child.kill("SIGTERM");
    } catch { /* already exited */ }
  }
}
function start(command, args, cwd) {
  const child = spawn(command, args, { cwd, stdio: "inherit", env: process.env, detached: process.platform !== "win32" });
  children.push(child);
  child.on("error", error => { console.error(error.message); stop(1); });
  child.on("exit", code => { if (!stopping) stop(code ?? 1); });
}
try {
  const next = require.resolve("next/dist/bin/next");
  console.log(`Content Compare · http://127.0.0.1:${process.env.WEB_PORT || "3100"}\nCtrl+C stops ${webOnly ? "the local web service" : "both local services"}.`);
  if (!webOnly) start(findPython(), ["-m", "comparer", "serve", "--host", "127.0.0.1", "--port", process.env.COMPARER_PORT || "8765"], serviceDir);
  else console.log(`Web-only mode · comparer endpoint ${process.env.COMPARER_URL}`);
  start(process.execPath, [next, production ? "start" : "dev", "--hostname", "127.0.0.1", "--port", process.env.WEB_PORT || "3100"], path.join(root, "apps", "web"));
} catch (error) { console.error(error.message); stop(1); }
process.on("SIGINT", () => stop(0));
process.on("SIGTERM", () => stop(0));
