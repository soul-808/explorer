# Content Compare

A local workbench for checking approved marketing content against what was produced. Upload two images, documents, or one of each; inspect numbered differences on paired previews; then apply the rules for that piece of content.

**Next.js interface + Python comparison service, in one monorepo.** No separate database server, account, cloud deployment, or model API key is required. SQLite saves runs locally by default. Optional comparison packages are detected at runtime. Missing or failed methods are reported; a run without usable comparison evidence is inconclusive.

## Handing this to another team

Start with **[the handoff guide](docs/HANDOFF.md)**: installation, a first review, organization decisions, and a recipient acceptance checklist.

| Need | Guide |
|---|---|
| Use the tool and give useful feedback | [Reviewer guide](docs/REVIEWER_GUIDE.md) |
| Run it, back up data, manage cleanup, or fix an error | [Operations and troubleshooting](docs/OPERATIONS.md) |
| Understand the system and code visually | [Interactive architecture map](docs/ARCHITECTURE.html) — open directly in a browser |
| Customize branding, connect a test runner, or add adapters | [Integrations](docs/INTEGRATIONS.md) |
| Choose libraries, private repositories, or models | [Enterprise library options](docs/ENGINE_OPTIONS.md) · [Provider setup](docs/PROVIDERS.md) |
| Check what was tested and what remains | [Validation record](docs/VALIDATION.md) |

## Run it

Install **Node.js 22+** and **Python 3.10+**, unzip the project, and open a terminal in the `content-compare` folder.

```sh
npm ci
npm run setup:python
npm run dev
```

Open **http://127.0.0.1:3100**. The Python service uses **127.0.0.1:8765**. Ctrl+C stops both services. The commands work in macOS/Linux terminals and Windows PowerShell when Node and Python are on PATH.

`setup:python` creates `services/comparer/.venv` and installs the common optional packages: Pillow, pypdfium2, pypdf, pytesseract, NumPy, and scikit-image. **Tesseract is a separate executable** needed by the default OCR adapter:

- macOS: `brew install tesseract`
- Debian/Ubuntu: `sudo apt install tesseract-ocr`
- Windows: use your organization's approved Tesseract distribution, add it to PATH, and verify `tesseract --version`.

If Tesseract is absent, image pixel/structure comparison still works. Cross-format copy checks need an OCR engine or a configured vision model. To use an ONNX OCR backend instead, see [engine options](docs/ENGINE_OPTIONS.md).

For the **Python standard-library-only** mode, skip `setup:python`. TXT/DOCX parsing, text comparison, structured rules, and model HTTP adapters need no third-party Python package. Images can be forwarded to a configured vision model without Pillow. PDF support depends on optional PDF packages or system Poppler tools.

## Try the included examples

1. Choose **Try an example** to load the fictional approved design and produced screen.
2. Choose **Compare files**. The sample changes the rate from 4.25% to 4.75%, changes the CTA, and removes a disclosure. OCR and visual methods can report additional rendering or recognition differences.
3. Open **Add rules**, then **Try the sample's rules**. The disclosure is required and the app's CTA wording is allowed.
4. Compare again. Switch between **Base comparison** and **After rules**. The **Ignored** filter retains the original findings and the rule that suppressed them.

The arrow beside the example button loads **DOCX vs. screenshot**. Additional DOCX/TXT files are in `apps/web/public/samples/` for document-to-document and reversed comparisons. These are synthetic test assets, not financial products or advice.

## What the interface does

- Two file uploads: PNG/JPEG/WebP/GIF/BMP/TIFF, PDF, DOCX, TXT, or Markdown. UI cap: **10 MB per file**.
- Side-by-side previews, zoom, per-document page navigation, image overlay, and numbered color-coded boxes.
- A linked finding list with changed/missing/extra copy, visual differences, search, priority, review checkmarks, and per-method status.
- Per-comparison rule sets: required text, forbidden text, allowed wording changes, visual ignore regions, compliance labels, and optional free-form expert guidance.
- Import/export rule sets as JSON. Export comparison evidence and review checkmarks as JSON, or download the current page's annotated PNG when rendering is available.
- Original comparison findings remain separate from the rule-filtered result. Rule explanations are visible. No final approval or wider review workflow is implied.

## History, automation, and feedback

Every completed manual comparison is saved in **History**. Reopen it to inspect the same evidence and add **reviewer feedback**: correct findings, false positives, acceptable differences, missed issues, or priority corrections. Export the dataset from History as JSONL, including original findings, model/engine provenance, rules, content hashes, and reviewer notes. Feedback does not change old findings or train a model automatically.

To test the optional background workflow while the app is running:

```sh
npm run demo:automation
```

**Connections** shows the job queue and intake status; completed jobs appear in History. Any testing framework can use the included Node/Python clients to submit files over HTTP. Alternatively, set `COMPARER_INBOX=inbox` in `.env`, restart, then run `npm run demo:automation -- --inbox` to try automatic folder intake.

For your organization, copy `config/organization.example.json` to `config/organization.json`, set `COMPARER_CONFIG=config/organization.json` in `.env`, and restart. Change the name, accent, and local logo; use CSS for a deeper restyle. SQLite and JSON-file stores ship with the app; other databases, sources, and model gateways have explicit adapter interfaces.

See [the integration and white-label guide](docs/INTEGRATIONS.md) for producer examples, configuration, database boundaries, and a practical feedback workflow.

## Configure a vision model

Copy `.env.example` to `.env` in the repo root, set the provider and an exact model available to you, then restart `npm run dev`. Enable **Vision model** under **Comparison methods** when you want files sent to that provider.

```dotenv
COMPARER_VISION_PROVIDER=gemini
COMPARER_VISION_MODEL=your-supported-vision-model
GEMINI_API_KEY=your-key
```

Adapters support Gemini, OpenAI-compatible endpoints (including local servers), native Ollama, and Anthropic. A model is deliberately not selected for you. For local inference, use a model that accepts images; a text-only Llama model cannot inspect a screenshot. See [provider setup](docs/PROVIDERS.md).

Provider URLs and credentials are server configuration, never browser input. Free-form expert guidance requires a separate model rules review; if it cannot run, the UI says **not evaluated** and preserves the findings. Structured rules work locally.

## Useful commands

| Command | Purpose |
|---|---|
| `npm run doctor` | Print available comparison engines |
| `npm run dev` | Start both local services |
| `npm run dev:web` / `npm run dev:api` | Start either service independently; web-only mode reads the root `.env` |
| `npm run start:web` | Run the built UI against an existing API, without starting Python |
| `npm run setup:python` | Install the common optional Python packages |
| `npm run setup:advanced` | Install the broader evaluation profile, including ONNX OCR |
| `npm run typecheck` | Check the TypeScript interface |
| `npm test` | Run the Python regression suite |
| `npm run demo:automation` | Submit a synthetic screenshot job (or add `-- --inbox`) |
| `npm run test:automation` | Test background jobs, history, feedback, and origin protection |
| `npm run test:smoke` | Check real uploads and responses through the running UI proxy |
| `npm run build` / `npm start` | Build the interface, then run both services in production mode |
| `npm run package:zip` | Create `dist/content-compare.zip` |

The ZIP includes source, lockfile, sample files, and instructions. It excludes installed dependencies, Git history, `.env`, organization-specific config, saved runs/feedback, comparison artifacts, and agent messages. Recipients install their own dependencies; it is not an offline executable bundle.

## Monorepo layout

Open [the interactive architecture guide](docs/ARCHITECTURE.html) for diagrams of the workflow, runtime, code/modules, UI components, and tooling. It is a single offline HTML file with a searchable source tree and clickable explanations.

```text
apps/web/             Next.js App Router interface and same-origin API proxy
services/comparer/    Standard-library Python server, loaders, engine adapters, rules, tests
scripts/              Cross-platform launch/setup, sample generation, smoke checks, ZIP packaging
docs/                 Architecture guide, integration, engine research, providers, rules, validation
examples/             Framework-neutral Node/Python job clients and a sample intake manifest
config/               Organization branding example (your real config stays local)
```

The source primer provides background for this slice; the app implements comparison, rules, intake, history, and feedback, rather than the primer's wider compliance, approval, destination-crawling, or record-management landscape.

## Current boundaries

- OCR and model observations are fallible. Confidence values are heuristics, not calibrated probabilities. Extra engines can add coverage and also false positives.
- Text comparison normalizes spacing/line breaks and typographic quotes/dashes. Capitalization and punctuation checks can be configured. DOCX is shown as extracted copy rather than a Word-perfect rendering; legacy `.doc` is not supported.
- PDF processing defaults to the first **10 pages**. Automatic caps prevent a complete match verdict; limitations and unreadable pages are surfaced. Cross-page copy is compared as reading-order text; there is no semantic page alignment or automatic image registration.
- Pixel comparison is intended for similar layouts. Different aspect ratios are called out as layout differences. Animated/multiframe images are treated as a still image.
- Optional model adapters are implemented and tested with controlled responses. A real provider requires your configuration and should be evaluated on representative assets.
- Draft rules and temporary reviewer checkmarks live in the current browser page. Saved runs, originals, and feedback persist in `services/comparer/.data/`; scratch previews also use `.artifacts/`. Both are excluded from the ZIP. Automatic cleanup defaults to 30 days, 500 runs, and a 2 GB saved-asset budget; the first reached limit prunes oldest runs. Feedback is retained for dataset export by default. Connections shows the policy and a cleanup preview.
- The included stores and worker support a single service process, with optional worker threads. External databases/storage services require an adapter and integration testing; a database adapter alone does not replace local artifact storage. The ZIP has no SSO, tenant isolation, or distributed queue.
- This is a local testing app. The Python standard-library server is not an internet-facing production service. Keep the default loopback binding.

See [enterprise setup and dependency research](docs/ENGINE_OPTIONS.md), [rules](docs/RULES.md), [API contract](services/comparer/API.md), and [validation](docs/VALIDATION.md).
