# Integrations, white-label setup, and feedback

The manual comparer and the optional automation layer use the same Python pipeline. An automated job carries **two files + comparison options + labels**. It produces the same base evidence, rules review, preview boxes, and result as a manual upload. No particular testing framework, model provider, or external database is required.

For a new recipient, start with [the handoff checklist](HANDOFF.md). Day-to-day review is in [the reviewer guide](REVIEWER_GUIDE.md); backup, restore, retention, and troubleshooting are in [operations](OPERATIONS.md).

## Quick local trial

Start the app with `npm run dev`. In a second terminal, in the project folder:

```sh
npm run demo:automation
```

This submits the included synthetic images, waits for a job, and prints its review URL. Open **Connections** for activity and **History** for completed results. Your original manual upload workflow remains on **Compare**.

For automatic pickup, add `COMPARER_INBOX=inbox` to the root `.env` and restart both services. Then:

```sh
npm run demo:automation -- --inbox
```

The demo writes the files first, then atomically renames a `.pending` manifest to `.json`. The inbox poller discovers it within the configured interval. The default inbox is **not** enabled until you configure a path. `COMPARER_WORKERS=0` pauses background execution; manual comparisons still run.

## Two integration contracts

| Contract | Use it when | Shipped implementation |
|---|---|---|
| HTTP push | Your test runner can submit artifacts after a test | `POST /api/jobs`; Node and Python clients in `examples/` |
| Folder intake | A runner/exporter can write to a shared local folder | Inbox poller for JSON manifests with relative file paths |
| Custom source | Your organization needs S3, SharePoint, CI artifact APIs, or another source | `Source` extension interface; vendor connectors are not shipped |

### HTTP from any testing framework

`examples/submit-job.mjs` needs Node 22+ and no npm dependencies. `examples/submit_job.py` needs Python 3.10+ and no pip dependencies. They call the Python API directly by default. Set `COMPARER_URL` and optional `COMPARER_TOKEN` in their environment when using another service. The standalone clients do not read the root `.env`; the npm demo does.

```sh
node examples/submit-job.mjs approved.png actual.png build-123-checkout
python examples/submit_job.py approved.png actual.png --key build-123-checkout
```

Use a stable, unique idempotency key for each **build + test case + reference revision + rules/config revision**. Retrying the same key returns the existing job. A changed pair or rule set needs a new key. Keep keys under 200 characters. A completed job can contain `match`, `mismatch`, or `inconclusive`: `done` means processing completed, not that the assets matched. Read the saved run's verdict to decide your CI outcome.

Deduplication lasts while the job record exists. Terminal jobs expire after 7 days by default; use a producer-side ledger or adjust job retention if retries can arrive later. Reusing a retained failed job's key returns that failed job rather than rerunning it.

In an existing Playwright test, after capture:

```js
import { CompareClient } from './content-compare/examples/submit-job.mjs';

await page.screenshot({ path: 'actual.png', fullPage: true });
const client = new CompareClient({
  baseUrl: process.env.COMPARER_URL,
  token: process.env.COMPARER_TOKEN,
});
const { job } = await client.submit({
  sourcePath: 'approved.png',
  targetPath: 'actual.png',
  idempotencyKey: `${buildId}-checkout-${referenceRevision}-${rulesRevision}`,
  labels: { suite: 'checkout', build: String(buildId) },
  options: { engines: ['ocr', 'text', 'pixel'], rules: approvedRuleProfile.rules },
});
```

This is a handoff example for your existing runner, not a Playwright dependency installed by this project. Playwright supports saving screenshots or obtaining a buffer. [Playwright screenshot documentation](https://playwright.dev/docs/screenshots).

For Cypress, its Node-side `after:screenshot` event supplies the saved screenshot path; call the same Node client after the screenshot is ready. Choose the approved reference explicitly and use build/test metadata for labels. [Cypress event documentation](https://docs.cypress.io/api/node-events/after-screenshot-api).

For Selenium Python, call `driver.get_screenshot_as_file(...)` and pass that completed file plus the approved reference to `CompareClient.submit`. [Selenium WebDriver API](https://www.selenium.dev/selenium/docs/api/py/selenium_webdriver_remote/selenium.webdriver.remote.webdriver.html).

### Folder manifest

See `examples/manifest.example.json`. Place referenced files below the configured inbox. A manifest lists one or more pairs:

```json
{
  "batch": "build-123",
  "idempotency_prefix": "build-123-reference-v2-rules-v1",
  "pairs": [{
    "source": "approved/checkout.png",
    "target": "screenshots/checkout.png",
    "labels": { "suite": "checkout", "build": "123" },
    "options": { "engines": ["ocr", "text", "pixel"] }
  }]
}
```

Write assets completely before publishing the manifest. Build the manifest under a non-`.json` extension, close it, then rename it in the same folder. The service copies inputs into its private data directory before a job runs. It rejects absolute paths, traversal, symlinks, oversized files, and invalid manifests. A successfully enqueued manifest becomes `.json.done`; rejected input is recorded with an error. Inspect Connections and the manifest's error file before retrying. Do not share or ZIP a live inbox containing actual organization assets.

A reference and an output need not have the same type: a manifest may pair `copy.docx` with `screenshot.png`, or PDF with TXT. Each selected method reports whether it could compare that pair. Supply rules in `options.rules` and optional `rule_guidance`. Include `vision_llm` in `options.engines` only when model processing is intended; the service must also have a configured provider/model.

## Organization settings and restyling

Copy the example to `config/organization.json`:

```json
{
  "brand": {
    "name": "Example Studio · Content Review",
    "accent": "#345d99",
    "logo_url": "/brand/logo.png"
  }
}
```

Put the logo in `apps/web/public/brand/logo.png`. The UI accepts a local absolute URL path for the logo, so loading a brand does not make a request to an external image host. Use a six-digit hex accent; the UI chooses contrasting button text. For deeper restyling edit `apps/web/src/app/globals.css`; layout components remain ordinary React/Next.js.

Set `COMPARER_CONFIG=config/organization.json` in `.env`, then restart. The npm launchers resolve environment path settings from the project root. Paths inside a JSON config should be absolute; direct Python invocations use their current working directory. Environment variables override file settings. Keep API keys and tokens in environment configuration, not branding JSON.

`config/organization.json` and `.env` are excluded from the standard ZIP. The example is included. Custom assets and code under `apps/web/public` and `src` **are** included; inspect the archive before distributing a branded fork.

## Libraries, frameworks, models, and storage

| Layer | Built in | How an organization adapts it |
|---|---|---|
| Comparison runtime | Python standard library; optional Pillow, PDF, OCR, SSIM extras | Install only permitted extras; missing methods report their status. See `ENGINE_OPTIONS.md`. |
| HTTP serving | Python `ThreadingHTTPServer` for local testing | An internal deployment can wrap `pipeline.compare` / `Automation` using its approved framework. No FastAPI/Django runtime is required or shipped. |
| UI | Next.js + React | Restyle components/CSS; point the proxy at an approved internal Python endpoint using `COMPARER_URL`. |
| Models | Gemini, OpenAI-compatible, Anthropic, Ollama | Set exact model/endpoint server-side, or implement a provider plugin. No model/provider SDK is mandatory. |
| Run/job/feedback records | SQLite default; JSON files alternative | `COMPARER_STORE=your_package:YourStore` loads the `Store` contract. Postgres/Mongo adapters are not shipped. |
| Input sources | HTTP push; watched folder | `COMPARER_SOURCES=your_package:YourSource` loads an organization-owned source. |
| Artifact bytes | Local filesystem under `.data` | Database adapters change records, not artifact storage. Remote object storage needs an additional implementation/deployment design. |

The package choices are public candidates, not evidence of internal Artifactory approval. The source ZIP plus npm lockfile and Python optional extras give administrators a small, reviewable baseline. See [enterprise installation and alternatives](ENGINE_OPTIONS.md) for registry configuration and advanced research candidates.

### Custom adapter shape

See `services/comparer/comparer/adapters.py` and [the automation API](../services/comparer/AUTOMATION_API.md) for exact signatures. Put plugins in an installed package or on `PYTHONPATH` before starting the service.

For a reviewer machine where Python is prohibited, set `COMPARER_URL` in the root `.env` to the organization-hosted API and use `npm run dev:web`, or `npm run build` then `npm run start:web`. Those modes load configuration without starting or requiring a Python process.

- A **Store** implements lifecycle/health, runs, jobs, atomic job claiming/cancellation, restart recovery, and feedback iteration. It must be thread-safe. Follow the SQLite implementation as a working reference; the JSON-file implementation demonstrates an alternate backend. `tests/plugins_demo.py` exercises dynamic loading with an in-memory test implementation.
- A **Source** returns named file bytes, labels, options, and an idempotency key. Follow the inbox implementation for durable handoff/acknowledgment. Avoid acknowledging an upstream artifact before the local job is durably saved.
- A **provider** plugin uses `COMPARER_PROVIDER_PLUGIN=org=module:function`; set `COMPARER_VISION_PROVIDER=org`, then match the exact documented function signature and response format in the service API. The built-in model response validators and selected-engine gate still apply.

A configured store that cannot start causes an explicit startup failure. It does not silently write to a different database. Failed source plugins are reported in Connections. Switching `COMPARER_STORE` selects a different store; it **does not migrate existing history**.

## Persistence and operating boundaries

The included runtime is designed for one service process per data directory. Worker threads share the store and queue. Restart recovery returns interrupted work to the queue within the configured attempt limit. Use a single instance with JSON-file storage; it is intended for portable local tests, not multiple processes writing to a shared network drive. SQLite's WAL file belongs with its database during backup; stop the service before copying the complete data directory.

The data directory stores records, original files, previews, and feedback. Scratch previews also remain in `.artifacts`. Automatic cleanup runs every 10 minutes by default. It prunes oldest runs at 30 days, 500 runs, or a 2 GB saved-run artifact budget, removes terminal job records after 7 days, and expires scratch artifacts after 120 minutes. Input copies are released after successful persistence. Producer-owned inbox files are never deleted; acknowledged manifests expire after 7 days. Review feedback survives run pruning by default. The source ZIP excludes both locations. To move review history privately, stop the service and back up `.data` separately. Review exports contain text excerpts, notes, and reviewer labels; treat them as content data. Use **Connections → Preview cleanup** to inspect proposed removals without deleting anything. Run the standalone cleanup CLI only with the service stopped; live maintenance uses the API in the running process. Configure retention in `.env` or organization JSON; see the service API for all settings. The size budget applies to saved run folders, not the entire disk, database, queued inputs, or retained feedback.

`COMPARER_TOKEN` optionally protects integration operations, and the Next proxy adds it on the server. It is an integration credential, **not user login or tenant isolation**. The default launcher binds both services to loopback. An organization hosting the app centrally must add its own authentication, authorization, TLS, access restrictions, backup, retention, and load-tested serving strategy. None is silently provisioned by this ZIP.

## A feedback loop that can be evaluated

1. Reopen a run and select a finding, or review the overall comparison.
2. Save a verdict, a correction, and useful notes. For a missed issue, include expected wording and page/location in the note.
3. Export all saved feedback from History. Each JSONL row includes a stable feedback ID, run/finding IDs, the finding snapshot, verdict, correction, notes, content hashes, and configuration provenance.
4. Curate with an SME: reconcile conflicting labels, remove accidental duplicate reviews, and split train/evaluation sets by content or campaign to reduce leakage.
5. Establish false-positive and missed-issue rates on a held-out set. Compare changes to prompts, rules, engine settings, or model versions against that set.
6. If your chosen model supports fine-tuning, transform reviewed examples into its required dataset format in your organization's tools. That conversion, training, deployment, and any external upload are outside this app.

The UI's small review checkboxes remain temporary session triage. **Save feedback** records persistent reviewer judgment. Feedback entries are append-only in this UI; corrections should explain which previous review they supersede. There is no automatic model update, universal fine-tuning format, or claim that labels by themselves improve accuracy.
