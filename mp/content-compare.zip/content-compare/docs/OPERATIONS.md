# Operations and troubleshooting

This runbook covers the shipped local pilot. Use [HANDOFF.md](HANDOFF.md) for first installation and team acceptance, [INTEGRATIONS.md](INTEGRATIONS.md) for customization, and the [automation API](../services/comparer/AUTOMATION_API.md) for exact contracts.

## Start, stop, and restart

Run commands from the project root, where `package.json` lives.

| Task | Command / procedure |
|---|---|
| Install the web dependencies | `npm ci` |
| Install common optional Python packages | `npm run setup:python` |
| See detected comparison methods | `npm run doctor` |
| Start the local app and API | `npm run dev` |
| Stop both | Ctrl+C in the terminal running them |
| Apply `.env` or organization config changes | Stop, then run `npm run dev` again |
| Build and run without the dev server | `npm run build`, then `npm start` |
| Start only Python | `npm run dev:api` |
| Start only the UI against an existing API | Set `COMPARER_URL`, then `npm run dev:web` |
| Run the built UI without Python on this machine | `npm run build`, then `npm run start:web` |

Default UI: **http://127.0.0.1:3100**. Default API: **http://127.0.0.1:8765**. The combined launcher binds both to loopback. Production mode changes how Next.js serves the UI; it does not add authentication, central hosting, or a production Python server.

Use one comparer process per data directory. Worker threads are configured with `COMPARER_WORKERS` (default 1, maximum 4). `0` pauses job execution, but manual comparisons, storage, intake, and cleanup remain active. Restart recovery retries interrupted jobs within the configured attempt limit; this is not a distributed queue.

Logs appear in the terminal. The app does not rotate or persist a separate operational log by default.

## Configuration and paths

The npm launchers load the root `.env`; variables already set in the launching environment take precedence. Automation settings prefer environment values over organization JSON, then built-in defaults. Use the example JSON for branding and documented non-secret settings. Keep keys and `COMPARER_TOKEN` in the environment, never in `NEXT_PUBLIC_*` variables or branding JSON.

The npm scripts resolve these relative paths from the project root: `COMPARER_CONFIG`, `COMPARER_DATA_DIR`, `COMPARER_STORE_PATH`, `COMPARER_INBOX`, and `COMPARER_ARTIFACT_DIR`. Use absolute filesystem paths inside organization JSON. Direct Python commands and standalone example clients do **not** load `.env`; set the equivalent environment explicitly and account for their working directory.

Both Python and the Next proxy need the same `COMPARER_TOKEN` when it is configured. The root npm launcher supplies it to both. Direct HTTP producers must supply it themselves. It protects selected integration operations, not all reads or feedback writes, and is not user authentication. Do not expose the shipped service as a public or shared tenant service.

To use different local ports, update the related settings together and restart:

```dotenv
WEB_PORT=3200
COMPARER_PORT=8865
COMPARER_URL=http://127.0.0.1:8865
COMPARER_CORS_ORIGIN=http://127.0.0.1:3200
```

Open the UI on the matching port. `COMPARER_CORS_ORIGIN` is for direct browser-to-Python requests. The normal UI calls its same-origin Next proxy; the proxy forwards server-side without the browser's Origin header. An explicit `http://127.0.0.1:3100` allowlist does not also mean `http://localhost:3100` for direct calls.

Changing `COMPARER_STORE` selects a different record store; it does not migrate history. Built-in choices are `sqlite` and `jsonfiles`. A configured store that cannot open fails startup rather than silently switching. Custom stores/sources/providers must be importable by the Python interpreter actually selected by the launcher.

## Data locations and ownership

| Data | Default location | Treatment |
|---|---|---|
| Run/job/feedback records | `services/comparer/.data/comparer.db` for SQLite; `.data/store/` for JSON files | Persistent private data; back up with artifacts |
| Originals, previews, overlays, result JSON | `.data/runs/<run_id>/` | Persistent until run cleanup; saved history uses these URLs |
| Pending job input copies | `.data/jobs/<job_id>/` | Released after successful completion; terminal leftovers expire |
| Scratch previews | `services/comparer/.artifacts/cmp_…/` | Removed after saved-run copying, or by scratch TTL |
| Producer files and manifests | Configured `COMPARER_INBOX` | Producer owns asset cleanup; comparer expires acknowledged manifests only |
| Server process marker | `.data/server.lock` | Runtime PID marker; protects standalone cleanup against a live server |
| Secrets and organization settings | Root `.env`, `config/organization.json` | Private configuration, supplied separately from the ZIP |

If the installation directory is read-only, set `COMPARER_DATA_DIR` and `COMPARER_ARTIFACT_DIR` to writable locations. A custom `COMPARER_STORE_PATH` may live outside the data directory and must be included separately in backup. Database adapters replace records; they do not move artifact bytes to remote object storage.

## Retention and cleanup

**Cleanup starts automatically, with the first pass shortly after startup and later passes every 600 seconds by default.** Inspect the effective policy, disk usage, and **Preview cleanup** in Connections. The preview does not delete data.

| Setting | Default | What expires |
|---|---|---|
| `COMPARER_RETENTION_DAYS` | 30 | Older run records and their files |
| `COMPARER_MAX_RUNS` | 500 | Oldest runs above the count |
| `COMPARER_MAX_DATA_MB` | 2048 | Oldest runs above the saved run-folder byte budget |
| `COMPARER_JOB_RETENTION_DAYS` | 7 | Terminal jobs and leftover inputs |
| `COMPARER_SCRATCH_TTL_MINUTES` | 120 | Temporary comparison artifacts; minimum 1 minute |
| `COMPARER_INBOX_TTL_DAYS` | 7 | Acknowledged `.done` / `.failed` manifests and error files |
| `COMPARER_KEEP_FEEDBACK` | 1 | Keep feedback when run records/files are pruned |

Run limits act independently. To disable an individual run age/count/size limit or job/inbox age limit, set it to `0`. **Scratch TTL cannot be disabled with `0`; that becomes 1 minute.** Retained feedback, the database, queued job inputs, producer-owned assets, and backups are outside the saved-run size budget. Monitor those separately. Feedback retained after pruning no longer has the original run images available; export includes its stored finding/context/provenance snapshot.

Use the running service's `POST /api/automation/cleanup?dry_run=1` to inspect cleanup through the API. Omitting `dry_run` executes removal. The UI offers preview only. The standalone `python -m comparer cleanup` command is for a stopped server; direct Python requires the same environment and interpreter as the service. Do not bypass the live-server guard for routine operations. Full policy and orphan handling are in [the API](../services/comparer/AUTOMATION_API.md#cleanup--retention).

## Back up and restore private history

The shareable source ZIP is **not a backup** of review data. Exported comparison JSON or feedback JSONL is also not a full restore image.

1. Pause upstream producers and allow queued/running jobs to finish where possible. If moving to a different filesystem path, drain the queue: unfinished jobs store input paths and are not automatically rebased by a move.
2. Stop the app with Ctrl+C and confirm its service processes have exited. Running cleanup alone does not stop writes and is not a substitute for stopping the service.
3. Copy the complete configured data directory to a private backup location, including the SQLite database and any `-wal` / `-shm` sidecars. Copy an external store path separately if configured. Preserve originals and run folders, not just records.
4. Preserve the corresponding source release, dependency inventory, rule profiles, organization settings, and required inbox inputs separately. Supply credentials through the normal secret mechanism. Scratch files are unnecessary for saved runs; copy them only if temporary comparisons must also be retained.
5. Restore into an isolated installation with the **same release and store type**, with the service stopped. Keep existing backups rather than overwriting your only copy. Recreate the environment and point it to the restored directories. For an unfinished queue, preserve the original input paths or arrange a controlled resubmission after addressing retained job records; changing directories alone is insufficient.
6. Review retention settings before first startup so old restored runs are not immediately pruned. Keep external producers disconnected until verification is complete.
7. Start one service instance. Confirm History opens a known run with its images, feedback is present/exportable, and a synthetic new comparison completes. Only then resume intake.

Switching SQLite to JSON files, or to an external database, requires a separate migration implementation; no automatic store migration is provided. Cross-machine restore and future-version schema migration need testing in the target environment.

## Troubleshooting

| Symptom | Check / next action |
|---|---|
| `npm` / Python not found | Confirm Node 22+ and Python 3.10+ are on PATH. Open a new terminal after installation; set `COMPARER_PYTHON` to the intended executable if needed. |
| Package install or certificate failure | Use the organization's configured npm/PyPI repositories and CA settings; see [enterprise setup](ENGINE_OPTIONS.md#artifactory-configuration). Ask which package/version is missing. Do not disable certificate checks. |
| Port already in use | Stop the earlier app in its own terminal, or choose another UI/API port pair and update `COMPARER_URL`. Do not stop unrelated project processes. |
| UI opens but service is offline / `503` | Read the Python startup error; inspect `COMPARER_URL`, writable data paths, and store config. Open `http://127.0.0.1:3100/api/health` for the running proxy/service health. `npm run doctor` detects libraries but does not prove a server is listening. |
| Upload `403` | Refresh the current UI and restart updated services. The Next proxy accepts mutation Origin only for the exact UI scheme/host/port. Direct browser API calls also need a matching Python CORS allowlist. |
| Integration `401` | Match producer, Python, and Next proxy tokens. Standalone Node/Python clients do not read root `.env`; set their environment explicitly. |
| Upload `413` | UI files are limited to 10 MB each. The Next proxy permits a 30 MB request body, including encoding overhead. Direct API limits depend on `COMPARER_MAX_BODY_MB` and job `COMPARER_MAX_INPUT_MB`; raising Python limits does not raise UI/proxy limits. |
| OCR unavailable or cross-format copy missing | Run `npm run doctor`; check the selected interpreter has the OCR wrapper and `tesseract --version` works in the launching shell. A visual finding alone does not mean copy was checked. |
| PDF/DOCX preview differs from the source app | DOCX is extracted copy, not Word layout. PDF rendering needs an available backend; inspect notes, unreadable-page warnings, and the default 10-page cap. |
| Vision unavailable, `404`, `429`, or guidance not evaluated | Check the configured provider pin, exact available vision model, endpoint, credentials/quota, and selected method. Connections shows provider plugin errors. No specific model is bundled or guaranteed by this release. |
| Job stays queued | Inspect Connections; confirm workers are enabled and the store is healthy. `COMPARER_WORKERS=0` deliberately pauses execution. |
| Job failed | Read its error and attempts. Correct the cause and submit a new request with a new key when an intentional rerun is needed. Reusing a retained job's idempotency key returns that same job, including a failed one. |
| Inbox ignored or manifest failed | Configure the inbox and restart. Publish only after all files are complete; use relative paths with no traversal/symlinks. Read the sibling error file. After fixing a partially stored manifest, retry with its original stable keys so existing jobs are not duplicated. |
| A repeated submission runs again later | Idempotency applies while the job record exists. Cleanup removes terminal jobs after 7 days by default; old keys can then be reused. Keep a producer-side ledger or adjust retention if deduplication must last longer. |
| History unexpectedly empty or preview missing | Check effective data directory/store path and whether retention pruned the run. Changing store type does not migrate data. Inspect saved artifact warnings and backup availability. |
| Feedback not saved | Use **Save feedback**, not the session checkmark. A run must have persisted successfully. Export from History after saving at least one entry. |
| Disk use exceeds the configured budget | The budget covers `.data/runs`, not all data. Inspect queued inputs, retained feedback/database files, producer inbox assets, and private backups. |
| Shell says `command not found: ng` before the app starts | This is a shell startup configuration, not a Content Compare dependency. Guard an optional Angular completion line with `if command -v ng >/dev/null 2>&1; then source <(ng completion script); fi`, or have the machine owner remove the obsolete line. |

History search covers loaded records, and its feedback export covers **all** saved feedback, not only currently filtered runs. For support, include the details listed in [the handoff guide](HANDOFF.md#what-to-send-and-how-to-report-an-issue).

## Package a handoff

1. Review the recipient acceptance checklist and [validation record](VALIDATION.md). Record organization-specific deviations, chosen package versions, and remaining verification.
2. For code changes, run `npm run typecheck`, `npm test`, and `npm run build`. Use `npm run test:smoke` and `npm run test:automation` against a separate disposable test instance; they create comparisons, jobs, and feedback. Do not run them against a team's live review history or configured external model account. See the scripts for required sample assets and default ports.
3. Review files under `apps/web/public`, `src`, `docs`, `examples`, and `scripts` for organization-specific content before sharing. These paths are included. Remove private additions from the distribution scope without deleting the organization's only copy.
4. Run `npm run package:zip` **after the final source/documentation changes**. It replaces `dist/content-compare.zip` with an explicit source selection and verifies archive integrity.
5. Inspect the ZIP: include the handoff/reviewer/operations guides and sample/config examples; exclude credentials, private run/feedback data, live inbox files, Git history, installed dependencies, and runtime agent logs. Defaults exclude `.env`, `.data`, `.artifacts`, `.venv`, `node_modules`, and the standard private organization config; arbitrary secrets pasted into otherwise distributable files cannot be detected automatically.
6. Extract the ZIP into a new folder and verify the selected setup path with synthetic assets. Share that ZIP and the release/validation information; provide private settings separately. Recipients still need access to permitted packages. For offline installation, IT must prepare the dependency bundle separately.

Keep custom adapter documentation and tests beside its implementation. When APIs or behavior change, update the corresponding contract, architecture map, handoff instructions, and validation record together.
