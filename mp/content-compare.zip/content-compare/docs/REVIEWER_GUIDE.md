# Reviewer guide

Use Content Compare to check an approved reference against what was produced, explain acceptable exceptions, and record where the comparison was right or wrong. A person still makes the final content decision.

Need the app started first? Send the person setting it up to [the handoff guide](HANDOFF.md).

## 1. Choose the two files

On **Compare**, put the approved design or copy in **Approved reference** on the left. Put the screenshot, document, or other produced output in **Produced asset** on the right. The direction matters: missing copy means reference content is absent from the produced asset.

Images, PDF, DOCX, TXT, and Markdown are supported, up to **10 MB per file in the UI**. The files can be different types. Legacy `.doc` files need conversion to DOCX or PDF first. Start with **Try an example** if you do not yet have a pair.

Under **Comparison methods**, check which methods are available. OCR reads screenshot text; text comparison finds copy changes; pixel/structure methods inspect visual differences. The optional vision method uses the model configured by your operator. Enabling it can send content to that endpoint. No AI model is bundled.

Click **Compare files**. Keep the result's warnings, method status, and coverage in view. An unavailable method did not check anything. For image-to-document copy checks, confirm text was actually extracted or the vision method ran successfully.

## 2. Read the evidence

| Result | Meaning |
|---|---|
| **No flagged differences** (`match`) | The methods that ran found no remaining flagged difference within their coverage. This is not proof that every detail was checked. |
| **Differences found** (`mismatch`) | At least one difference remains flagged. Inspect it to decide whether it matters. |
| **Needs more evidence** (`inconclusive`) | Available evidence or coverage was insufficient. Ask the operator about missing methods, unreadable pages, or limits. |

Select a finding in the list to highlight its numbered box and relevant page. Use page controls and zoom to inspect details. Some findings have text but no coordinates, so they appear in the list without a box. DOCX shows extracted copy with simplified layout.

Priority describes the reported issue's importance; confidence is a heuristic, not a percentage probability of correctness. OCR can misread characters, and visual methods may report expected font or rendering differences. Default PDF processing covers at most 10 pages; read coverage warnings for longer files.

## 3. Apply the rules for this content

Open **Add rules** before comparing. You can require wording, forbid wording, allow a specific wording change, or ignore visual differences in a region. Import/export a rule profile as JSON so the team can reuse an agreed version.

For the sample, choose **Try the sample's rules**, then compare again. Switch between **Base comparison** and **After rules**. The **Ignored** filter shows suppressed findings and the rule explanation; evidence is preserved.

An allowed copy change can still have a pixel difference. A visual ignore region does not waive a missing required disclosure. The **Compliance-related** label helps categorize review; it does not certify compliance. See [rule semantics](RULES.md) for exact behavior.

Free-form expert guidance requires the vision method and makes a separate model review request. If it says **not evaluated**, the instruction was not applied. Use structured checks for required wording rather than assuming a free-form instruction ran.

## 4. Save useful feedback

Under **Teach the next review**, choose the finding or overall comparison, then an assessment:

| Assessment | Use when |
|---|---|
| Correct finding | The reported difference is real and useful. |
| False positive | The claimed issue is not present; explain what the tool misread. |
| Acceptable difference | The difference is real but approved for this content; explain why. |
| Missed an issue | Something important was not flagged. Include expected/actual wording and page/location. This is saved against the overall comparison. |
| Wrong priority | The issue exists but its priority should change; choose the expected priority. |
| Other | Explain a review judgment that does not fit the choices above. |

For example: “Page 1, bottom disclosure: the reference includes ‘Terms and conditions apply.’ but the produced asset omits it.” Record enough context for another reviewer to understand without guessing.

Click **Save feedback** and confirm the saved entry appears. Feedback persists with history and does not alter the original findings. Entries are appended; to correct an earlier review, save another entry explaining which one it supersedes.

**The small checkmarks beside findings are temporary session triage.** They are not saved feedback. Draft rule edits also live in the current browser page; export the profile before leaving or refreshing.

## 5. Reopen and share the review

- **History** contains saved manual and automated runs. Open one to inspect its original evidence and feedback. A saved review's comparison settings are read-only; start a new comparison to change inputs or rules.
- History search covers loaded results; use **Load older comparisons** to include older pages, or use its source/result filters.
- **Export report** saves comparison JSON, including rule evidence and current review checkmarks. Image URLs refer to this installation; the JSON is not a self-contained image bundle.
- **Reference PNG / Produced PNG** download the current page's annotations when rendering is available. With rules applied, these PNGs show after-rules flagged findings. Export additional pages separately if needed.
- **History → Export review dataset** downloads all saved feedback as JSONL, including text excerpts and reviewer notes. The team curates this for evaluation or training in its own tools; exporting does not train a model or upload data.

Automated jobs appear in **Connections**. A job marked `done` means it finished processing; open its saved run to see whether it matched. Cancel is available only while a job is queued.

History is subject to the operator's cleanup policy. The default removes older runs at 30 days, 500 runs, or the saved-asset budget; feedback is retained by default. Save needed evidence through the team's archive/backup process. Ask your operator about a disappeared run, missing preview, unavailable engine, or failed save; [troubleshooting](OPERATIONS.md#troubleshooting) lists the checks.
