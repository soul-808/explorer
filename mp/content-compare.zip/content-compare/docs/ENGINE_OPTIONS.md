# Comparison engines and enterprise installation

Research checked **September 17, 2026**. These are candidate choices based on public documentation, distribution, licensing, and dependency footprint. We do not have access to an internal Artifactory or approved-package list. **Available on PyPI is not the same as internally approved.**

## Recommended starting point

Keep the service itself on Python's standard library. Add Pillow for decoding and pixel differences, pypdfium2 plus pypdf for PDFs, and pytesseract plus the Tesseract executable for OCR. Add NumPy/scikit-image only when structural comparison is useful. This gives independently useful layers without making a heavy model framework mandatory.

| Component | Role in this app | Review considerations | Primary source |
|---|---|---|---|
| Python `difflib`, `zipfile`, XML, `urllib`, `http.server` | Core text comparison, DOCX extraction, HTTP adapters and local server | No third-party Python runtime dependencies | [Python library](https://docs.python.org/3/library/index.html) |
| Pillow | Image loading, pixel regions, image exports | HPND/MIT-CMU family; inspect native codec notices | [Pillow](https://pillow.readthedocs.io/en/stable/about.html) |
| pypdfium2 | PDF rasterization and positioned native text | Apache/BSD terms plus bundled PDFium and third-party notices; prefer platform wheels | [pypdfium2](https://pypdfium2.readthedocs.io/en/stable/readme.html) |
| pypdf | Pure Python PDF text fallback | BSD-3-Clause; useful when native renderers cannot be installed | [pypdf license](https://github.com/py-pdf/pypdf/blob/main/LICENSE) |
| pytesseract + Tesseract | Extract screenshot copy and coordinates | Apache-2.0; the system binary is a separate install/approval item | [pytesseract](https://github.com/madmaze/pytesseract) |
| NumPy + scikit-image | Structural similarity (SSIM) | BSD-family packages, plus SciPy and other transitive wheels; not required for ordinary text/pixel comparison | [scikit-image licensing](https://scikit-image.org/docs/stable/license.html) |
| Next.js + React | Local interface and API proxy | MIT; npm lockfile included | [Next.js installation](https://nextjs.org/docs/app/getting-started/installation) |

No benchmark establishes one of these as universally accurate for marketing proofing. In particular, a high visual similarity score does not establish correct wording, and correct OCR text does not establish correct visual placement.

## Optional newer/heavier approaches

| Candidate | Current app status | Why evaluate it | Tradeoff / source |
|---|---|---|---|
| RapidOCR / ONNX Runtime | Adapter implemented for `rapidocr-onnxruntime`; optional profile | OCR without a separate Tesseract binary; CPU inference option | Native runtime/model assets still need review. Current upstream also has a newer `rapidocr` package; the implemented compatibility adapter is not a claim that every release is interchangeable. [RapidOCR](https://github.com/RapidAI/RapidOCR) |
| EasyOCR | Adapter implemented; separate optional profile | Alternative recognition behavior for difficult screenshots/languages | PyTorch footprint and model downloads; benchmark and pre-cache approved weights. [EasyOCR](https://github.com/JaidedAI/EasyOCR) |
| PaddleOCR / document vision models | Research candidate, not integrated | Advanced text detection, document layout, and image/PDF parsing | More dependencies and model/runtime choices. Upstream documents current capabilities and model assets. [PaddleOCR](https://github.com/PaddlePaddle/PaddleOCR) |
| Docling / Granite-Docling | Research candidate, not integrated | Structured document understanding, reading order, tables, multiple OCR backends | MIT codebase; model licenses must be reviewed separately. Bigger scope than the initial comparator. [Docling](https://github.com/docling-project/docling), [model catalog](https://docling-project.github.io/docling/usage/model_catalog/) |
| Datalab / Surya family | Research candidate, not integrated | Modern document OCR/layout alternatives | Check code and weight terms for the exact selected release; do not infer a model's commercial terms from a repository badge. [Repository](https://github.com/datalab-to/surya), [model terms](https://github.com/datalab-to/surya/blob/master/MODEL_LICENSE) |
| OpenCV feature matching / registration | Package extra only; alignment not implemented | Could align shifted/cropped screenshots before pixel comparison | Can misalign repeated UI patterns; validate correspondence rather than assuming registration worked. [OpenCV](https://docs.opencv.org/4.x/) |
| Hosted or local vision models | Gemini, OpenAI-compatible, Anthropic, Ollama adapters implemented | Meaning, wording, and layout observations; interpreting expert guidance | Nondeterministic results, variable coordinate quality, provider limits, and data-routing decisions. [Provider setup](PROVIDERS.md) |

Avoid adding every package to an enterprise baseline. The broader `all` profile is for evaluation, not a minimum requirement. PyMuPDF is an explicit opt-in fallback because its AGPL/commercial terms differ from the default PDF path. Poppler executables are also separate distribution/licensing review items.

## Deployment environments

| Environment | Practical mode |
|---|---|
| No third-party Python libraries | Run the stdlib service directly; compare TXT/DOCX with local rules. Add a configured API for image understanding. System PDF tools may help if permitted. |
| Common Python packages permitted | Install only `[images,pdf,ocr]`, then add `[ssim]` if useful. |
| Python permitted but system OCR binaries restricted | Evaluate `[ocr-onnx]` with approved ONNX wheels/model files. |
| No outbound model calls | Leave Vision model off; local OCR/pixel/text/structure/rules still work. A local vision server is another option. |
| Python not permitted on the user's machine | Run the same Python API on an approved internal host and set `COMPARER_URL` for the Next.js proxy. This app does not contain a second JavaScript comparison implementation. |
| Fully offline installation | Have your administrators prepare npm packages, platform-specific Python wheels, system binaries, and any model weights. A source ZIP alone is not an offline dependency bundle. |

## Artifactory configuration

Use your organization's existing repositories and credentials. No repository is created by this app. JFrog documents both [PyPI](https://docs.jfrog.com/artifactory/docs/pypi-repositories) and [npm](https://docs.jfrog.com/artifactory/docs/npm-repositories) endpoints.

Example package endpoints (replace placeholders):

```text
npm:  https://ARTIFACTORY_HOST/artifactory/api/npm/NPM_VIRTUAL_REPO/
PyPI: https://ARTIFACTORY_HOST/artifactory/api/pypi/PYPI_VIRTUAL_REPO/simple
```

Use your normal user-level npm/pip configuration or organization-provided JFrog CLI setup. Environment variables can select the indexes without editing source files:

```sh
export npm_config_registry=https://ARTIFACTORY_HOST/artifactory/api/npm/NPM_VIRTUAL_REPO/
export PIP_INDEX_URL=https://ARTIFACTORY_HOST/artifactory/api/pypi/PYPI_VIRTUAL_REPO/simple
npm ci
npm run setup:python
```

In PowerShell, set `$env:npm_config_registry` and `$env:PIP_INDEX_URL` to the corresponding values before running the same npm commands. Keep repository tokens in your organization's credential mechanism, not the shared ZIP. Use the organization's CA configuration when required; do not disable certificate validation.

Python optional extras have version ranges so approved compatible releases can be selected. For a controlled rollout, resolve and lock the exact transitive versions on each target platform, retain hashes, and mirror any model downloads. The delivered npm lockfile records the interface dependency resolution; the tested Python package inventory is recorded in [validation](VALIDATION.md).

## Evaluating accuracy

Build a small labeled set covering exact matches, price/date changes, missing disclosures, CTA changes, extra copy, logo/layout changes, screenshot scaling, multi-page reflow, low contrast, and empty/corrupt inputs. Run each engine alone, then combinations. Measure missed differences and false positives per category. Use human-reviewed labels; a count of engines is not a calibrated confidence probability.

## Optional automation has the same small baseline

Run history, the job queue, intake, cleanup, and feedback add **no mandatory Python package**. SQLite uses `sqlite3`; the alternative store uses JSON and the filesystem. Both are shipped and tested. The HTTP clients use Node `fetch` or Python `urllib`, so an existing testing framework can hand over screenshots without installing another runner.

The local API is independent of FastAPI, Flask, Django, or another Python web framework. An organization's deployment team can wrap the pipeline and automation contracts in its approved serving stack; such wrappers are extension work, not prebuilt alternatives claimed by this ZIP. For machines that cannot run Python at all, `npm run dev:web` / `npm run start:web` connects only the UI to a separately hosted, approved comparer API.

See [integration contracts and database choices](INTEGRATIONS.md). SQLite and JSON files are actual implementations; Postgres, MongoDB, object storage, and proprietary artifact systems require organization-specific adapters and validation.
