# Vision providers

Vision is optional and off in the interface by default. Keys, endpoints, and the model name are configured on the Python service. Copy the root `.env.example` to `.env` and use `npm run dev` so both processes inherit it. If you start Python directly, provide environment variables in that shell.

## Gemini

```dotenv
COMPARER_VISION_PROVIDER=gemini
COMPARER_VISION_MODEL=your-supported-vision-model
GEMINI_API_KEY=your-key
```

The adapter uses the Generate Content REST image interface. Choose an available model supporting image input; model names and availability are account/provider-specific. [Google image-input documentation](https://ai.google.dev/gemini-api/docs/generate-content/image-understanding).

## OpenAI-compatible endpoints

```dotenv
COMPARER_VISION_PROVIDER=openai
COMPARER_VISION_MODEL=your-vision-model
OPENAI_BASE_URL=http://127.0.0.1:1234/v1
OPENAI_API_KEY=your-key-if-required
```

Uses `/chat/completions` with text and image content. The endpoint must implement that multimodal contract. This can point to an approved gateway, LM Studio, vLLM, or Ollama's compatibility endpoint. Protocol compatibility does not guarantee that a selected model supports images. A local endpoint may not require a key.

## Native Ollama

```dotenv
COMPARER_VISION_PROVIDER=ollama
COMPARER_VISION_MODEL=your-installed-vision-model
OLLAMA_BASE_URL=http://127.0.0.1:11434
```

Uses native `/api/chat` with base64 images. Models must be installed on that server and support vision. [Ollama vision documentation](https://docs.ollama.com/capabilities/vision).

## Anthropic

```dotenv
COMPARER_VISION_PROVIDER=anthropic
COMPARER_VISION_MODEL=your-supported-vision-model
ANTHROPIC_API_KEY=your-key
```

Uses the Messages API with base64 image blocks. The adapter is implemented in `services/comparer/comparer/engines/vision_llm.py`.

## Endpoint control and rules

`COMPARER_VISION_BASE_URL` is an optional server-side endpoint override; normal provider-specific variables also apply. Requests cannot redirect credentials by passing `options.vision.base_url`. `COMPARER_VISION_MODELS` can restrict model selection; see the service documentation for the accepted form.

The base model review detects differences. If free-form expert guidance is supplied, a separate rules review evaluates existing findings and retains reasons. This can cause an additional model request. Malformed replies or unavailable providers are reported rather than interpreted as a clean comparison. No real cloud credential is bundled or required for local tests.

For another provider, implement the same internal call interface and return the normalized comparison/rule schemas. Keep file reading, rule evaluation, evidence storage, and UI independent of that provider. Use contract tests with controlled HTTP/model responses before connecting it to actual assets.

## Organization-owned provider plugin

Install an importable adapter on the Python service, then configure it explicitly:

```dotenv
COMPARER_PROVIDER_PLUGIN=org=your_package.provider:complete
COMPARER_VISION_PROVIDER=org
COMPARER_VISION_MODEL=your-internal-model
```

The callable contract is:

```python
def complete(model, base_url, source_images, source_text,
             target_images, target_text, prompt="") -> str:
    # Images: [(page_index, mime_type, base64_content), ...].
    # Empty prompt means base comparison; use comparer.engines.vision_llm.PROMPT.
    # Nonempty prompt is the separate SME guidance request.
    # Call your approved gateway and return its raw JSON response text.
    ...
```

Read credentials from your service environment. Return the schemas documented in the API and the supplied guidance prompt. No SDK is imposed. `tests/plugins_demo.py` includes a controlled-response plugin for contract testing; it is a fixture, not a real AI model.

Provider selection is strict: an unconfigured or failed pinned provider disables model processing with a reason, rather than using another provider's credentials. Both base review and guidance respect `options.engines`; selecting local methods only makes neither model call. The plugin can still fail independently, and the remaining engines continue with that failure reported.
