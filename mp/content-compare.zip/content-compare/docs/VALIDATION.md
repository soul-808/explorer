# Validation record

Tested locally on September 17, 2026, using macOS arm64, Node 22.16.0, and Python 3.12.11. This is a working local prototype; the checks below do not establish proofing accuracy on an organization's actual assets.

## Checks completed for v0.2.0

- TypeScript and the production Next.js build passed. Compare, History, and Connections are prerendered routes; the same-origin API proxy runs on the server.
- **134 Python tests passed** in the common optional-package environment. The original format/OCR/rules/coverage checks now include both storage adapters, concurrent duplicate submissions, atomic cancellation, durable intake, restart recovery, preserved preview URLs, feedback provenance, cleanup limits and active-file protection, custom adapters, and strict provider selection.
- At the application feature freeze, a fresh portable copy containing all 83 distributable paths ran **134 tests in a bare virtual environment: 113 passed, 21 optional-engine tests skipped**. No pip or third-party Python packages were installed. System Poppler was available. The later handoff pass adds three documentation files.
- **13 manual comparison integration checks** passed through the actual Next.js proxy, including all file-pair directions, rules, annotations, browser Origin headers, invalid routes, and scheme/port boundaries.
- **13 automation integration checks** passed through the same proxy: concurrent duplicate jobs, completion, saved options/labels/evidence, model-selection gate, history query filters, feedback save/reopen, provenance JSONL export, persisted manual runs, scratch opt-out, cleanup preview, and cross-origin rejection.
- A separate test instance on ports 3150/8766 used temporary data, an integration token, and sample organization branding. Saved runs and feedback survived restart. The user's own dev session was left running independently.
- Browser verification in an isolated headless Chrome profile exercised branded navigation, history, reopened image previews and numbered boxes, feedback submission and persistence after refresh, job status, authenticated cleanup preview, fresh manual sample comparison, and responsive mobile layout. No uncaught browser exceptions were observed. Desktop and mobile screenshots were inspected.
- The standalone architecture HTML passed **22 browser interaction/data checks** across seven views, repeated after the handoff update with all **86 source paths** verified. Diagram selection, search, tree expansion, keyboard navigation, mobile overflow, and all-view PDF printing were checked.
- The Node HTTP demo, atomic folder-manifest demo, and dependency-free Python client all produced completed jobs. Folder output appeared in history with intake provenance.
- Web-only startup passed with an unusable `COMPARER_PYTHON` value, served the UI, and reached the existing API. It does not require starting Python on the reviewer machine.
- The feature-freeze 83-file distribution installed with `npm ci --offline` using the existing local cache and passed a separate production build. This validates a portable source package, not an offline dependency bundle.
- ZIP selection includes source/config examples/docs/tests and excludes credentials, organization-local config, uploaded assets, private history/feedback, dependencies, caches, Git internals, and runtime agent messages. Archive integrity and byte correspondence are checked by the packaging workflow.
- The earlier browser upload 403 was fixed by comparing the supplied Origin against the browser-facing host **and scheme/port**, rather than Next's internally normalized origin. Regression checks do not trust a spoofed `Sec-Fetch-Site` header.

Automated model tests use controlled replies and a fixture provider plugin. Separately, Claude reported a live Gemini authentication/billing check: the requested older model returned an availability error, and a subsequent model request was blocked by depleted account credits. **No successful live model comparison was obtained.** Real model output quality, quotas, and compatibility still need evaluation with a configured, usable account or local model. Credentials were not added to the package.

## Handoff documentation pass

The final package adds a recipient handoff/checklist, a marketing reviewer walkthrough, and an operations runbook. Instructions were checked against launch scripts, configuration parsing, UI labels, persistence/cleanup behavior, and the API. All local Markdown links/anchors and documented npm commands were checked, and the architecture map includes every distributable file. Claude supplied an independent review of backend operating pitfalls.

This pass changes documentation and corrects the proxy's oversized-request error text to say 30 MB, matching its existing limit; it changes no comparison or persistence behavior. TypeScript passed again. The feature-freeze Python and integration results above were retained rather than rerun for documentation and message-only edits. The rebuilt 86-file ZIP is checked for archive integrity, required guides, exclusions, and byte-for-byte agreement with the final source.

## Tested optional package versions

| Package | Version |
|---|---|
| Pillow | 12.3.0 |
| pypdfium2 | 5.13.0 |
| pypdf | 6.19.0 |
| pytesseract | 0.3.13 |
| Tesseract executable | 5.5.3 |
| NumPy | 2.5.3 |
| scikit-image | 0.26.0 |
| SciPy | 1.18.1 |
| ImageIO | 2.37.4 |
| networkx | 3.6.1 |
| tifffile | 2026.9.15 |
| lazy-loader | 0.5 |

These are the versions tested on this machine, not an enterprise allowlist or a cross-platform Python lockfile. The npm lockfile is included. See [engine options](ENGINE_OPTIONS.md) for private repository installation and platform-specific dependency review.

## Remaining verification

- The browser checks cover key local workflows, not a full cross-browser or accessibility certification. Test on the organization's supported browsers and actual files.
- The optional WebMCP browser integration exposes `get_comparison_review` and `set_findings_reviewed` using the same UI state. It is feature-detected and has input validation and cleanup. No supported WebMCP context was available, so registration and live state transitions are **not verified**. Ordinary browser use does not depend on it.
- RapidOCR, EasyOCR, and PyMuPDF were not installed in these checks. Successful real vision inference remains unverified; see the account/API check above. Research-only engines are identified separately in the engine guide.
- Windows and Linux launch paths are implemented with Node/Python APIs, but execution was tested on macOS only.
- OCR may merge tightly kerned characters, misorder complex layouts, or miss small/low-contrast content. Pixel and SSIM findings can duplicate copy findings or flag expected rendering changes. Confidence values are heuristic evidence summaries, not probabilities or automatic approval.

For an acceptance exercise, use representative approved/produced pairs and deliberately introduce prices, dates, missing disclosures, punctuation, layout changes, and accepted exceptions. Compare the findings with human labels before using the result to support actual review work.
