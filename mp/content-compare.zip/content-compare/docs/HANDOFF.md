# Start here: team handoff

**Content Compare 0.2.0** is a local pilot for comparing an approved reference with a produced asset. Both inputs can be images or documents. It combines available comparison methods, applies content-specific rules, and keeps evidence for human review. Manual uploads and automated jobs use the same comparison pipeline.

The ZIP contains the application source, sample assets, examples, tests, and these guides. Recipients install dependencies on their own machines. It does not contain accounts, API keys, organization data, or installed models.

## Choose your starting point

| Your role | Read first | Next |
|---|---|---|
| Marketing reviewer or SME | [Reviewer guide](REVIEWER_GUIDE.md) | [Rules and examples](RULES.md) |
| Person installing or supporting the pilot | First launch below | [Operations and troubleshooting](OPERATIONS.md) |
| Test automation or integration developer | [Integration guide](INTEGRATIONS.md) | [Job/history/feedback API](../services/comparer/AUTOMATION_API.md), [comparison API](../services/comparer/API.md) |
| Developer taking over the code | [Interactive architecture map](ARCHITECTURE.html) | [Repository layout](../README.md#monorepo-layout), API contracts, tests |
| Enterprise package or platform reviewer | [Library choices and Artifactory setup](ENGINE_OPTIONS.md) | [Provider configuration](PROVIDERS.md), [validation and limits](VALIDATION.md) |

Open `ARCHITECTURE.html` directly in a browser; it works without running the app or accessing the internet. It explains workflow, infrastructure, code, components, tools, customization, and automation.

## First launch

1. Install **Node.js 22+** and **Python 3.10+** using your organization's normal process. Unzip the project and open a terminal in the folder containing `package.json`.
2. If your organization uses private npm/PyPI repositories, configure them **before installing**; follow [enterprise setup](ENGINE_OPTIONS.md#artifactory-configuration). The package list is not an internal approval list.
3. Run:

   ```sh
   npm ci
   npm run setup:python
   npm run doctor
   npm run dev
   ```

4. Open **http://127.0.0.1:3100**. Keep the terminal open. **Ctrl+C** stops both services.
5. For screenshot copy recognition, install the separate **Tesseract executable** as described in [the README](../README.md#run-it). The common Python profile installs its wrapper, not that executable. Confirm `ocr` is available in `npm run doctor` before expecting image-to-document copy checks.

No `.env` file or AI account is needed for local methods. If optional Python packages are prohibited, skip `setup:python` and start with the included TXT/DOCX pair. If Python itself is prohibited on reviewer machines, an operator must supply an approved comparer API; [web-only mode](OPERATIONS.md#start-stop-and-restart) runs the UI against it.

## First review and automation trial

1. Click **Try an example**, then **Compare files**. The synthetic image pair changes the rate from 4.25% to 4.75%, changes the CTA, and removes a disclosure. Which findings appear depends on available methods; inspect engine status and coverage, not just the headline verdict.
2. Click **Add rules → Try the sample's rules**, then compare again. Inspect **Base comparison**, **After rules**, and **Ignored**. The original evidence remains available.
3. Add a useful assessment under **Teach the next review**, click **Save feedback**, then reopen the run from **History** and confirm it was saved.
4. From a second terminal in the same folder, run `npm run demo:automation`. Follow the printed review URL; find the completed job in **Connections** and its result in **History**.
5. Export feedback using **History → Export review dataset**. This is local JSONL data for evaluation or training preparation; no model training or upload occurs.

For a trial without OCR, manually choose `approved-copy.txt` and `produced-copy.txt` from `apps/web/public/samples/`. DOCX counterparts are included. For folder intake, follow [the integration guide](INTEGRATIONS.md#quick-local-trial).

## Decide these settings for each organization

Copy `.env.example` to `.env` using your file manager or editor; keep it in the project root. Restart the app after changes. Do not send a filled-in `.env` with the source ZIP.

| Decision | Starting point | Owner to record |
|---|---|---|
| Team identity and visual style | Copy `config/organization.example.json` to `config/organization.json`; set `COMPARER_CONFIG=config/organization.json`. See [branding](INTEGRATIONS.md#organization-settings-and-restyling). | Brand/design owner |
| Permitted libraries | Choose the smallest useful profile supported by the organization's package repositories. | IT/package owner |
| Model processing | Optional. Configure an available vision model and endpoint, then enable it for intended runs. Provider/plugin setup is [documented here](PROVIDERS.md). | AI/platform owner |
| Source of approved references | Decide who supplies and versions each reference; the app does not choose a source of truth. | Content owner |
| Automated inputs | HTTP submission or folder manifests are included. Map reference/output pairs and stable build/config keys. | Test/integration owner |
| Rules and feedback | Export versioned rule profiles; name the SME who resolves conflicting reviews. | SME/review owner |
| Saved data and cleanup | SQLite is the default; JSON files are an alternative. Set retention and backup ownership before collecting real reviews. | Pilot operator |

**Automatic cleanup is on:** defaults are 30 days, 500 runs, and 2048 MB of saved run files, with oldest runs removed when a limit is reached. Feedback survives pruning by default. These limits do not bound all disk usage. Review **Connections → Preview cleanup** and [data operations](OPERATIONS.md#retention-and-cleanup) before relying on history as an archive.

## What is ready, and what needs integration work

| Included and implemented | Requires organization-specific work |
|---|---|
| Manual comparisons, annotations, structured rules, optional model guidance | A formal approval/sign-off workflow |
| HTTP jobs, folder intake, background execution, history | Connectors to an actual CI artifact system, cloud bucket, SharePoint, or DAM |
| Branding configuration and editable React/CSS | Each organization's final design and assets |
| Gemini, OpenAI-compatible, Anthropic, Ollama adapters; custom provider hook | A usable provider account or installed local vision model; validation of real model output |
| SQLite and JSON-file record stores; custom store hook | Other database adapters, migration, and remote artifact storage |
| Feedback capture and JSONL export | Dataset curation, provider-specific training format, training and deployment |
| Loopback local runtime | Central hosting, user authentication/authorization, tenant isolation, distributed workers |

The Python server is for local pilots. An integration token is not a user-login system. A shared organizational deployment needs a separately designed serving and access layer; see [operating boundaries](INTEGRATIONS.md#persistence-and-operating-boundaries).

## Recipient acceptance checklist

- [ ] Record the ZIP version, OS, `node --version`, Python version, and `npm run doctor` output.
- [ ] Confirm permitted packages install and the UI opens without service errors.
- [ ] Compare a known identical pair and a deliberately changed pair using the methods the team intends to use.
- [ ] Test each required file-pair direction with representative organization assets; inspect missing evidence and page caps.
- [ ] Apply a required-text rule and an allowed change; verify base evidence and ignored findings remain inspectable.
- [ ] Save feedback, restart, reopen the run, and export the review dataset.
- [ ] If automation is needed, submit a demo, verify the saved result, then connect one real producer using stable idempotency keys.
- [ ] If AI is needed, verify a successful response from the chosen model with approved sample content; configuration alone is not a successful model test.
- [ ] Record retention, backup location, restore procedure, support owner, and the team's remaining issues.

Completed development checks and unverified areas are in [VALIDATION.md](VALIDATION.md). macOS was exercised; Windows/Linux commands still require recipient testing. Live model comparison quality remains unverified. A clean automated test run does not establish accuracy on an organization's content.

## What to send, and how to report an issue

Send `dist/content-compare.zip` and point recipients to this guide. A browser-only reviewer can use an already configured installation and start with the reviewer guide. API credentials and private configuration should be supplied separately through the organization's normal mechanism.

For an issue, capture: version/OS, manual or automated flow, run/job ID, file types/page counts, enabled methods, rule profile revision, expected versus actual result, and the error text. Attach synthetic reproductions or approved sanitized files when possible. Remove credentials and sensitive copy from logs before sharing. The current terminal holds service logs; there is no bundled support portal.

To hand on a customized build, use [the release checklist](OPERATIONS.md#package-a-handoff). The source ZIP is separate from a private data backup.
