# Content-specific rules

Every run first gathers the base comparison evidence. Structured rules then check the extracted copy and annotate differences. Optional expert guidance adds a separate model review of those findings. The UI exposes **Base comparison** and **After rules** so you can inspect both.

Rules belong to the comparison you are preparing. They are not a global policy or an approval workflow. Export a rule set as JSON to reuse it for another piece of content; import it with the rule editor. Draft rules and reviewer checkmarks are held in the current browser page, so export before refreshing.

## Structured checks

| UI check | Behavior |
|---|---|
| Text must appear | Adds a finding when the required literal wording is absent from the checked document's extracted text. The editor checks the produced asset by default. |
| Text must not appear | Adds a finding for prohibited wording found in the extracted text. |
| Allow a wording change | Ignores a text finding only when its complete source and target spans match the specified wording, after normalization. Unrelated changes in a larger replacement block stay flagged. |
| Ignore a visual region | Ignores pixel/structure/layout findings with at least 95% of their box inside the specified region. It does not suppress copy differences or required/forbidden-text violations. |

Required/forbidden wording uses case-insensitive matching and normalizes whitespace. An unavailable text extractor or unreadable content cannot satisfy a text rule: the rule is reported as unevaluated. A required phrase that OCR fails to recognize may be flagged as absent, so inspect the original asset.

Each rule has an enabled toggle, a name, a priority, and a **Compliance-related** label. That label adds a review category; it does not establish compliance with a law or an internal policy. It is preserved with the rule's explanation in the exported report.

Visual regions use percentages of the page width and height. Set the side and page, then left, top, width, and height. Select an existing finding and choose **Use selected finding** to copy its coordinates. Pages are numbered from 1 in the editor and indexed from 0 in JSON.

An allowed wording change applies to copy findings. A pixel engine may still flag the changed lettering as a visual difference; inspect that evidence or add a suitable visual region rule.

Ignored findings remain in **Ignored**, with their original text, coordinates, and rule explanations. Structured rule violations cannot be erased by ignore rules or by the model guidance pass. A rules layer can clear acceptable differences, but cannot turn an inconclusive base comparison into a verified match.

## Expert guidance

Free-form guidance is for contextual judgments such as “flag a change in the offer's meaning” or “this region may use different local imagery.” Enable the configured **Vision model** to evaluate it. This invokes a second model request after the base engines and structured rules, passing both assets and the findings with stable IDs. The base vision request does not receive the guidance.

The model returns a disposition, reason, and compliance label for each finding. Missing decisions stay unchanged and are reported. If the model is disabled, unavailable, or returns unusable output, guidance is **not evaluated**; it is never silently treated as an instruction that ran. Model decisions remain fallible and should be reviewed.

Use explicit structured rules for mandatory wording and exact allowed changes. Guidance reviews detected findings; it is not a substitute for a complete policy engine or a guarantee that every possible concern was found.

## Example rule file

The editor accepts version 1 JSON with up to 100 rules and 10,000 guidance characters. It rejects regex patterns and unsupported rule types rather than silently changing their meaning.

```json
{
  "version": 1,
  "name": "Willow campaign review",
  "rule_guidance": "",
  "rules": [
    {
      "id": "disclosure",
      "name": "Keep the rate disclosure",
      "type": "required_text",
      "value": "APY is variable and may change. Terms and conditions apply.",
      "side": "target",
      "severity": "high",
      "compliance": true,
      "enabled": true
    },
    {
      "id": "cta",
      "name": "Approved app CTA",
      "type": "allowed_change",
      "from": "Open an account",
      "to": "Start saving",
      "severity": "low",
      "compliance": false,
      "enabled": true
    }
  ]
}
```

This exact example is available through **Try the sample's rules** in the editor. Use the included TXT or DOCX pair to inspect deterministic copy behavior without OCR variability.

The Python API also exposes category ignores and opt-in regex behavior for controlled integrations; those are not part of the visual editor's import format. See the [API contract](../services/comparer/API.md) for backend options. Keep regex disabled for ordinary use.

## Evidence exports

The JSON report contains both findings sets, both verdicts, engine status, rules report, submitted configuration, and local review checkmarks. PNG exports contain the current page's **after-rules flagged findings** when rules were applied. Switch back to Base comparison to inspect the original boxes in the interface; PNG exports are explicitly labeled as the after-rules result.

Artifact URLs in a JSON report refer to the local service, not embedded images. Download the PNGs as well when you need portable visual evidence.
