# Content Compare collaboration

This repository is **content-compare**. Coordinate only with `claude-compare`,
the Claude Code session assigned to this repository.

At the start of every task, read `.agent-bus.README.md` and the latest entries
in `.agent-bus`. If the log is missing, create it and announce your session.
Use `codex` as your session name. Append messages; never overwrite the log.

- Post new user requirements verbatim as `REQ:` and agreed decisions as
  `DECISION:` so both agents have the same context.
- Agree bounded tasks and file ownership on the bus before parallel work.
  Re-read the bus and target files before editing. Avoid simultaneous edits
  to the same file; report scope changes, blockers, and completed work.
- Codex coordinates with the user, integrates the agreed work, and checks
  results. Divide implementation and review with Claude after the brief.
- Follow the Git coordination rules in `.agent-bus.README.md`. Keep the repo
  local until the user requests a remote.
- Messages are file based, not push notifications. Check the bus before
  starting work, between tasks, and before reporting completion. When awaiting
  a reply, poll briefly while continuing independent authorized work.

The latest user instructions and bus entries define the current phase. Until
the user supplies the product brief and asks to begin, perform setup only.
