/** Framework-neutral client; Node 22+, no installed packages. */
import { readFile } from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";

export class CompareClient {
  constructor({ baseUrl = "http://127.0.0.1:8765", token = "" } = {}) {
    this.baseUrl = baseUrl.replace(/\/$/, ""); this.token = token;
  }
  async request(route, body) {
    const headers = { ...(body ? { "content-type": "application/json" } : {}), ...(this.token ? { authorization: `Bearer ${this.token}` } : {}) };
    const response = await fetch(`${this.baseUrl}/api/${route}`, { method: body ? "POST" : "GET", headers, ...(body ? { body: JSON.stringify(body) } : {}), redirect: "error", signal: AbortSignal.timeout(60000) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || `Request failed: ${response.status}`);
    return data;
  }
  async submit({ sourcePath, targetPath, options = { engines: ["text", "ocr", "pixel"] }, labels = {}, idempotencyKey }) {
    const [source, target] = await Promise.all([readFile(sourcePath), readFile(targetPath)]);
    return this.request("jobs", { source: { name: path.basename(sourcePath), content_base64: source.toString("base64") }, target: { name: path.basename(targetPath), content_base64: target.toString("base64") }, options, labels, idempotency_key: idempotencyKey });
  }
  async wait(jobId, { timeoutMs = 300000, intervalMs = 1000 } = {}) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const job = await this.request(`jobs/${encodeURIComponent(jobId)}`);
      if (["done", "failed", "cancelled"].includes(job.status)) return job;
      await new Promise(resolve => setTimeout(resolve, intervalMs));
    }
    throw new Error(`Job still running after ${timeoutMs / 1000}s; it remains in History / Connections: ${jobId}`);
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const [sourcePath, targetPath, idempotencyKey] = process.argv.slice(2);
  if (!sourcePath || !targetPath) { console.error("Usage: node examples/submit-job.mjs approved.png actual.png [unique-build-case-key]"); process.exitCode = 1; }
  else {
    const client = new CompareClient({ baseUrl: process.env.COMPARER_URL || `http://127.0.0.1:${process.env.COMPARER_PORT || "8765"}`, token: process.env.COMPARER_TOKEN });
    try {
      const submitted = await client.submit({ sourcePath, targetPath, idempotencyKey });
      console.log(JSON.stringify(submitted, null, 2));
      const job = await client.wait(submitted.job.id);
      console.log(JSON.stringify(job, null, 2));
      if (job.status !== "done") process.exitCode = 1;
    } catch (e) { console.error(e.message); process.exitCode = 1; }
  }
}
