"""Framework-neutral Python 3.10+ client; standard library only.

Use from Selenium/Robot or any producer after the screenshot is fully written.
"""
import argparse
import base64
import json
import os
from pathlib import Path
import time
from urllib.error import HTTPError
from urllib.request import Request, urlopen, build_opener, HTTPRedirectHandler


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class CompareClient:
    def __init__(self, base_url="http://127.0.0.1:8765", token=""):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.opener = build_opener(NoRedirect)

    def request(self, route, body=None):
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        req = Request(f"{self.base_url}/api/{route}", data=json.dumps(body).encode() if body is not None else None, headers=headers)
        try:
            with self.opener.open(req, timeout=60) as response:
                return json.load(response)
        except HTTPError as error:
            try:
                message = json.loads(error.read()).get("error", str(error))
            except (ValueError, AttributeError):
                message = str(error)
            raise RuntimeError(message) from error

    def submit(self, source_path, target_path, *, options=None, labels=None, idempotency_key=None):
        def file(path):
            path = Path(path)
            return {"name": path.name, "content_base64": base64.b64encode(path.read_bytes()).decode()}
        return self.request("jobs", {"source": file(source_path), "target": file(target_path), "options": options if options is not None else {"engines": ["text", "ocr", "pixel"]}, "labels": labels or {}, "idempotency_key": idempotency_key})

    def wait(self, job_id, timeout=300):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            job = self.request(f"jobs/{job_id}")
            if job["status"] in ("done", "failed", "cancelled"):
                return job
            time.sleep(1)
        raise TimeoutError(f"Job remains queued/running; inspect Connections: {job_id}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source")
    parser.add_argument("target")
    parser.add_argument("--key", help="Stable build/case key for duplicate submission protection")
    args = parser.parse_args()
    client = CompareClient(os.getenv("COMPARER_URL", "http://127.0.0.1:8765"), os.getenv("COMPARER_TOKEN", ""))
    result = client.submit(args.source, args.target, idempotency_key=args.key)
    print(json.dumps(result, indent=2))
    job = client.wait(result["job"]["id"])
    print(json.dumps(job, indent=2))
    raise SystemExit(0 if job["status"] == "done" else 1)
