"use client";

import { useRef, useState } from "react";
import { BookOpen, Download, Plus, ScanLine, Sparkles, Trash2, Upload, X } from "lucide-react";
import type { Finding, Rule, RuleProfile } from "@/lib/types";

const TYPES: { value: Rule["type"]; label: string }[] = [
  { value: "required_text", label: "Text must appear" },
  { value: "forbidden_text", label: "Text must not appear" },
  { value: "allowed_change", label: "Allow a wording change" },
  { value: "ignore_region", label: "Ignore a visual region" },
];

export function validateProfile(input: unknown): RuleProfile {
  if (!input || typeof input !== "object") throw new Error("Choose a rule-set JSON exported by Content Compare.");
  const data = input as Record<string, unknown>;
  if (data.version !== 1 || !Array.isArray(data.rules) || data.rules.length > 100) throw new Error("Rule sets must use version 1 and contain no more than 100 rules.");
  const ids = new Set<string>();
  const rules = data.rules.map((v: unknown, i: number): Rule => {
    if (!v || typeof v !== "object") throw new Error(`Rule ${i + 1} is invalid.`);
    const r = v as Record<string, unknown>;
    if ("pattern" in r) throw new Error(`Rule ${i + 1} uses a regex pattern. The visual editor supports literal text only.`);
    if (!TYPES.some(t => t.value === r.type)) throw new Error(`Rule ${i + 1} has an unsupported type.`);
    const id = typeof r.id === "string" && r.id ? r.id : `rule-${i + 1}`;
    if (ids.has(id)) throw new Error("Every rule needs a unique ID.");
    ids.add(id);
    const rule: Rule = { id, name: String(r.name || TYPES.find(t => t.value === r.type)?.label), type: r.type as Rule["type"], enabled: r.enabled !== false, severity: ["high", "medium", "low", "info"].includes(String(r.severity)) ? r.severity as Rule["severity"] : "medium", compliance: r.compliance === true, side: r.side === "source" ? "source" : "target", page: Number.isInteger(r.page) && Number(r.page) >= 0 ? Number(r.page) : 0 };
    for (const key of ["value", "from", "to"] as const) if (typeof r[key] === "string") rule[key] = r[key] as string;
    if (Array.isArray(r.bbox) && r.bbox.length === 4 && r.bbox.every(n => typeof n === "number" && Number.isFinite(n))) rule.bbox = r.bbox as Rule["bbox"];
    if (rule.enabled) {
      if (["required_text", "forbidden_text"].includes(rule.type) && !rule.value?.trim()) throw new Error(`“${rule.name}” needs the text to check.`);
      if (rule.type === "allowed_change" && (!rule.from?.trim() || !rule.to?.trim())) throw new Error(`“${rule.name}” needs both the reference and allowed wording.`);
      if (rule.type === "ignore_region") {
        const b = rule.bbox;
        if (!b || b[0] < 0 || b[1] < 0 || b[2] <= 0 || b[3] <= 0 || b[0] + b[2] > 1.00001 || b[1] + b[3] > 1.00001) throw new Error(`“${rule.name}” needs a region inside the page.`);
      }
    }
    return rule;
  });
  const guidance = typeof data.rule_guidance === "string" ? data.rule_guidance : "";
  if (guidance.length > 10000) throw new Error("Keep expert guidance under 10,000 characters.");
  return { version: 1, name: String(data.name || "Comparison rules"), rules, rule_guidance: guidance };
}

export default function RuleEditor({ profile, onChange, enabled, onToggle, disabled, selectedFinding, modelEnabled }: { profile: RuleProfile; onChange: (p: RuleProfile) => void; enabled: boolean; onToggle: () => void; disabled: boolean; selectedFinding?: Finding; modelEnabled: boolean }) {
  const [open, setOpen] = useState(false);
  const [error, setError] = useState("");
  const importRef = useRef<HTMLInputElement>(null);
  const update = (id: string, patch: Partial<Rule>) => onChange({ ...profile, rules: profile.rules.map(r => r.id === id ? { ...r, ...patch } : r) });
  const active = profile.rules.filter(r => r.enabled).length;
  function addRule() {
    onChange({ ...profile, rules: [...profile.rules, { id: crypto.randomUUID(), name: "", type: "required_text", value: "", side: "target", severity: "high", compliance: false, enabled: true }] });
    setOpen(true);
  }
  function example() {
    onChange({ version: 1, name: "Willow campaign review", rule_guidance: "", rules: [
      { id: "willow-disclosure", name: "Keep the rate disclosure", type: "required_text", value: "APY is variable and may change. Terms and conditions apply.", side: "target", severity: "high", compliance: true, enabled: true },
      { id: "willow-cta", name: "Approved app CTA", type: "allowed_change", from: "Open an account", to: "Start saving", severity: "low", compliance: false, enabled: true },
    ] }); setOpen(true);
  }
  function exportRules() {
    try {
      const safe = validateProfile(profile);
      const url = URL.createObjectURL(new Blob([JSON.stringify(safe, null, 2)], { type: "application/json" }));
      const a = document.createElement("a"); a.href = url; a.download = "content-compare-rules.json"; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000); setError("");
    } catch (e) { setError(e instanceof Error ? e.message : "Check the rule fields."); }
  }
  async function importRules(file?: File) {
    if (!file) return;
    try {
      if (file.size > 250000) throw new Error("Rule files must be smaller than 250 KB.");
      onChange(validateProfile(JSON.parse(await file.text()))); setOpen(true); setError("");
    } catch (e) { setError(e instanceof Error ? e.message : "This rule file is invalid."); }
  }
  return <section className={`rules-panel ${open ? "open" : ""}`} aria-labelledby="rules-title">
    <div className="rules-summary"><div className="rules-icon"><BookOpen size={18} /></div><button className="rules-summary-button" onClick={() => setOpen(!open)} aria-expanded={open} aria-controls="rules-editor"><strong id="rules-title">Add your expert eye.</strong><span>{active || profile.rule_guidance ? `${active} ${active === 1 ? "rule" : "rules"}${profile.rule_guidance ? " + expert guidance" : ""} · ${enabled ? "applied after the base comparison" : "not applied to this run"}` : "Optional rules tell us what matters, what is allowed, and what to ignore."}</span></button><button className="button secondary small" disabled={disabled} onClick={() => setOpen(!open)}>{open ? <X size={13} /> : <Plus size={13} />}{open ? "Close rules" : active ? "Edit rules" : "Add rules"}</button></div>
    {open && <div id="rules-editor" className="rules-editor">
      <div className="rule-set-toolbar"><label className="rule-set-name">RULE SET<input placeholder="e.g. Summer campaign · app version" value={profile.name} disabled={disabled} onChange={e => onChange({ ...profile, name: e.target.value })} /></label><div className="rule-file-actions"><input type="file" accept=".json" className="sr-only" ref={importRef} onChange={e => { void importRules(e.target.files?.[0]); e.target.value = ""; }} /><button className="text-button" disabled={disabled} onClick={() => importRef.current?.click()}><Upload size={13} />Import</button><button className="text-button" disabled={disabled || !profile.rules.length && !profile.rule_guidance} onClick={exportRules}><Download size={13} />Export</button></div></div>
      <div className="rule-intro"><span>Rules run after comparison. Original findings are always preserved.</span><label><input type="checkbox" checked={enabled} disabled={disabled} onChange={onToggle} />Apply this rule set</label></div>
      {!profile.rules.length && <div className="rules-empty"><p>A required disclosure. An approved CTA change. A region that always varies.</p><button className="text-button" disabled={disabled} onClick={example}><Sparkles size={13} />Try the sample’s rules</button></div>}
      <div className="rule-rows">{profile.rules.map((rule, i) => <div className={`rule-row ${!rule.enabled ? "rule-disabled" : ""}`} key={rule.id}>
        <div className="rule-row-header"><label className="rule-enable"><input type="checkbox" checked={rule.enabled} disabled={disabled} onChange={e => update(rule.id, { enabled: e.target.checked })} /><span>RULE {i + 1}</span></label><input className="rule-title-input" aria-label={`Rule ${i + 1} name`} placeholder="Give this rule a name" value={rule.name} disabled={disabled} onChange={e => update(rule.id, { name: e.target.value })} /><button className="icon-button" disabled={disabled} aria-label={`Delete rule ${i + 1}`} onClick={() => onChange({ ...profile, rules: profile.rules.filter(r => r.id !== rule.id) })}><Trash2 size={14} /></button></div>
        <div className="rule-fields"><label>Check<select value={rule.type} disabled={disabled} onChange={e => update(rule.id, { type: e.target.value as Rule["type"], bbox: rule.bbox || [0, 0, 0.2, 0.2], page: rule.page ?? 0 })}>{TYPES.map(t => <option value={t.value} key={t.value}>{t.label}</option>)}</select></label>
          {rule.type === "required_text" || rule.type === "forbidden_text" ? <label className="grow">{rule.type === "required_text" ? "Required wording" : "Wording to flag"}<input value={rule.value || ""} disabled={disabled} placeholder={rule.type === "required_text" ? "Terms and conditions apply." : "Guaranteed returns"} onChange={e => update(rule.id, { value: e.target.value })} /></label> : rule.type === "allowed_change" ? <><label className="grow">Reference wording<input value={rule.from || ""} disabled={disabled} placeholder="Open an account" onChange={e => update(rule.id, { from: e.target.value })} /></label><label className="grow">Allowed produced wording<input value={rule.to || ""} disabled={disabled} placeholder="Start saving" onChange={e => update(rule.id, { to: e.target.value })} /></label></> : <div className="region-fields"><label>Side<select disabled={disabled} value={rule.side || "target"} onChange={e => update(rule.id, { side: e.target.value as Rule["side"] })}><option value="target">Produced</option><option value="source">Reference</option></select></label><label>Page<input type="number" min="1" value={(rule.page ?? 0) + 1} disabled={disabled} onChange={e => update(rule.id, { page: Math.max(0, Number(e.target.value) - 1) })} /></label>{["Left %", "Top %", "Width %", "Height %"].map((label, j) => <label key={label}>{label}<input type="number" min="0" max="100" step="0.1" disabled={disabled} value={Math.round((rule.bbox?.[j] || 0) * 1000) / 10} onChange={e => { const box: [number, number, number, number] = [...(rule.bbox || [0, 0, 0.2, 0.2])]; box[j] = Number(e.target.value) / 100; update(rule.id, { bbox: box }); }} /></label>)}</div>}
        </div><div className="rule-row-footer"><label><input type="checkbox" disabled={disabled} checked={rule.compliance} onChange={e => update(rule.id, { compliance: e.target.checked })} />Compliance-related</label><label>Priority<select value={rule.severity} disabled={disabled} onChange={e => update(rule.id, { severity: e.target.value as Rule["severity"] })}><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option><option value="info">Info</option></select></label>{rule.type === "ignore_region" && <><span>Suppresses visual findings contained in this region, not text findings.</span><button className="text-button" disabled={disabled || !selectedFinding?.[rule.side || "target"]?.bbox} onClick={() => { const region = selectedFinding?.[rule.side || "target"]; if (region?.bbox) update(rule.id, { bbox: region.bbox, page: region.page }); }}><ScanLine size={12} />Use selected finding</button></>}</div>
      </div>)}</div>
      <button className="button secondary small add-rule" disabled={disabled || profile.rules.length >= 100} onClick={addRule}><Plus size={13} />Add a rule</button>
      <div className="expert-guidance"><label htmlFor="expert-guidance"><Sparkles size={15} /><strong>Expert guidance</strong><span>Optional · needs a vision model</span></label><textarea id="expert-guidance" maxLength={10000} rows={3} disabled={disabled} placeholder="e.g. Disclosures must remain complete. Ignore differences in the device’s status bar. Flag any change to the offer’s meaning as compliance-related." value={profile.rule_guidance} onChange={e => onChange({ ...profile, rule_guidance: e.target.value })} /><p>{modelEnabled ? "The configured model will use this guidance in a separate rules review. Check its reasoning before accepting a finding." : "Structured rules above work locally. Enable a configured vision model to evaluate this free-form guidance; otherwise it is reported as not evaluated."}</p></div>
      {error && <div className="notice error" role="alert">{error}</div>}
    </div>}
  </section>;
}
