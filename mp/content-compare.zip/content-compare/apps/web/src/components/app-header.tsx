"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { CircleHelp, History, Plug, ScanLine } from "lucide-react";
import { api } from "@/lib/api";
import type { PublicConfig } from "@/lib/types";

export default function AppHeader({ active }: { active: "compare" | "history" | "automation" }) {
  const [brand, setBrand] = useState<PublicConfig["brand"]>({ name: "Content Compare", accent: "#285d49" });
  useEffect(() => {
    let alive = true;
    api<PublicConfig>("config").then(config => {
      if (!alive) return;
      setBrand(config.brand);
      document.title = `${config.brand.name} · ${active === "compare" ? "Review" : active === "history" ? "History" : "Connections"}`;
      if (/^#[0-9a-f]{6}$/i.test(config.brand.accent)) {
        const style = document.documentElement.style;
        style.setProperty("--green", config.brand.accent);
        style.setProperty("--green-dark", `color-mix(in srgb, ${config.brand.accent}, black 22%)`);
        style.setProperty("--green-soft", `color-mix(in srgb, ${config.brand.accent} 8%, white)`);
        const channels = config.brand.accent.slice(1).match(/../g)!.map(c => {
          const v = parseInt(c, 16) / 255;
          return v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4;
        });
        style.setProperty("--on-accent", channels[0] * .2126 + channels[1] * .7152 + channels[2] * .0722 > .179 ? "#12221a" : "#ffffff");
      }
    }).catch(() => { /* Compare still works with the original service; status is shown in each page. */ });
    return () => { alive = false; };
  }, [active]);
  const logo = brand.logo_url && /^\/(?!\/)[a-zA-Z0-9/_.-]+$/.test(brand.logo_url) ? brand.logo_url : null;
  return <header className="topbar product-header">
    <a className="brand" href="/" aria-label={`${brand.name} home`}>{logo ? <img className="brand-logo" src={logo} alt="" /> : <span className="brand-mark"><ScanLine size={21} /></span>}<span>{brand.name}<span className="beta">BETA</span></span></a>
    <nav className="product-nav" aria-label="Workspace">
      <a href="/" aria-current={active === "compare" ? "page" : undefined}><ScanLine size={15} />Compare</a>
      <Link href="/history" aria-current={active === "history" ? "page" : undefined}><History size={15} />History</Link>
      <Link href="/automation" aria-current={active === "automation" ? "page" : undefined}><Plug size={15} />Connections</Link>
    </nav>
    <details className="help"><summary><CircleHelp size={17} /><span>How it works</span></summary><div className="help-popover"><strong>From approved to produced.</strong><p>Upload two files, or submit a job through a connected workflow.</p><p>Select a finding to locate it. Add feedback to capture your judgment, or reopen any saved comparison from History.</p><p>Review feedback is saved locally. Export it when you are ready to prepare an evaluation or training dataset.</p></div></details>
  </header>;
}
