"use client";

import { useEffect, useState } from "react";
import { Check, MessageSquare, Send } from "lucide-react";
import { api, dateLabel } from "@/lib/api";
import type { Feedback, FeedbackVerdict, Finding } from "@/lib/types";

const LABELS: Record<FeedbackVerdict, string> = { correct: "Correct finding", false_positive: "False positive", missed: "Missed an issue", wrong_severity: "Wrong priority", acceptable_difference: "Acceptable difference", other: "Other" };
export default function FeedbackPanel({ runId, findings, selected }: { runId?: string; findings: Finding[]; selected: string | null }) {
  const [feedback, setFeedback] = useState<Feedback[]>([]);
  const [findingId, setFindingId] = useState(selected || "");
  const [verdict, setVerdict] = useState<FeedbackVerdict>("correct");
  const [comment, setComment] = useState("");
  const [reviewer, setReviewer] = useState("");
  const [severity, setSeverity] = useState("");
  const [category, setCategory] = useState("");
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);
  useEffect(() => { setFindingId(selected || ""); setSaved(false); }, [selected]);
  useEffect(() => {
    setFeedback([]); setError(""); setSaved(false);
    if (!runId) return;
    const controller = new AbortController();
    api<Feedback[]>(`runs/${encodeURIComponent(runId)}/feedback`, { signal: controller.signal }).then(setFeedback).catch(e => { if (!controller.signal.aborted) setError(e.message); });
    return () => controller.abort();
  }, [runId]);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!runId || busy) return;
    setBusy(true); setError(""); setSaved(false);
    try {
      const item = await api<Feedback>(`runs/${encodeURIComponent(runId)}/feedback`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ finding_id: verdict === "missed" ? null : findingId || null, verdict, comment, reviewer, expected_severity: severity || null, expected_category: category || null }) });
      setFeedback(items => [...items, item]); setComment(""); setSaved(true);
    } catch (e) { setError(e instanceof Error ? e.message : "Could not save feedback."); }
    finally { setBusy(false); }
  }
  return <section className="feedback-panel" aria-labelledby="feedback-heading">
    <div className="section-title"><div><p className="eyebrow">HUMAN REVIEW</p><h2 id="feedback-heading"><MessageSquare size={19} />Teach the next review</h2><p>Capture what was right, what was missed, and what you would change.</p></div><span className="count-badge">{feedback.length} saved</span></div>
    {!runId ? <div className="notice warning">This comparison was not saved to history. Feedback needs a saved run; check the service status and compare again.</div> : <form onSubmit={submit}>
      <div className="feedback-grid">
        <label>What are you reviewing?<select value={findingId} disabled={verdict === "missed" || busy} onChange={e => { setFindingId(e.target.value); setSaved(false); }}><option value="">The overall comparison</option>{findings.map(f => <option key={f.id} value={f.id}>{f.id} · {f.message.slice(0, 110)}</option>)}</select></label>
        <label>Your assessment<select value={verdict} disabled={busy} onChange={e => { setVerdict(e.target.value as FeedbackVerdict); setSaved(false); }}>{Object.entries(LABELS).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>
        <label>Expected priority (optional)<select value={severity} onChange={e => setSeverity(e.target.value)} disabled={busy}><option value="">No correction</option>{["high", "medium", "low", "info"].map(v => <option key={v}>{v}</option>)}</select></label>
        <label>Reviewer (optional)<input value={reviewer} onChange={e => setReviewer(e.target.value)} maxLength={120} placeholder="Name or team" disabled={busy} /></label>
      </div>
      <div className="feedback-grid feedback-notes"><label>Review notes<textarea value={comment} maxLength={4000} onChange={e => { setComment(e.target.value); setSaved(false); }} placeholder={verdict === "missed" ? "Describe the missing issue, exact text, and page or region…" : "Explain the correction or why this difference is acceptable…"} required={verdict !== "correct"} disabled={busy} /></label><label>Expected category (optional)<select value={category} onChange={e => setCategory(e.target.value)} disabled={busy}><option value="">No correction</option>{["text_missing", "text_extra", "text_changed", "text_moved", "visual_diff", "layout_shift", "llm_observation", "rule_violation"].map(value => <option key={value} value={value}>{value.replaceAll("_", " ")}</option>)}</select><span className="field-note">Saved with the original finding and run context for later evaluation.</span></label></div>
      <div className="feedback-actions"><p>Saving feedback records your judgment. It does not change the comparison or train a model.</p><button type="submit" className="button primary" disabled={busy}><Send size={14} />{busy ? "Saving…" : "Save feedback"}</button></div>
      {saved && <p className="feedback-saved" role="status"><Check size={15} />Feedback saved to this run.</p>}
    </form>}
    {error && <div className="notice error" role="alert">{error}</div>}
    {feedback.length > 0 && <details className="feedback-log"><summary>Review history · {feedback.length} {feedback.length === 1 ? "entry" : "entries"}</summary>{[...feedback].reverse().map(item => <article key={item.id}><div><strong>{LABELS[item.verdict] || item.verdict}</strong><span>{item.finding_id || "Overall comparison"} · {item.reviewer || "Unnamed reviewer"} · {dateLabel(item.created_at)}</span></div>{item.comment && <p>{item.comment}</p>}{(item.expected_category || item.expected_severity) && <small>Expected: {[item.expected_category, item.expected_severity].filter(Boolean).join(" · ")}</small>}</article>)}</details>}
  </section>;
}
