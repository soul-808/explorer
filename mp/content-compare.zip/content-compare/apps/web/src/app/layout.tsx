import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Content Compare · Every word. Every detail.",
  description: "Compare approved marketing copy with the finished asset. Review text and visual differences side by side.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
