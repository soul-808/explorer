"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { ArrowRight, Download, History, RefreshCw, Search } from "lucide-react";
import AppHeader from "@/components/app-header";
import { api, dateLabel } from "@/lib/api";
import type { RunSummary } from "@/lib/types";

export default function HistoryPage() {
  const [runs, setRuns] = useState<RunSummary[]>([]);
  const [origin, setOrigin] = useState("");
  const [status, setStatus] = useState("");
  const [query, setQuery] = useState("");
  const [cursor, setCursor] = useState<string | null>(null);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState("");
  const [exporting, setExporting] = useState(false);
  const load = useCallback(async (next?: string, signal?: AbortSignal) => {
    setBusy(true); setError("");
    try {
      const params = new URLSearchParams({ limit: "50" });
      if (origin) params.set("origin", origin);
      if (status) params.set("status", status);
      if (next) params.set("cursor", next);
      const data = await api<{ runs: RunSummary[]; next_cursor: string | null }>(`runs?${params}`, { signal });
      if (signal?.aborted) return;
      setRuns(previous => next ? [...previous, ...data.runs.filter(r => !previous.some(old => old.id === r.id))] : data.runs);
      setCursor(data.next_cursor);
    } catch (e) { if (!signal?.aborted) setError(e instanceof Error ? e.message : "Could not load history."); }
    finally { if (!signal?.aborted) setBusy(false); }
  }, [origin, status]);
  useEffect(() => { const controller = new AbortController(); setRuns([]); void load(undefined, controller.signal); return () => controller.abort(); }, [load]);
  async function exportFeedback() {
    setExporting(true); setError("");
    try {
      const response = await fetch("/api/feedback/export?format=jsonl", { cache: "no-store" });
      if (!response.ok) { const data = await response.json(); throw new Error(data.error || "Feedback export failed."); }
      const blob = await response.blob();
      if (!blob.size) throw new Error("No feedback has been saved yet. Open a comparison and add your review first.");
      const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = `review-feedback-${new Date().toISOString().slice(0, 10)}.jsonl`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) { setError(e instanceof Error ? e.message : "Could not export feedback."); }
    finally { setExporting(false); }
  }
  const filtered = runs.filter(run => `${run.source_name} ${run.target_name} ${run.id} ${run.batch || ""} ${JSON.stringify(run.labels)}`.toLowerCase().includes(query.toLowerCase()));
  return <div className="app-shell"><AppHeader active="history" /><main className="collection-page">
    <section className="page-heading"><div><p className="eyebrow">YOUR REVIEW LIBRARY</p><h1>Every comparison, kept in context.</h1><p>Reopen manual uploads and automated runs, inspect the original evidence, and add feedback.</p></div><Link className="button primary" href="/">New comparison<ArrowRight size={15} /></Link></section>
    <div className="collection-toolbar"><label className="search-input"><Search size={15} /><input aria-label="Search loaded comparisons" placeholder="Search files, build, or labels…" value={query} onChange={e => setQuery(e.target.value)} /></label><label className="compact-select">Source<select aria-label="Filter comparison source" disabled={busy} value={origin} onChange={e => setOrigin(e.target.value)}><option value="">All sources</option><option value="manual">Manual uploads</option><option value="job">API jobs</option><option value="intake">Folder intake</option></select></label><label className="compact-select">Result<select aria-label="Filter comparison verdict" disabled={busy} value={status} onChange={e => setStatus(e.target.value)}><option value="">All results</option>{["match", "mismatch", "inconclusive"].map(s => <option key={s}>{s}</option>)}</select></label><button className="button secondary small" onClick={() => void load()} disabled={busy}><RefreshCw size={14} />Refresh</button></div>
    {error && <div className="notice error" role="alert">{error}</div>}
    {busy && <p className="loading-note" role="status">Loading saved comparisons…</p>}
    {!busy && !filtered.length && !error && <div className="collection-empty"><History size={34} /><h2>{runs.length ? "No comparisons match this search." : "Your review history starts here."}</h2><p>{runs.length ? "Try a different term, or load more comparisons." : "Upload two files in Compare, or submit a job from your test workflow. Completed results appear here."}</p><Link className="button secondary" href="/">Compare files</Link></div>}
    <div className="run-list">{filtered.map(run => <Link className="run-card" href={`/?run=${encodeURIComponent(run.id)}`} key={run.id}><div className="run-card-main"><div className="run-meta"><span className={`status-badge ${run.verdict.status}`}>{run.verdict.status === "match" ? "No flagged differences" : run.verdict.status === "mismatch" ? "Differences found" : "Needs more evidence"}</span><span>{run.origin === "manual" ? "Manual upload" : run.origin === "intake" ? "Folder intake" : "API job"}</span><time>{dateLabel(run.created_at)}</time></div><h2>{run.source_name}<ArrowRight size={15} /><span>{run.target_name}</span></h2><p>{run.verdict.summary}</p><div className="run-labels">{run.batch && <span>Batch: {run.batch}</span>}{Object.entries(run.labels || {}).map(([key, value]) => <span key={key}>{key}: {value}</span>)}</div></div><div className="run-counts"><strong>{run.counts.flagged}</strong><span>flagged · {run.counts.ignored} ignored</span><small>{run.feedback_count} feedback {run.feedback_count === 1 ? "entry" : "entries"}</small></div><ArrowRight size={18} /></Link>)}</div>
    {cursor && <div className="load-more"><button className="button secondary" disabled={busy} onClick={() => void load(cursor)}>Load older comparisons</button></div>}
    <div className="dataset-card"><div><h2>Turn review into better evaluations.</h2><p>Export all saved feedback as JSONL with findings and comparison context. Your team can curate it for evaluation or training in its own tools.</p><small>Includes reviewer-entered text and content excerpts. Export stays on this computer; no training runs automatically.</small></div><button className="button secondary" onClick={exportFeedback} disabled={exporting}><Download size={15} />{exporting ? "Preparing…" : "Export review dataset"}</button></div>
  </main></div>;
}
