"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { ArrowRight, Check, Database, FolderInput, Plug, RefreshCw, Server, X } from "lucide-react";
import AppHeader from "@/components/app-header";
import { api, dateLabel } from "@/lib/api";
import type { AutomationStatus, CleanupReport, Job, PublicConfig } from "@/lib/types";

export default function AutomationPage() {
  const [status, setStatus] = useState<AutomationStatus | null>(null);
  const [config, setConfig] = useState<PublicConfig | null>(null);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [jobFilter, setJobFilter] = useState("");
  const [updated, setUpdated] = useState("");
  const [cleanupPreview, setCleanupPreview] = useState<CleanupReport | null>(null);
  const refresh = useCallback(async (signal?: AbortSignal) => {
    try {
      const [state, settings, activity] = await Promise.all([api<AutomationStatus>("automation", { signal }), api<PublicConfig>("config", { signal }), api<{ jobs: Job[] }>(`jobs?limit=50${jobFilter ? `&status=${jobFilter}` : ""}`, { signal })]);
      if (signal?.aborted) return;
      setStatus(state); setConfig(settings); setJobs(activity.jobs); setUpdated(new Date().toISOString()); setError("");
    } catch (e) { if (!signal?.aborted) setError(e instanceof Error ? e.message : "Could not load connections."); }
  }, [jobFilter]);
  useEffect(() => {
    const controller = new AbortController();
    let inFlight = false;
    const poll = async () => { if (inFlight || document.hidden) return; inFlight = true; await refresh(controller.signal); inFlight = false; };
    void poll(); const timer = setInterval(() => void poll(), 5000);
    return () => { clearInterval(timer); controller.abort(); };
  }, [refresh]);
  async function action(path: string) {
    setBusy(true); setError("");
    try { await api(path, { method: "POST" }); await refresh(); }
    catch (e) { setError(e instanceof Error ? e.message : "Action failed."); }
    finally { setBusy(false); }
  }
  async function previewCleanup() {
    setBusy(true); setError(""); setCleanupPreview(null);
    try { setCleanupPreview(await api<CleanupReport>("automation/cleanup?dry_run=1", { method: "POST" })); }
    catch (e) { setError(e instanceof Error ? e.message : "Could not preview cleanup."); }
    finally { setBusy(false); }
  }
  return <div className="app-shell"><AppHeader active="automation" /><main className="collection-page">
    <section className="page-heading"><div><p className="eyebrow">OPTIONAL AUTOMATION</p><h1>Bring the work to your reviewers.</h1><p>Connect a screenshot workflow once. Completed comparisons join the same review history as manual uploads.</p></div><button className="button secondary" disabled={busy} onClick={() => void refresh()}><RefreshCw size={15} />Refresh status</button></section>
    {error && <div className="notice error" role="alert">{error}</div>}
    {config?.vision.error && <div className="notice warning" role="status"><strong>Model configuration:</strong> {config.vision.error}</div>}
    <div className="connection-flow"><span>Testing tools / asset sources</span><ArrowRight size={18} /><span>Files + manifest or HTTP job</span><ArrowRight size={18} /><span>Comparison + SME rules</span><ArrowRight size={18} /><Link href="/history">Review history + feedback</Link></div>
    <div className="connection-grid"><article><Server size={22} /><h2>Comparison worker</h2><span className={`status-badge ${status?.worker.running ? "match" : "inconclusive"}`}>{status ? status.worker.running ? "Running" : "Stopped" : "Connecting…"}</span><p>{status ? `${status.worker.workers} worker(s) · ${status.worker.queued} queued · ${status.worker.running_jobs} running` : "Waiting for the Python service."}</p><small>Jobs run in the background and are saved before execution.</small></article><article><FolderInput size={22} /><h2>Folder intake</h2><span className={`status-badge ${status?.intake.enabled ? "match" : "neutral"}`}>{status?.intake.enabled ? "Watching inbox" : "Not configured"}</span><p>{status?.intake.enabled ? `${status.intake.manifests_seen} manifests seen · last scan ${dateLabel(status.intake.last_poll)}` : "Set an inbox folder to pick up files automatically."}</p><button className="text-button" disabled={!status?.intake.enabled || busy} onClick={() => void action("automation/poll")}>Check inbox now<ArrowRight size={13} /></button></article><article><Database size={22} /><h2>Review storage</h2><span className={`status-badge ${status?.store.ok ? "match" : "inconclusive"}`}>{status?.store.kind || "Connecting…"}</span><p>{status ? `${status.store.runs} saved comparisons` : "Waiting for storage status."}</p><small>SQLite or JSON files locally; your organization can supply a storage adapter.</small></article></div>
    {(status?.intake.errors?.length || status?.errors?.length || status?.plugin_errors?.length) ? <div className="notice warning"><div>{[...(status?.intake.errors || []), ...(status?.errors || []), ...(status?.plugin_errors || [])].map((item, i) => <p key={i}>{typeof item === "string" ? item : JSON.stringify(item)}</p>)}</div></div> : null}
    {status?.cleanup && <section className="retention-card"><div><p className="eyebrow">STORAGE & RETENTION</p><h2>Keep the workspace manageable.</h2><p>{status.cleanup.data_dir_mb} MB stored · {status.cleanup.scratch_mb} MB scratch · last cleanup {dateLabel(status.cleanup.last?.at)}</p><div className="retention-limits"><span>History age: <strong>{status.cleanup.policy.retention_days ? `${status.cleanup.policy.retention_days} days` : "Unlimited"}</strong></span><span>Run count: <strong>{status.cleanup.policy.max_runs || "Unlimited"}</strong></span><span>Saved asset budget: <strong>{status.cleanup.policy.max_data_mb ? `${status.cleanup.policy.max_data_mb} MB` : "Unlimited"}</strong></span></div><p>Automatic cleanup prunes oldest runs at these limits. Feedback {status.cleanup.policy.keep_feedback_on_prune ? "is kept for dataset export" : "is removed with pruned runs"}. Configure the policy in your server settings.</p></div><button className="button secondary" disabled={busy} onClick={previewCleanup}>Preview cleanup</button>{cleanupPreview && <div className="cleanup-preview" role="status">{cleanupPreview.busy ? "A cleanup pass is already running. Try again shortly." : <><strong>Preview only · no files removed</strong><p>{cleanupPreview.runs_pruned?.length || 0} runs · {cleanupPreview.jobs_pruned?.length || 0} job records · {cleanupPreview.job_inputs_removed || 0} job input folders · {cleanupPreview.scratch_removed || 0} scratch folders · {cleanupPreview.orphans_removed || 0} orphan folders · {cleanupPreview.inbox_manifests_removed || 0} processed manifests</p>{cleanupPreview.errors?.map((e, i) => <p key={i}>{e}</p>)}</>}</div>}</section>}
    <section className="activity-section"><div className="section-title"><div><p className="eyebrow">LIVE ACTIVITY</p><h2>Background jobs</h2><p>Refreshes every 5 seconds while this page is visible. {updated && `Last updated ${dateLabel(updated)}.`}</p></div><label className="compact-select">Status<select aria-label="Filter jobs" value={jobFilter} onChange={e => setJobFilter(e.target.value)}><option value="">All jobs</option>{["queued", "running", "done", "failed", "cancelled"].map(v => <option key={v}>{v}</option>)}</select></label></div>
      {!jobs.length && !error && <div className="collection-empty compact"><Plug size={28} /><h2>No {jobFilter || "background"} jobs yet.</h2><p>Try the demo below, or keep comparing files manually.</p></div>}
      <div className="job-list">{jobs.map(job => <article className="job-row" key={job.id}><span className={`status-badge ${job.status === "done" ? "match" : job.status === "failed" ? "mismatch" : "neutral"}`}>{job.status === "done" && <Check size={12} />}{job.status}</span><div className="job-detail"><strong>{job.source_name}<ArrowRight size={13} />{job.target_name}</strong><p>{dateLabel(job.created_at)} · {job.origin} · attempt {job.attempts}{Object.entries(job.labels || {}).map(([k, v]) => ` · ${k}: ${v}`).join("")}</p>{job.error && <p className="job-error">{job.error}</p>}</div>{job.run_id && <Link className="text-button" href={`/?run=${encodeURIComponent(job.run_id)}`}>Open review<ArrowRight size={13} /></Link>}{job.status === "queued" && <button className="text-button" disabled={busy} onClick={() => void action(`jobs/${encodeURIComponent(job.id)}/cancel`)}><X size={13} />Cancel</button>}</article>)}</div>
    </section>
    <section className="setup-guides"><div className="section-title"><div><p className="eyebrow">CONNECT YOUR ENVIRONMENT</p><h2>Start small. Swap the adapters as you grow.</h2><p>The files and comparison options are the contract. Your testing tools stay independent.</p></div></div><div className="guide-grid"><article><span className="guide-number">01</span><h3>Try an automated run</h3><p>From the project folder, keep the app running and submit the included sample pair:</p><pre>npm run demo:automation</pre><p>The job will appear above, then open from History.</p></article><article><span className="guide-number">02</span><h3>Watch a screenshot folder</h3><p>Set <code>COMPARER_INBOX</code> in your root <code>.env</code> to an absolute folder path and restart the app. Produce a ready-to-read manifest:</p><pre>npm run demo:automation -- --inbox</pre><p>Replace the demo producer with your testing tool’s screenshot output.</p></article><article><span className="guide-number">03</span><h3>Use your organization’s tools</h3><p>Configure branding, model endpoints, storage, and optional library tiers in the included setup guide.</p><div className="config-summary"><span>Provider: {config?.vision.providers_configured.join(", ") || "Local comparison only"}</span><span>Model: {config?.vision.model_default || "None configured"}</span><span>Storage: {config?.store.kind || "Unavailable"}</span></div><p>See <code>docs/INTEGRATIONS.md</code> and <code>docs/ENGINE_OPTIONS.md</code> in your ZIP.</p></article></div></section>
  </main></div>;
}
