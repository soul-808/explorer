import { NextRequest } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const MAX_BODY = 30 * 1024 * 1024;

async function proxy(request: NextRequest, context: { params: Promise<{ path: string[] }> }) {
  const { path } = await context.params;
  const route = path.join("/");
  const allowed = request.method === "POST"
    ? ["compare", "jobs", "automation/poll", "automation/cleanup"].includes(route) || /^runs\/run_[a-zA-Z0-9_-]+\/feedback$/.test(route) || /^jobs\/job_[a-zA-Z0-9_-]+\/cancel$/.test(route)
    : ["health", "config", "runs", "jobs", "automation", "feedback/export"].includes(route)
      || /^artifacts\/[a-zA-Z0-9_-]+\/[a-zA-Z0-9_.-]+$/.test(route)
      || /^runs\/run_[a-zA-Z0-9_-]+(?:\/feedback|\/artifacts\/[a-zA-Z0-9_.-]+)?$/.test(route)
      || /^jobs\/job_[a-zA-Z0-9_-]+$/.test(route);
  if (!allowed) return Response.json({ error: "Not found" }, { status: 404 });
  // Use the browser-facing Host header: Next's internal URL may normalize 127.0.0.1 to
  // localhost. Preserve the full scheme/host/port boundary and reject malformed origins.
  const origin = request.headers.get("origin");
  if (request.method === "POST" && origin) {
    const host = request.headers.get("host");
    let sameOrigin = false;
    try {
      const supplied = new URL(origin);
      const expected = new URL(`${request.nextUrl.protocol}//${host}`);
      sameOrigin = Boolean(host) && ["http:", "https:"].includes(supplied.protocol)
        && supplied.origin === expected.origin && supplied.origin === origin;
    } catch { /* Reject malformed or opaque origins. */ }
    if (!sameOrigin) return Response.json({ error: "Cross-origin requests are not allowed" }, { status: 403 });
  }
  try {
    let body: Uint8Array | undefined;
    if (request.method === "POST") {
      if (Number(request.headers.get("content-length")) > MAX_BODY) {
        return Response.json({ error: "Keep the complete request body under 30 MB, including file encoding and options." }, { status: 413 });
      }
      const reader = request.body?.getReader();
      const chunks: Uint8Array[] = [];
      let size = 0;
      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          size += value.byteLength;
          if (size > MAX_BODY) {
            await reader.cancel();
            return Response.json({ error: "Keep the complete request body under 30 MB, including file encoding and options." }, { status: 413 });
          }
          chunks.push(value);
        }
      }
      body = new Uint8Array(size);
      let offset = 0;
      for (const chunk of chunks) { body.set(chunk, offset); offset += chunk.byteLength; }
    }
    const base = process.env.COMPARER_URL || "http://127.0.0.1:8765";
    const headers = new Headers();
    if (body) headers.set("content-type", request.headers.get("content-type") || "application/json");
    if (process.env.COMPARER_TOKEN) headers.set("authorization", `Bearer ${process.env.COMPARER_TOKEN}`);
    const response = await fetch(`${base.replace(/\/$/, "")}/api/${route}${request.nextUrl.search}`, {
      method: request.method,
      headers,
      redirect: "error",
      body: body as BodyInit | undefined,
      signal: AbortSignal.timeout(route === "health" ? 6000 : 300000),
      cache: "no-store",
    });
    return new Response(response.body, {
      status: response.status,
      headers: { "Content-Type": response.headers.get("content-type") || "application/json", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" },
    });
  } catch (error) {
    const timeout = error instanceof Error && /timeout|abort/i.test(error.name);
    return Response.json({ error: timeout ? "The comparison took too long. Try smaller files or fewer engines." :
      "The comparison service is offline. Start both services with npm run dev, then retry." }, { status: timeout ? 504 : 503 });
  }
}

export const GET = proxy;
export const POST = proxy;
