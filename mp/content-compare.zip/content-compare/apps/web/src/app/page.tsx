"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowLeftRight, ArrowRight, Check, ChevronLeft, ChevronRight, CircleHelp,
  Download, Eye, FileText, ImageIcon, Layers, LoaderCircle, Maximize2, Minus,
  Plus, RotateCcw, ScanLine, Search, Settings2, ShieldCheck, Sparkles,
  TriangleAlert, Upload, X,
} from "lucide-react";
import type { Asset, CompareOptions, CompareResult, Engine, EngineName, Finding, Health, Page, RuleProfile, SavedRun } from "@/lib/types";
import { useReviewTools } from "@/lib/review-tools";
import AppHeader from "@/components/app-header";
import FeedbackPanel from "@/components/feedback-panel";
import { api, dateLabel } from "@/lib/api";
import RuleEditor, { validateProfile } from "@/components/rule-editor";

type InputFile = { file: File; url: string; text?: string };
type Side = "source" | "target";
const ACCEPT = ".png,.jpg,.jpeg,.webp,.gif,.bmp,.tif,.tiff,.pdf,.docx,.txt,.md";
const DEFAULT_OPTIONS: CompareOptions = {
  engines: ["text", "ocr", "pixel", "ssim"],
  text: { ignore_case: false, ignore_whitespace: true, ignore_punctuation: false },
  pixel: { threshold: 32, min_region_px: 24 }, render_overlays: true,
};
const METHODS: { id: EngineName; label: string; detail: string }[] = [
  { id: "text", label: "Copy comparison", detail: "Find changed, missing, and extra words." },
  { id: "ocr", label: "Text recognition", detail: "Read copy inside images and scanned pages." },
  { id: "pixel", label: "Pixel comparison", detail: "Locate changes in color and artwork." },
  { id: "ssim", label: "Structural similarity", detail: "Compare the visual structure of each page." },
  { id: "vision_llm", label: "Vision model", detail: "Add a review from your configured AI provider." },
];
const CATEGORY: Record<string, { label: string; color: string; className: string }> = {
  text_missing: { label: "Missing copy", color: "#dc5157", className: "missing" },
  text_moved: { label: "Moved copy", color: "#0f766e", className: "layout" },
  text_extra: { label: "Extra copy", color: "#c47732", className: "extra" },
  text_changed: { label: "Changed copy", color: "#b48a17", className: "changed" },
  visual_diff: { label: "Visual difference", color: "#bd579d", className: "visual" },
  layout_shift: { label: "Layout change", color: "#8a6cbc", className: "layout" },
  rule_violation: { label: "Rule violation", color: "#b42318", className: "missing" },
  llm_observation: { label: "AI observation", color: "#5486ba", className: "ai" },
};
const methodLabel = (name: string) => METHODS.find(m => m.id === name || (name === "text_extract" && m.id === "text"))?.label || name;
const categoryInfo = (category: string) => CATEGORY[category] || { label: category.replaceAll("_", " "), color: "#60716b", className: "other" };
const sizeLabel = (bytes: number) => bytes >= 1024 * 1024 ? `${(bytes / 1024 / 1024).toFixed(1)} MB` : `${Math.ceil(bytes / 1024)} KB`;
const percent = (value: number) => `${Math.round(Math.max(0, Math.min(1, value)) * 100)}%`;
function download(content: Blob, name: string) {
  const url = URL.createObjectURL(content);
  const a = document.createElement("a"); a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export default function CompareWorkspace() {
  const [files, setFiles] = useState<Record<Side, InputFile | null>>({ source: null, target: null });
  const [health, setHealth] = useState<Health | null>(null);
  const [serviceError, setServiceError] = useState("");
  const [error, setError] = useState("");
  const [result, setResult] = useState<CompareResult | null>(null);
  const [savedRun, setSavedRun] = useState<SavedRun | null>(null);
  const [openingRun, setOpeningRun] = useState(false);
  const [busy, setBusy] = useState(false);
  const [loadingSample, setLoadingSample] = useState(false);
  const [settings, setSettings] = useState(false);
  const [options, setOptions] = useState<CompareOptions>(DEFAULT_OPTIONS);
  const [profile, setProfile] = useState<RuleProfile>({ version: 1, name: "", rules: [], rule_guidance: "" });
  const [applyRules, setApplyRules] = useState(true);
  const [stage, setStage] = useState<"base" | "rules">("base");
  const [submittedConfiguration, setSubmittedConfiguration] = useState("");
  const configuration = JSON.stringify({ options, profile, applyRules });
  const [selected, setSelected] = useState<string | null>(null);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [showBoxes, setShowBoxes] = useState(true);
  const [zoom, setZoom] = useState(100);
  const [pages, setPages] = useState<Record<Side, number>>({ source: 0, target: 0 });
  const [view, setView] = useState<"side" | "overlay">("side");
  const [opacity, setOpacity] = useState(50);
  const [reviewed, setReviewed] = useState<Set<string>>(new Set());
  const [isSample, setIsSample] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [exportError, setExportError] = useState("");
  const fileRefs = useRef(files);
  fileRefs.current = files;
  const abortRef = useRef<AbortController | null>(null);

  const refreshHealth = useCallback(async () => {
    try {
      const response = await fetch("/api/health", { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Comparison service unavailable");
      setHealth(data); setServiceError("");
    } catch (e) { setHealth(null); setServiceError(e instanceof Error ? e.message : "Comparison service unavailable"); }
  }, []);
  useEffect(() => { void refreshHealth(); }, [refreshHealth]);
  useEffect(() => {
    const id = new URLSearchParams(window.location.search).get("run");
    if (!id) return;
    const controller = new AbortController();
    setOpeningRun(true);
    api<SavedRun>(`runs/${encodeURIComponent(id)}`, { signal: controller.signal }).then(run => {
      if (controller.signal.aborted) return;
      setSavedRun(run); setResult({ ...run.result, run_id: run.id });
      setSubmittedConfiguration(JSON.stringify(run.options));
      setStage(run.result.rules_report?.rules.length || run.result.rules_report?.guidance.status === "evaluated" ? "rules" : "base");
      setPages({ source: run.result.source.pages[0]?.index ?? 0, target: run.result.target.pages[0]?.index ?? 0 });
    }).catch(e => { if (!controller.signal.aborted) setError(e.message); }).finally(() => { if (!controller.signal.aborted) setOpeningRun(false); });
    return () => controller.abort();
  }, []);
  useEffect(() => () => { Object.values(fileRefs.current).forEach(f => f && URL.revokeObjectURL(f.url)); abortRef.current?.abort(); }, []);
  useEffect(() => {
    if (!busy) return;
    setElapsed(0);
    const timer = setInterval(() => setElapsed(t => t + 1), 1000);
    return () => clearInterval(timer);
  }, [busy]);

  const resetResult = () => { setSavedRun(null); if (window.location.search) window.history.replaceState(null, "", "/"); setResult(null); setSelected(null); setReviewed(new Set()); setPages({ source: 0, target: 0 }); setView("side"); setFilter("all"); setSearch(""); setError(""); };
  async function prepareFile(file: File): Promise<InputFile> {
    if (!/\.(png|jpe?g|webp|gif|bmp|tiff?|pdf|docx|txt|md)$/i.test(file.name)) throw new Error("Choose an image, PDF, DOCX, or plain text file.");
    if (file.size > 10 * 1024 * 1024) throw new Error("Each file can be up to 10 MB. Please choose a smaller file.");
    if (!file.size) throw new Error("That file is empty. Please choose another file.");
    return { file, url: URL.createObjectURL(file), text: /\.(txt|md)$/i.test(file.name) ? await file.text() : undefined };
  }
  async function chooseFile(side: Side, file?: File) {
    if (!file || busy) return;
    try {
      const input = await prepareFile(file);
      const previous = fileRefs.current[side]; if (previous) URL.revokeObjectURL(previous.url);
      setFiles(current => ({ ...current, [side]: input })); setIsSample(false); resetResult();
    } catch (e) { setError(e instanceof Error ? e.message : "Could not open this file."); }
  }
  async function loadSample(kind: "image" | "mixed" = "image") {
    setLoadingSample(true); setError("");
    const prepared: InputFile[] = [];
    try {
      const names = [kind === "mixed" ? "approved-copy.docx" : "approved-design.png", "produced-screen.png"];
      for (const name of names) {
        const response = await fetch(`/samples/${name}`);
        if (!response.ok) throw new Error("Sample files could not be loaded.");
        prepared.push(await prepareFile(new File([await response.blob()], name, { type: response.headers.get("content-type") || "" })));
      }
      Object.values(fileRefs.current).forEach(f => f && URL.revokeObjectURL(f.url));
      setFiles({ source: prepared[0], target: prepared[1] }); resetResult(); setIsSample(true);
    } catch (e) { prepared.forEach(f => URL.revokeObjectURL(f.url)); setError(e instanceof Error ? e.message : "Could not load sample files."); }
    finally { setLoadingSample(false); }
  }
  function clearAll() {
    Object.values(fileRefs.current).forEach(f => f && URL.revokeObjectURL(f.url));
    setFiles({ source: null, target: null }); resetResult(); setIsSample(false);
  }
  async function compare() {
    if (!files.source || !files.target || busy) return;
    let safeProfile: RuleProfile;
    try { safeProfile = applyRules ? validateProfile(profile) : { ...profile, rules: [], rule_guidance: "" }; }
    catch (e) { setError(e instanceof Error ? e.message : "Check your rules before comparing."); return; }
    setBusy(true); resetResult(); setExportError("");
    setSubmittedConfiguration(configuration);
    const controller = new AbortController(); abortRef.current = controller;
    const timer = setTimeout(() => controller.abort("timeout"), 305000);
    try {
      const body = new FormData();
      body.append("source", files.source.file); body.append("target", files.target.file); body.append("options", JSON.stringify({ ...options, rules: safeProfile.rules, rule_guidance: safeProfile.rule_guidance }));
      const response = await fetch("/api/compare", { method: "POST", body, signal: controller.signal });
      const data = await response.json();
      if (!response.ok) throw new Error(typeof data.error === "string" ? data.error : data.error?.message || data.message || "Comparison failed. Please try again.");
      if (!data.verdict || !Array.isArray(data.findings)) throw new Error("The comparison service returned an unexpected response.");
      setResult(data);
      setStage(safeProfile.rules.length || safeProfile.rule_guidance ? "rules" : "base");
      const first: Finding | undefined = data.findings.find((f: Finding) => f.disposition !== "ignored");
      setSelected(first?.id || null);
      if (first) setPages({ source: first.source?.page ?? 0, target: first.target?.page ?? 0 });
    } catch (e) {
      setError(controller.signal.aborted ? controller.signal.reason === "timeout" ? "The comparison timed out. Try fewer pages or disable the vision model." : "Comparison canceled." : e instanceof Error ? e.message : "Could not complete the comparison.");
    } finally { clearTimeout(timer); setBusy(false); abortRef.current = null; void refreshHealth(); }
  }
  const selectFinding = (finding: Finding, scroll = false) => {
    setSelected(finding.id);
    setPages(p => ({ source: finding.source?.page ?? p.source, target: finding.target?.page ?? p.target }));
    if (scroll) {
      setFilter(stage === "rules" && finding.disposition === "ignored" ? "ignored" : "all"); setSearch("");
      requestAnimationFrame(() => document.getElementById(`finding-${finding.id}`)?.scrollIntoView({ behavior: "smooth", block: "nearest" }));
    }
  };
  const toggleEngine = (id: EngineName) => setOptions(o => ({ ...o, engines: o.engines.includes(id) ? o.engines.filter(e => e !== id) : [...o.engines, id] }));
  const runEngines = result?.engines || health?.engines || [];
  const findings = stage === "base" ? result?.base_findings || result?.findings || [] : result?.findings || [];
  const flagged = findings.filter(f => stage === "base" || f.disposition !== "ignored");
  const ignored = stage === "rules" ? findings.filter(f => f.disposition === "ignored") : [];
  const verdict = stage === "base" ? result?.base_verdict || result?.verdict : result?.verdict;
  const rulesRan = Boolean(result?.rules_report?.rules.length || result?.rules_report?.guidance.status !== "not_provided" && result?.rules_report);
  const warnings = result ? [...new Set([...(result.warnings || []), ...(result.stats.warnings || []), ...(result.source.notes || []).map(n => `Reference: ${n}`), ...(result.target.notes || []).map(n => `Produced: ${n}`)])] : [];
  const filtered = (filter === "ignored" ? ignored : flagged).filter(f => (filter === "all" || filter === "ignored" || filter === "unreviewed" && !reviewed.has(f.id) || filter === "copy" && f.category.startsWith("text_") || filter === "visual" && ["visual_diff", "layout_shift"].includes(f.category) || filter === "ai" && f.category === "llm_observation" || filter === "rules" && f.engine === "rules" || filter === "compliance" && f.rule_matches?.some(m => m.compliance)) && `${f.message} ${f.source?.text || ""} ${f.target?.text || ""} ${(f.rule_matches || []).map(m => `${m.rule_name} ${m.reason}`).join(" ")}`.toLowerCase().includes(search.toLowerCase()));
  const countCopy = flagged.filter(f => f.category.startsWith("text_")).length;
  const countVisual = flagged.filter(f => ["visual_diff", "layout_shift"].includes(f.category)).length;
  const countAI = flagged.filter(f => f.category === "llm_observation").length;
  const activeFinding = findings.find(f => f.id === selected);
  const canOverlay = Boolean(imageFor("source") && imageFor("target"));
  function pageFor(side: Side): Page | undefined { return result?.[side]?.pages?.find(p => p.index === pages[side]); }
  function imageFor(side: Side) {
    const page = pageFor(side);
    if (page?.image_url) return page.image_url;
    const input = files[side];
    return input && /\.(png|jpe?g|webp|gif|bmp|tiff?)$/i.test(input.file.name) ? input.url : undefined;
  }
  const report = () => {
    if (!result) return;
    download(new Blob([JSON.stringify({ ...result, applied_configuration: JSON.parse(submittedConfiguration || "{}"), review: { reviewed_finding_ids: [...reviewed], exported_at: new Date().toISOString(), note: "Reviewer checkmarks are local triage, not approval or sign-off." } }, null, 2)], { type: "application/json" }), `content-compare-${result.id}.json`);
  };
  const exportAnnotated = async (side: Side) => {
    setExportError("");
    const overlay = result?.overlays?.[side]?.find(o => o.page === pages[side]);
    if (!overlay) { setExportError("Annotated image export needs the optional Pillow package. You can still export the JSON report."); return; }
    try {
      const response = await fetch(overlay.image_url);
      if (!response.ok) throw new Error("Could not download the annotated image.");
      download(await response.blob(), `${side}-page-${pages[side] + 1}-annotated.png`);
    } catch (e) { setExportError(e instanceof Error ? e.message : "Download failed."); }
  };

  useReviewTools({ result, stage, reviewed, busy, setReviewed });

  return <div className="app-shell">
    <AppHeader active="compare" />

    <main>
      <div className="breadcrumb"><Layers size={14} /> Workspace <span>/</span> <strong>{savedRun ? "Saved comparison" : "New comparison"}</strong></div>
      {openingRun && <p className="loading-note" role="status">Opening saved comparison…</p>}
      {savedRun && <div className="saved-run-banner"><div><strong>Saved review · {dateLabel(savedRun.created_at)}</strong><p>{savedRun.source_name} → {savedRun.target_name} · {savedRun.origin === "manual" ? "Manual upload" : savedRun.origin === "intake" ? "Folder intake" : "API job"}</p><small>{Object.entries(savedRun.labels || {}).map(([key, value]) => `${key}: ${value}`).join(" · ")}</small></div><button className="button secondary small" onClick={clearAll}>Start a new comparison</button></div>}
      {!savedRun && <>
      <section className="page-heading">
        <div><div className="eyebrow">CREATIVE PROOFING, SIMPLIFIED</div><h1>A second look at every detail.</h1><p>Compare approved copy with what was produced. Find what changed, in one clear view.</p></div>
        <button className={`button secondary ${settings ? "pressed" : ""}`} onClick={() => setSettings(!settings)} aria-expanded={settings} aria-controls="comparison-settings"><Settings2 size={16} /> Comparison methods</button>
      </section>

      {settings && <section className="settings-panel" id="comparison-settings">
        <div className="settings-title"><div><h2>Your comparison toolkit</h2><p>Use any combination. Unavailable methods are skipped and reported.</p></div><button className="icon-button" onClick={() => setSettings(false)} aria-label="Close comparison methods"><X size={18} /></button></div>
        <div className="method-options">{METHODS.map(m => {
          const engine = health?.engines.find(e => e.name === m.id || m.id === "text" && e.name === "text_extract");
          return <label key={m.id} className={`method-option ${options.engines.includes(m.id) ? "enabled" : ""}`}><input type="checkbox" checked={options.engines.includes(m.id)} disabled={busy} onChange={() => toggleEngine(m.id)} /><div><strong>{m.label}</strong><p>{m.detail}</p><span className={`availability ${engine?.status === "ok" ? "available" : ""}`}>{engine?.status === "ok" ? `Available${engine.backend ? ` · ${engine.backend}` : ""}` : engine?.status === "skipped" ? "Not configured" : engine?.status === "unavailable" ? "Not installed" : "Checking availability"}</span></div></label>;
        })}</div>
        <div className="fine-settings"><div><span className="control-label">Copy rules</span><span className="spacing-note">Spacing and line breaks are normalized</span><label><input type="checkbox" disabled={busy} checked={options.text.ignore_case} onChange={e => setOptions(o => ({ ...o, text: { ...o.text, ignore_case: e.target.checked } }))} /> Ignore capitalization</label><label><input type="checkbox" disabled={busy} checked={options.text.ignore_punctuation} onChange={e => setOptions(o => ({ ...o, text: { ...o.text, ignore_punctuation: e.target.checked } }))} /> Ignore punctuation</label></div><label className="sensitivity"><span className="control-label">Pixel tolerance <strong>{options.pixel.threshold}</strong></span><input type="range" min="5" max="100" disabled={busy} value={options.pixel.threshold} onChange={e => setOptions(o => ({ ...o, pixel: { ...o.pixel, threshold: Number(e.target.value) } }))} /><span>Lower catches smaller changes.</span></label></div>
        {options.engines.includes("vision_llm") && <div className="settings-note"><Sparkles size={15} /><span>Vision review sends your selected files to the provider configured on the Python service. Use a local vision model to keep processing on your machine. Provider credentials stay on the server.</span></div>}
      </section>}

      <div className="setup-row"><div className="step-label"><span className="step-number">01</span><h2>Your two files</h2>{isSample && <span className="sample-badge">Sample files</span>}</div><div className="sample-actions"><span>Just exploring?</span><button className="text-button" onClick={() => loadSample("image")} disabled={busy || loadingSample || openingRun}>{loadingSample ? <LoaderCircle size={14} className="spin" /> : <Sparkles size={14} />}Try an example</button><details className="sample-menu"><summary aria-label="Other sample formats"><ChevronRight size={14} /></summary><div><button disabled={busy || loadingSample || openingRun} onClick={() => loadSample("mixed")}>DOCX vs. screenshot</button></div></details></div></div>

      <div className="upload-row">
        {(["source", "target"] as Side[]).map((side, index) => <FileSlot key={side} side={side} input={files[side]} disabled={busy || loadingSample || openingRun} onChoose={file => chooseFile(side, file)} onRemove={() => { const f = files[side]; if (f) URL.revokeObjectURL(f.url); setFiles(current => ({ ...current, [side]: null })); resetResult(); setIsSample(false); }} number={index + 1} />)}
        <button className="swap-button" title="Swap reference and produced files" aria-label="Swap reference and produced files" disabled={busy || !files.source || !files.target} onClick={() => { setFiles(f => ({ source: f.target, target: f.source })); resetResult(); }}><ArrowLeftRight size={16} /></button>
      </div>

      <RuleEditor profile={profile} onChange={setProfile} enabled={applyRules} onToggle={() => setApplyRules(!applyRules)} disabled={busy || loadingSample || openingRun} selectedFinding={activeFinding} modelEnabled={options.engines.includes("vision_llm")} />
      {result && configuration !== submittedConfiguration && <div className="notice warning">Your methods or rules have changed. Run the comparison again to apply them; the results below are from the previous run.</div>}
      <div className="run-bar"><div className="privacy-note"><ShieldCheck size={16} /><span>{options.engines.includes("vision_llm") ? "Vision review enabled · configured provider may receive files" : "Local methods selected · no files sent to an AI provider"}</span></div><div className="run-actions">{(files.source || files.target) && <button className="text-button muted" onClick={clearAll} disabled={busy}><RotateCcw size={14} />Reset</button>}{busy ? <><span className="elapsed">{elapsed}s</span><button className="button secondary" onClick={() => abortRef.current?.abort()}><X size={15} />Cancel</button><button className="button primary" disabled><LoaderCircle size={16} className="spin" />Comparing files</button></> : <button className="button primary" onClick={compare} disabled={!files.source || !files.target || !options.engines.length || loadingSample}>Compare files<ArrowRight size={17} /></button>}</div></div>
      </>}
      {savedRun && <details className="saved-configuration"><summary>Methods and rules used in this run</summary><pre>{JSON.stringify(savedRun.options, null, 2)}</pre></details>}
      {(error || serviceError) && <div className="notice error" role="alert"><TriangleAlert size={17} /><span>{error || serviceError}</span>{serviceError && <button className="text-button" onClick={refreshHealth}>Reconnect</button>}</div>}

      {result && <div className="stage-tabs" role="tablist" aria-label="Comparison stage"><button role="tab" aria-selected={stage === "base"} className={stage === "base" ? "active" : ""} onClick={() => { setStage("base"); setFilter("all"); setSelected(null); }}><ScanLine size={15} />Base comparison<span>{result.base_findings?.length ?? result.findings.length}</span></button><ArrowRight size={14} /><button role="tab" aria-selected={stage === "rules"} disabled={!rulesRan} className={stage === "rules" ? "active" : ""} onClick={() => { setStage("rules"); setFilter("all"); setSelected(null); }}><ShieldCheck size={15} />After rules<span>{result.rules_report?.counts.flagged ?? result.findings.length}</span></button><p>{stage === "base" ? "Original evidence, before any rules" : `${ignored.length} ignored by rules · original evidence preserved`}</p></div>}
      <section className={`comparison-workspace ${busy ? "is-comparing" : ""}`} aria-busy={busy}>
        <div className="workspace-toolbar"><div className="view-tabs"><button className={view === "side" ? "active" : ""} onClick={() => setView("side")}><Layers size={15} />Side by side</button><button className={view === "overlay" ? "active" : ""} onClick={() => setView("overlay")} disabled={!canOverlay}><Eye size={15} />Overlay</button></div><div className="canvas-controls"><button className={`icon-button ${showBoxes ? "selected" : ""}`} onClick={() => setShowBoxes(!showBoxes)} aria-label={showBoxes ? "Hide difference boxes" : "Show difference boxes"} title="Toggle difference boxes"><ScanLine size={16} /></button><span className="toolbar-divider" /><button className="icon-button" onClick={() => setZoom(z => Math.max(50, z - 25))} disabled={zoom <= 50} aria-label="Zoom out"><Minus size={15} /></button><span className="zoom-label">{zoom}%</span><button className="icon-button" onClick={() => setZoom(z => Math.min(200, z + 25))} disabled={zoom >= 200} aria-label="Zoom in"><Plus size={15} /></button><button className="icon-button" onClick={() => setZoom(100)} aria-label="Fit previews to width" title="Fit to width"><Maximize2 size={15} /></button></div></div>
        {view === "side" ? <div className="preview-pair">{(["source", "target"] as Side[]).map(side => <Preview key={side} side={side} input={files[side]} asset={result?.[side]} currentPage={pages[side]} page={pageFor(side)} image={imageFor(side)} zoom={zoom} findings={filter === "ignored" ? ignored : flagged} selected={selected} showBoxes={showBoxes} legend={result?.legend || {}} onSelect={f => selectFinding(f, true)} onPage={n => setPages(p => ({ ...p, [side]: n }))} />)}</div> : <div className="overlay-view"><div className="overlay-caption"><span>Reference</span><input aria-label="Produced image overlay opacity" type="range" min="0" max="100" value={opacity} onChange={e => setOpacity(Number(e.target.value))} /><span>Produced {opacity}%</span></div><p>Overlay scales both pages to the reference canvas. Use side by side to inspect different layouts.</p><div className="overlay-scroll"><div className="overlay-canvas" style={{ width: `${zoom}%` }}><img src={imageFor("source")} alt="Reference for overlay comparison" /><img className="overlay-target" src={imageFor("target")} alt="Produced file overlay" style={{ opacity: opacity / 100 }} /></div></div></div>}
        <div className="workspace-bottom"><div className="legend"><span className="legend-title">DIFFERENCE KEY</span>{["text_missing", "text_changed", "visual_diff", "llm_observation"].map(key => <span key={key}><i style={{ background: result?.legend?.[key] || CATEGORY[key].color }} />{CATEGORY[key].label}</span>)}</div><span className="workspace-hint">{result ? "Select a finding to locate it on the page" : "Your files will appear here"}</span></div>
        {busy && <div className="processing-strip" role="status"><LoaderCircle className="spin" size={15} />Reading your files and checking for differences<span>Results will appear when the selected methods finish.</span></div>}
      </section>

      <section className="results-section" aria-labelledby="findings-heading">
        <div className="results-heading"><div className="step-label"><span className="step-number">02</span><h2 id="findings-heading">Review the differences</h2>{result && <span className="count-badge">{flagged.length}</span>}</div><div className="report-actions">{result && <><span className="review-progress">{flagged.filter(f => reviewed.has(f.id)).length} of {flagged.length} reviewed</span><button className="button secondary small" onClick={report}><Download size={14} />Export report</button></>}</div></div>
        {!result ? <div className="empty-results"><span className="empty-results-icon"><ScanLine size={25} /></span><div><h3>{busy ? "A closer look is in progress." : "A clear picture of what changed."}</h3><p>{busy ? "Each available method contributes its findings to this review." : "Run a comparison to see copy changes, missing details, and visual differences here."}</p></div><div className="empty-example"><span className="example-line"><i /> Changed headline</span><span className="example-line"><i /> Missing disclosure</span><span className="example-line"><i /> Visual difference</span></div></div> : <>
          <div className={`verdict-strip ${verdict?.status}`} role="status"><span className="verdict-icon">{verdict?.status === "match" ? <Check size={19} /> : <TriangleAlert size={19} />}</span><div><strong>{verdict?.status === "match" ? stage === "rules" && ignored.length ? "No remaining flagged differences after rules" : flagged.length ? "Informational observations to review" : "No differences found by the methods that ran" : verdict?.status === "inconclusive" ? "This comparison needs more evidence" : `${flagged.length} ${flagged.length === 1 ? "finding" : "findings"} to take a closer look at`}</strong><p>{verdict?.summary}</p></div><div className="evidence-summary"><strong>{result.stats.engines_ran}</strong><span>methods ran</span></div></div>
          {warnings.length ? <div className="notice warning"><TriangleAlert size={15} /><div>{warnings.map((warning, i) => <p key={i}>{warning}</p>)}</div></div> : null}
          {stage === "rules" && result.rules_report && <div className="rules-outcome"><div className="rules-outcome-heading"><ShieldCheck size={15} /><strong>Rule-by-rule review</strong><span>{result.rules_report.counts.ignored} ignored · {result.rules_report.counts.added} added · {result.rules_report.counts.compliance_flagged} compliance-related</span></div>{result.rules_report.rules.map((r, i) => <div className={`rule-outcome-row ${r.status}`} key={`${r.rule_id}-${i}`}><strong>{r.name || r.rule_id}</strong><span>{r.reason || `${r.matches || 0} matching findings`}</span><small>{r.status.replaceAll("_", " ")}</small></div>)}{result.rules_report.guidance.status !== "not_provided" && <div className={`guidance-outcome ${result.rules_report.guidance.status}`}><Sparkles size={14} /><strong>Expert guidance: {result.rules_report.guidance.status === "evaluated" ? "evaluated" : result.rules_report.guidance.status === "skipped" ? "not run" : "not evaluated"}</strong><span>{result.rules_report.guidance.reason}{result.rules_report.guidance.missing?.length ? ` · ${result.rules_report.guidance.missing.length} findings were not evaluated by the model.` : ""}</span></div>}</div>}
          <div className="findings-toolbar"><div className="filter-tabs">{[{ key: "all", label: "Flagged", count: flagged.length }, { key: "copy", label: "Copy", count: countCopy }, { key: "visual", label: "Visual", count: countVisual }, ...(countAI ? [{ key: "ai", label: "AI", count: countAI }] : []), { key: "unreviewed", label: "To review", count: flagged.filter(f => !reviewed.has(f.id)).length }, ...(stage === "rules" ? [{ key: "compliance", label: "Compliance", count: flagged.filter(f => f.rule_matches?.some(m => m.compliance)).length }, { key: "ignored", label: "Ignored", count: ignored.length }] : [])].map(item => <button key={item.key} className={filter === item.key ? "active" : ""} onClick={() => setFilter(item.key)}>{item.label}<span>{item.count}</span></button>)}</div><label className="search-input"><Search size={15} /><input aria-label="Search findings" placeholder="Search findings…" value={search} onChange={e => setSearch(e.target.value)} /></label></div>
          {filtered.length > 0 ? <div className="findings-list">{filtered.map(f => {
            const info = categoryInfo(f.category); const index = Number(f.id.replace(/^f/, "")) || findings.indexOf(f) + 1;
            return <article id={`finding-${f.id}`} key={f.id} className={`finding ${selected === f.id ? "active" : ""} ${reviewed.has(f.id) ? "reviewed" : ""} ${f.disposition === "ignored" && stage === "rules" ? "ignored-finding" : ""}`}>
              <button className="finding-main" onClick={() => selectFinding(f)} aria-pressed={selected === f.id}><span className="finding-number" style={{ color: info.color, background: `${info.color}14` }}>{index.toString().padStart(2, "0")}</span><div className="finding-content"><div className="finding-meta"><span className={`category-tag ${info.className}`}>{info.label}</span><span className={`severity ${f.severity}`}>{f.severity === "high" ? "High priority" : f.severity === "medium" ? "Review" : f.severity === "low" ? "Minor" : "For context"}</span><span>{methodLabel(f.engine)}</span><span title="Heuristic confidence, not a calibrated probability">{percent(f.confidence)} confidence estimate</span></div><h3>{f.message}</h3>{stage === "rules" && f.rule_matches?.map((match, i) => <div className="rule-reason" key={`${match.rule_id}-${i}`}><ShieldCheck size={12} /><span><strong>{match.rule_name}</strong>{match.compliance && <em>Compliance</em>} · {match.reason}</span>{f.disposition === "ignored" && <small>Ignored</small>}</div>)}{(f.source?.text || f.target?.text) && <div className="copy-difference"><span><small>REFERENCE</small>{f.source?.text || <em>Not present</em>}</span><ArrowRight size={14} /><span><small>PRODUCED</small>{f.target?.text || <em>Not present</em>}</span></div>}</div><span className="finding-page">{f.source?.page != null || f.target?.page != null ? `Page ${(f.target?.page ?? f.source?.page ?? 0) + 1}` : "File level"}<ChevronRight size={15} /></span></button>
              <button className={`review-check ${reviewed.has(f.id) ? "checked" : ""}`} title={reviewed.has(f.id) ? "Clear session checkmark (use feedback below to save a review)" : "Mark reviewed for this session (use feedback below to save a review)"} aria-label={`${reviewed.has(f.id) ? "Unmark" : "Mark"} finding ${index} reviewed`} aria-pressed={reviewed.has(f.id)} onClick={() => setReviewed(previous => { const next = new Set(previous); if (next.has(f.id)) next.delete(f.id); else next.add(f.id); return next; })}>{reviewed.has(f.id) && <Check size={14} />}</button>
            </article>;
          })}</div> : <div className="no-findings"><Check size={23} /><h3>{findings.length ? "Nothing in this view." : verdict?.status === "inconclusive" ? "No findings could be established." : "No differences detected."}</h3><p>{findings.length ? "Try another filter or search term." : verdict?.status === "inconclusive" ? "Check the methods below, enable one that can read these files, and compare again." : "This result covers only the methods that ran. Give the assets a final human review."}</p></div>}
          {activeFinding && !activeFinding.source?.bbox && !activeFinding.target?.bbox && <p className="geometry-note"><FileText size={14} />This finding has no page coordinates. Review its text in the list above.</p>}
          <div className="export-images"><span><Download size={14} />Take the annotations with you</span><button className="text-button" onClick={() => exportAnnotated("source")} disabled={!result.overlays?.source?.length}>Reference PNG</button><button className="text-button" onClick={() => exportAnnotated("target")} disabled={!result.overlays?.target?.length}>Produced PNG</button><span className="export-note">Current page · {rulesRan ? "after-rules flagged findings" : "flagged findings"}</span></div>
          {exportError && <div className="notice error" role="alert">{exportError}</div>}
        </>}
      </section>

      {result && <FeedbackPanel key={result.id} runId={result.run_id} selected={selected} findings={[...new Map([...(result.base_findings || []), ...result.findings].map(f => [f.id, f])).values()]} />}
      <section className="engine-section"><div className="engine-heading"><div><ShieldCheck size={16} /><strong>{result ? "What informed this comparison" : "Ready for your environment"}</strong></div><span>{result ? "Every method reports its own status" : "Available methods are detected automatically"}</span></div><div className="engine-chips">{METHODS.map(m => { const engine: Engine | undefined = runEngines.find(e => e.name === m.id || m.id === "text" && e.name === "text_extract"); const status = engine?.status; return <div className={`engine-chip ${status || "unknown"}`} key={m.id} title={engine?.message || engine?.backend || m.detail}>{status === "ok" ? <Check size={13} /> : status === "failed" ? <TriangleAlert size={13} /> : <span className="engine-dot" />}<span>{m.label}</span><small>{status === "ok" ? result ? "Ran" : "Available" : status === "failed" ? "Failed" : status === "skipped" ? "Skipped" : status === "unavailable" ? "Unavailable" : "Offline"}</small></div>; })}</div>{result && <div className="engine-notes">{result.engines.filter(e => e.status !== "ok" && e.message).map(e => <p key={e.name}><strong>{methodLabel(e.name)}:</strong> {e.message}</p>)}</div>}</section>
      <footer className="footer"><span><ScanLine size={13} />Content Compare <span className="footer-dot">·</span> Built for a closer look.</span><span>Findings assist review. They do not constitute approval.</span></footer>
    </main>
  </div>;
}

function FileSlot({ side, input, disabled, onChoose, onRemove, number }: { side: Side; input: InputFile | null; disabled: boolean; onChoose: (f?: File) => void; onRemove: () => void; number: number }) {
  const ref = useRef<HTMLInputElement>(null);
  const [drag, setDrag] = useState(false);
  return <div className={`file-slot ${drag ? "dragging" : ""} ${input ? "filled" : ""}`} onDragOver={e => { e.preventDefault(); if (!disabled) setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={e => { e.preventDefault(); setDrag(false); if (!disabled) onChoose(e.dataTransfer.files[0]); }}>
    <input ref={ref} className="sr-only" type="file" accept={ACCEPT} disabled={disabled} aria-label={`Upload ${side === "source" ? "approved reference" : "produced file"}`} onChange={e => { onChoose(e.target.files?.[0]); e.target.value = ""; }} />
    <div className={`file-slot-icon ${side}`}>{input ? /\.(pdf|docx|txt|md)$/i.test(input.file.name) ? <FileText size={21} /> : <ImageIcon size={21} /> : <Upload size={20} />}</div>
    <button className="file-slot-content" disabled={disabled} onClick={() => ref.current?.click()}><span className="file-role">{number === 1 ? "APPROVED REFERENCE" : "PRODUCED ASSET"}</span><strong>{input?.file.name || (side === "source" ? "Drop your source of truth" : "Drop what was produced")}</strong><span className="file-detail">{input ? <>{input.file.name.split(".").pop()?.toUpperCase()}<i />{sizeLabel(input.file.size)}<i /><span className="replace-link">Replace file</span></> : <>or <span className="replace-link">browse files</span><i />Image, PDF, DOCX, TXT · up to 10 MB</>}</span></button>
    {input && <button className="icon-button remove-file" disabled={disabled} onClick={onRemove} aria-label={`Remove ${side} file`}><X size={15} /></button>}
  </div>;
}

function Preview({ side, input, asset, currentPage, page, image, zoom, findings, selected, showBoxes, legend, onSelect, onPage }: { side: Side; input: InputFile | null; asset?: Asset; currentPage: number; page?: Page; image?: string; zoom: number; findings: Finding[]; selected: string | null; showBoxes: boolean; legend: Record<string, string>; onSelect: (f: Finding) => void; onPage: (n: number) => void }) {
  const allPages = asset?.pages || [];
  const pagePosition = Math.max(0, allPages.findIndex(p => p.index === currentPage));
  const text = page?.text || asset?.text || input?.text;
  return <div className="preview-pane"><div className="preview-label"><div><span className={`side-dot ${side}`} /><strong>{side === "source" ? "Approved reference" : "Produced asset"}</strong>{(input || asset) && <span className="preview-filename">{input?.file.name || asset?.name}</span>}</div>{allPages.length > 1 && <div className="page-controls"><button className="icon-button" disabled={pagePosition === 0} onClick={() => onPage(allPages[pagePosition - 1].index)} aria-label={`Previous ${side} page`}><ChevronLeft size={14} /></button><span>{pagePosition + 1} / {allPages.length}</span><button className="icon-button" disabled={pagePosition >= allPages.length - 1} onClick={() => onPage(allPages[pagePosition + 1].index)} aria-label={`Next ${side} page`}><ChevronRight size={14} /></button></div>}</div>
    <div className="preview-stage"><div className="preview-width" style={{ width: `${zoom}%`, maxWidth: zoom > 100 ? "none" : undefined }}>
      {image ? <div className="image-canvas"><img src={image} alt={`${side === "source" ? "Approved reference" : "Produced asset"}, page ${currentPage + 1}`} draggable={false} />{showBoxes && findings.map((f, index) => {
        const displayIndex = Number(f.id.replace(/^f/, "")) || index + 1;
        const region = f[side]; if (!region?.bbox || region.page !== currentPage) return null;
        const [x, y, w, h] = region.bbox; if (![x, y, w, h].every(Number.isFinite)) return null;
        const color = legend[f.category] || categoryInfo(f.category).color;
        return <button key={f.id} title={f.message} aria-label={`Locate finding ${displayIndex}: ${f.message}`} onClick={() => onSelect(f)} className={`annotation ${selected === f.id ? "selected" : ""}`} style={{ left: `${Math.max(0, Math.min(1, x)) * 100}%`, top: `${Math.max(0, Math.min(1, y)) * 100}%`, width: `${Math.max(0.008, Math.min(w, 1 - x)) * 100}%`, height: `${Math.max(0.008, Math.min(h, 1 - y)) * 100}%`, borderColor: color, background: selected === f.id ? `${color}18` : "transparent", zIndex: selected === f.id ? 5 : 2 }}><span style={{ background: color }}>{displayIndex}</span></button>;
      })}</div> : text ? <div className="document-preview"><div className="document-caption"><FileText size={14} />Extracted copy<span>Layout simplified</span></div><pre>{text}</pre></div> : input || asset ? <div className="document-placeholder"><FileText size={38} strokeWidth={1.25} /><h3>{input?.file.name || asset?.name}</h3><p>{asset ? "A rendered preview is not available for this file. Review the findings below; PDF rendering may need an optional package." : "Run the comparison to extract this document’s copy and prepare any available page previews."}</p><span>{(input?.file.name || asset?.name || "").split(".").pop()?.toUpperCase()} DOCUMENT</span></div> : <div className="empty-preview"><div className="empty-page"><div className="empty-page-top"><span /><i /></div><div className="empty-page-block" /><div className="empty-page-line" /><div className="empty-page-line short" /><div className="empty-page-button" /></div><h3>{side === "source" ? "The original idea." : "The finished experience."}</h3><p>{side === "source" ? "Your approved design, copy deck, or document." : "The screenshot, creative, or document to check."}</p></div>}
    </div></div>
  </div>;
}
