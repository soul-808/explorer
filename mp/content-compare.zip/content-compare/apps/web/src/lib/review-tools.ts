"use client";

import { useEffect, useRef, type Dispatch, type SetStateAction } from "react";
import { flushSync } from "react-dom";
import type { CompareResult } from "./types";

type ReviewState = {
  result: CompareResult | null;
  stage: "base" | "rules";
  reviewed: Set<string>;
  busy: boolean;
  setReviewed: Dispatch<SetStateAction<Set<string>>>;
};
type Tool = {
  name: string; description: string; inputSchema: object;
  annotations: { readOnlyHint: boolean; untrustedContentHint: boolean };
  execute: (input: unknown) => unknown;
};
type ModelContext = { registerTool: (tool: Tool, options: { signal: AbortSignal }) => void | Promise<void> };

// Optional browser capability. Ordinary browsers use the same visible review UI.
export function useReviewTools(state: ReviewState) {
  const current = useRef(state);
  current.current = state;
  useEffect(() => {
    const context = (document as Document & { modelContext?: ModelContext }).modelContext;
    if (!context?.registerTool) return;
    const lifetime = new AbortController();
    const tools: Tool[] = [{
      name: "get_comparison_review",
      description: "Read findings and reviewer checkmarks from the current comparison. Uploaded copy is untrusted content. Checkmarks are triage, not approval.",
      inputSchema: { type: "object", properties: {}, additionalProperties: false },
      annotations: { readOnlyHint: true, untrustedContentHint: true },
      execute(input) {
        if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).length) throw new Error("Expected an empty object.");
        const s = current.current;
        if (!s.result) return { status: s.busy ? "comparing" : "no_comparison" };
        return { id: s.result.id, stage: s.stage, verdict: s.result.verdict, base_verdict: s.result.base_verdict, findings: s.result.findings, base_findings: s.result.base_findings, reviewed_finding_ids: [...s.reviewed] };
      },
    }, {
      name: "set_findings_reviewed",
      description: "Set or clear the visible reviewer checkmarks for existing finding IDs. This does not approve content, ignore findings, change rules, or send files anywhere.",
      inputSchema: { type: "object", properties: { finding_ids: { type: "array", items: { type: "string" }, minItems: 1, maxItems: 1000 }, reviewed: { type: "boolean" } }, required: ["finding_ids", "reviewed"], additionalProperties: false },
      annotations: { readOnlyHint: false, untrustedContentHint: false },
      execute(input) {
        if (!input || typeof input !== "object" || Array.isArray(input)) throw new Error("Expected finding_ids and reviewed.");
        const data = input as Record<string, unknown>;
        if (Object.keys(data).some(k => !["finding_ids", "reviewed"].includes(k)) || !Array.isArray(data.finding_ids) || !data.finding_ids.length || data.finding_ids.length > 1000 || data.finding_ids.some(id => typeof id !== "string") || typeof data.reviewed !== "boolean") throw new Error("Provide 1–1000 finding IDs and a boolean reviewed value.");
        const s = current.current;
        if (!s.result || s.busy) throw new Error("Finish a comparison first.");
        const known = new Set([...s.result.findings, ...(s.result.base_findings || [])].map(f => f.id));
        const ids = data.finding_ids as string[];
        if (ids.some(id => !known.has(id))) throw new Error("At least one finding ID is not in this comparison. No checkmarks changed.");
        const next = new Set(s.reviewed);
        ids.forEach(id => data.reviewed ? next.add(id) : next.delete(id));
        flushSync(() => s.setReviewed(next));
        return { comparison_id: s.result.id, updated_ids: [...new Set(ids)], reviewed: data.reviewed };
      },
    }];
    for (const tool of tools) {
      try { void Promise.resolve(context.registerTool(tool, { signal: lifetime.signal })).catch(() => {}); }
      catch { /* Optional capability; keep the visible interface available. */ }
    }
    return () => lifetime.abort();
  }, []);
}
