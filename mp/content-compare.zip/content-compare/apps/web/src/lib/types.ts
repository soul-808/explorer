export type EngineStatus = "ok" | "unavailable" | "failed" | "skipped";
export type EngineName = "text" | "ocr" | "pixel" | "ssim" | "vision_llm";
export type Engine = { name: string; status: EngineStatus; backend?: string; version?: string; message?: string; duration_ms?: number };
export type Health = { status: string; version: string; engines: Engine[]; supported_kinds: string[] };
export type Region = { page: number; bbox?: [number, number, number, number] | null; text?: string };
export type Finding = {
  id: string; category: string; severity: "high" | "medium" | "low" | "info";
  engine: string; confidence: number; message: string; source?: Region | null; target?: Region | null;
  disposition?: "flagged" | "ignored";
  rule_matches?: { rule_id: string; rule_name: string; reason: string; compliance: boolean }[];
};
export type Page = { index: number; width?: number; height?: number; image_url?: string; text?: string };
export type Asset = { name: string; kind: string; pages: Page[]; text?: string; notes?: string[] };
export type CompareResult = {
  run_id?: string;
  id: string; created_at: string; source: Asset; target: Asset; engines: Engine[];
  verdict: { status: "match" | "mismatch" | "inconclusive"; confidence: number; summary: string };
  stats: { text_similarity?: number | null; pixel_diff_ratio?: number | null; ssim?: number | null; engines_ran: number; warnings?: string[] };
  findings: Finding[]; overlays: { source?: { page: number; image_url: string }[]; target?: { page: number; image_url: string }[] };
  legend: Record<string, string>; warnings?: string[];
  base_findings?: Finding[];
  base_verdict?: { status: "match" | "mismatch" | "inconclusive"; confidence: number; summary: string };
  rules_report?: {
    rules: { rule_id: string; name: string; type: string; status: string; matches?: number; compliance?: boolean; reason?: string }[];
    guidance: { status: "not_provided" | "evaluated" | "unevaluated" | "skipped"; reason?: string; missing?: string[]; unknown_ids?: string[] };
    counts: { flagged: number; ignored: number; added: number; compliance_flagged: number };
  };
};
export type Rule = {
  id: string; name: string; type: "required_text" | "forbidden_text" | "allowed_change" | "ignore_region";
  enabled: boolean; value?: string; from?: string; to?: string;
  side?: "source" | "target"; page?: number; bbox?: [number, number, number, number];
  severity: "high" | "medium" | "low" | "info"; compliance: boolean;
};
export type RuleProfile = { version: 1; name: string; rules: Rule[]; rule_guidance: string };
export type CompareOptions = {
  engines: EngineName[];
  text: { ignore_case: boolean; ignore_whitespace: boolean; ignore_punctuation: boolean };
  pixel: { threshold: number; min_region_px: number };
  render_overlays: boolean;
};

export type FeedbackVerdict = "correct" | "false_positive" | "missed" | "wrong_severity" | "acceptable_difference" | "other";
export type Feedback = {
  id: string; created_at: string; finding_id: string | null; verdict: FeedbackVerdict;
  expected_category?: string | null; expected_severity?: string | null; comment: string; reviewer: string;
};
export type RunSummary = {
  id: string; created_at: string; origin: "manual" | "job" | "intake";
  source_name: string; target_name: string; verdict: CompareResult["verdict"];
  counts: { findings: number; flagged: number; ignored: number }; job_id?: string | null;
  batch?: string | null; labels: Record<string, string>; feedback_count: number;
};
export type SavedRun = RunSummary & { result: CompareResult; options: Record<string, unknown>; feedback: Feedback[] };
export type Job = {
  id: string; status: "queued" | "running" | "done" | "failed" | "cancelled";
  created_at: string; started_at?: string | null; finished_at?: string | null; attempts: number;
  run_id?: string | null; error?: string | null; origin: string; labels: Record<string, string>;
  source_name: string; target_name: string;
};
export type PublicConfig = {
  brand: { name: string; logo_url?: string | null; accent: string };
  automation: { enabled: boolean; intake_enabled: boolean; worker: string };
  store: { kind: string; path?: string };
  vision: { providers_configured: string[]; model_default: string | null; models_allowed: string[]; error?: string | null };
  version: string;
};
export type AutomationStatus = {
  intake: { enabled: boolean; inbox?: string; last_poll?: string; manifests_seen: number; errors: string[] };
  worker: { running: boolean; workers: number; queued: number; running_jobs: number; done: number; failed: number };
  store: { kind: string; ok: boolean; runs: number }; errors?: string[]; plugin_errors?: string[];
  cleanup?: { policy: { retention_days: number; max_runs: number; max_data_mb: number; scratch_ttl_minutes: number; cleanup_interval: number; keep_feedback_on_prune: boolean }; last?: CleanupReport | null; data_dir_mb: number; scratch_mb: number };
};
export type CleanupReport = { at?: string; dry_run?: boolean; busy?: boolean; runs_pruned?: string[]; jobs_pruned?: string[]; job_inputs_removed?: number; scratch_removed?: number; orphans_removed?: number; inbox_manifests_removed?: number; errors?: string[] };
