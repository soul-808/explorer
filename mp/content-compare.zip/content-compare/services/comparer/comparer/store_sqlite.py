"""Default Store: stdlib sqlite3, one file, WAL mode, safe across the worker thread and HTTP threads."""
from __future__ import annotations

import json
import os
import sqlite3
import threading
from typing import Iterator, Optional

from .adapters import Store

SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
  id TEXT PRIMARY KEY, created_at TEXT NOT NULL, origin TEXT NOT NULL, status TEXT NOT NULL,
  summary TEXT NOT NULL, result TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS runs_created ON runs(created_at DESC);
CREATE TABLE IF NOT EXISTS jobs (
  id TEXT PRIMARY KEY, created_at TEXT NOT NULL, status TEXT NOT NULL, idempotency_key TEXT UNIQUE,
  data TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS jobs_status ON jobs(status, created_at);
CREATE TABLE IF NOT EXISTS feedback (
  id TEXT PRIMARY KEY, run_id TEXT NOT NULL, created_at TEXT NOT NULL, data TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS feedback_run ON feedback(run_id);
"""


class SqliteStore(Store):
    kind = "sqlite"

    def __init__(self, path: str):
        self.path = path
        self._lock = threading.RLock()
        self._conn: Optional[sqlite3.Connection] = None

    def open(self):
        os.makedirs(os.path.dirname(os.path.abspath(self.path)), exist_ok=True)
        self._conn = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._conn.executescript(SCHEMA)

    def close(self):
        if self._conn:
            self._conn.close(); self._conn = None

    def health(self):
        try:
            with self._lock:
                self._conn.execute("SELECT 1").fetchone()
            return {"kind": self.kind, "ok": True, "path": self.path}
        except Exception as e:
            return {"kind": self.kind, "ok": False, "path": self.path, "error": str(e)}

    # ---- runs
    def save_run(self, run):
        summary = {k: v for k, v in run.items() if k not in ("result", "options", "feedback")}
        with self._lock:
            self._conn.execute("INSERT OR REPLACE INTO runs VALUES (?,?,?,?,?,?)",
                               (run["id"], run["created_at"], run["origin"], run["verdict"]["status"],
                                json.dumps(summary), json.dumps({"result": run["result"], "options": run.get("options", {})})))

    def get_run(self, run_id):
        with self._lock:
            row = self._conn.execute("SELECT summary, result FROM runs WHERE id=?", (run_id,)).fetchone()
        if not row:
            return None
        run = json.loads(row[0]); run.update(json.loads(row[1]))
        run["feedback"] = self.list_feedback(run_id)
        run["feedback_count"] = len(run["feedback"])
        return run

    def list_runs(self, limit=50, cursor=None, origin=None, status=None):
        q = "SELECT id, summary FROM runs WHERE 1=1"; args = []
        if cursor:
            q += (" AND (created_at < (SELECT created_at FROM runs WHERE id=?)"
                  " OR (created_at = (SELECT created_at FROM runs WHERE id=?) AND id < ?))")
            args += [cursor, cursor, cursor]
        if origin:
            q += " AND origin=?"; args.append(origin)
        if status:
            q += " AND status=?"; args.append(status)
        q += " ORDER BY created_at DESC, id DESC LIMIT ?"; args.append(limit + 1)
        with self._lock:
            rows = self._conn.execute(q, args).fetchall()
            counts = dict(self._conn.execute("SELECT run_id, COUNT(*) FROM feedback GROUP BY run_id").fetchall())
        runs = []
        for rid, summary in rows[:limit]:
            r = json.loads(summary); r["feedback_count"] = counts.get(rid, 0); runs.append(r)
        return runs, (rows[limit - 1][0] if len(rows) > limit else None)

    def delete_run(self, run_id, keep_feedback=False):
        with self._lock:
            cur = self._conn.execute("DELETE FROM runs WHERE id=?", (run_id,))
            if not keep_feedback:
                self._conn.execute("DELETE FROM feedback WHERE run_id=?", (run_id,))
        return cur.rowcount > 0

    def run_ids_for_pruning(self, created_before=None, keep_newest=None):
        ids = set()
        with self._lock:
            if created_before:
                ids.update(r[0] for r in self._conn.execute("SELECT id FROM runs WHERE created_at < ?", (created_before,)))
            if keep_newest is not None:
                ids.update(r[0] for r in self._conn.execute(
                    "SELECT id FROM runs ORDER BY created_at DESC, id DESC LIMIT -1 OFFSET ?", (max(0, keep_newest),)))
            order = {r[0]: i for i, r in enumerate(self._conn.execute("SELECT id FROM runs ORDER BY created_at, id"))}
        return sorted(ids, key=lambda i: order.get(i, 0))

    def delete_jobs(self, statuses, finished_before):
        out = []
        with self._lock:
            rows = self._conn.execute("SELECT id, data FROM jobs WHERE status IN (%s)" % ",".join("?" * len(statuses)), statuses).fetchall()
            for jid, data in rows:
                job = json.loads(data)
                if (job.get("finished_at") or job["created_at"]) < finished_before:
                    self._conn.execute("DELETE FROM jobs WHERE id=?", (jid,)); out.append(jid)
        return out

    def count_runs(self):
        with self._lock:
            return self._conn.execute("SELECT COUNT(*) FROM runs").fetchone()[0]

    # ---- jobs
    def create_job(self, job):
        with self._lock:
            try:
                self._conn.execute("INSERT INTO jobs VALUES (?,?,?,?,?)",
                                   (job["id"], job["created_at"], job["status"], job.get("idempotency_key"), json.dumps(job)))
            except sqlite3.IntegrityError as e:
                raise ValueError(f"job with idempotency_key {job.get('idempotency_key')!r} already exists") from e

    def cancel_job(self, job_id, finished_at):
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                row = self._conn.execute("SELECT data FROM jobs WHERE id=?", (job_id,)).fetchone()
                if not row:
                    self._conn.execute("COMMIT"); return None
                job = json.loads(row[0])
                if job["status"] == "queued":
                    job["status"] = "cancelled"; job["finished_at"] = finished_at
                    self._conn.execute("UPDATE jobs SET status='cancelled', data=? WHERE id=? AND status='queued'", (json.dumps(job), job_id))
                self._conn.execute("COMMIT")
                return job
            except Exception:
                self._conn.execute("ROLLBACK"); raise

    def get_job(self, job_id):
        with self._lock:
            row = self._conn.execute("SELECT data FROM jobs WHERE id=?", (job_id,)).fetchone()
        return json.loads(row[0]) if row else None

    def find_job_by_key(self, key):
        with self._lock:
            row = self._conn.execute("SELECT data FROM jobs WHERE idempotency_key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else None

    def list_jobs(self, status=None, limit=50):
        q = "SELECT data FROM jobs"; args = []
        if status:
            q += " WHERE status=?"; args.append(status)
        q += " ORDER BY created_at DESC LIMIT ?"; args.append(limit)
        with self._lock:
            return [json.loads(r[0]) for r in self._conn.execute(q, args).fetchall()]

    def update_job(self, job_id, **fields):
        with self._lock:
            job = self.get_job(job_id)
            if not job:
                return None
            job.update(fields)
            self._conn.execute("UPDATE jobs SET status=?, data=? WHERE id=?", (job["status"], json.dumps(job), job_id))
            return job

    def claim_next_job(self, worker_id):
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                row = self._conn.execute("SELECT data FROM jobs WHERE status='queued' ORDER BY created_at LIMIT 1").fetchone()
                if not row:
                    self._conn.execute("COMMIT"); return None
                job = json.loads(row[0])
                job["status"] = "running"; job["worker"] = worker_id
                job["attempts"] = int(job.get("attempts", 0)) + 1
                self._conn.execute("UPDATE jobs SET status='running', data=? WHERE id=?", (json.dumps(job), job["id"]))
                self._conn.execute("COMMIT")
                return job
            except Exception:
                self._conn.execute("ROLLBACK"); raise

    def recover_running(self, max_attempts):
        n = 0
        with self._lock:
            for (data,) in self._conn.execute("SELECT data FROM jobs WHERE status='running'").fetchall():
                job = json.loads(data)
                if int(job.get("attempts", 0)) >= max_attempts:
                    job["status"] = "failed"; job["error"] = "worker died and max attempts reached"
                else:
                    job["status"] = "queued"; job["error"] = "recovered after worker restart"
                self._conn.execute("UPDATE jobs SET status=?, data=? WHERE id=?", (job["status"], json.dumps(job), job["id"]))
                n += 1
        return n

    def job_counts(self):
        with self._lock:
            rows = self._conn.execute("SELECT status, COUNT(*) FROM jobs GROUP BY status").fetchall()
        return {s: c for s, c in rows}

    # ---- feedback
    def add_feedback(self, fb):
        with self._lock:
            self._conn.execute("INSERT INTO feedback VALUES (?,?,?,?)", (fb["id"], fb["run_id"], fb["created_at"], json.dumps(fb)))

    def list_feedback(self, run_id):
        with self._lock:
            rows = self._conn.execute("SELECT data FROM feedback WHERE run_id=? ORDER BY created_at", (run_id,)).fetchall()
        return [json.loads(r[0]) for r in rows]

    def iter_feedback(self, since=None):
        q = "SELECT data FROM feedback"; args = []
        if since:
            q += " WHERE created_at >= ?"; args.append(since)
        q += " ORDER BY created_at"
        with self._lock:
            rows = self._conn.execute(q, args).fetchall()
        for (data,) in rows:
            yield json.loads(data)
