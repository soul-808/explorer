"""Alternative Store: one JSON file per record under a directory. No database at all; fine for
demos and small teams, and the reference for writing another Store."""
from __future__ import annotations

import json
import os
import threading
from typing import Iterator, Optional

from .adapters import Store


class JsonFilesStore(Store):
    kind = "jsonfiles"

    def __init__(self, root: str):
        self.root = root
        self._lock = threading.RLock()

    def _dir(self, kind):
        d = os.path.join(self.root, kind); os.makedirs(d, exist_ok=True); return d

    def _write(self, kind, rid, obj):
        path = os.path.join(self._dir(kind), rid + ".json"); tmp = path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(obj, f)
        os.replace(tmp, path)

    def _read(self, kind, rid):
        path = os.path.join(self._dir(kind), rid + ".json")
        if not os.path.isfile(path):
            return None
        with open(path) as f:
            return json.load(f)

    def _all(self, kind):
        out = []
        for fn in os.listdir(self._dir(kind)):
            if fn.endswith(".json"):
                with open(os.path.join(self.root, kind, fn)) as f:
                    out.append(json.load(f))
        return out

    def open(self):
        os.makedirs(self.root, exist_ok=True)

    def health(self):
        return {"kind": self.kind, "ok": os.path.isdir(self.root), "path": self.root}

    # runs
    def save_run(self, run):
        with self._lock:
            self._write("runs", run["id"], {k: v for k, v in run.items() if k != "feedback"})

    def get_run(self, run_id):
        with self._lock:
            run = self._read("runs", run_id)
        if run:
            run["feedback"] = self.list_feedback(run_id); run["feedback_count"] = len(run["feedback"])
        return run

    def list_runs(self, limit=50, cursor=None, origin=None, status=None):
        with self._lock:
            runs = sorted(self._all("runs"), key=lambda r: (r["created_at"], r["id"]), reverse=True)
            fb = self._all("feedback")
        counts = {}
        for f in fb:
            counts[f["run_id"]] = counts.get(f["run_id"], 0) + 1
        if cursor:
            ids = [r["id"] for r in runs]
            runs = runs[ids.index(cursor) + 1:] if cursor in ids else runs
        if origin:
            runs = [r for r in runs if r["origin"] == origin]
        if status:
            runs = [r for r in runs if r["verdict"]["status"] == status]
        page = runs[:limit]
        out = []
        for r in page:
            s = {k: v for k, v in r.items() if k not in ("result", "options")}
            s["feedback_count"] = counts.get(r["id"], 0); out.append(s)
        return out, (page[-1]["id"] if len(runs) > limit else None)

    def delete_run(self, run_id, keep_feedback=False):
        with self._lock:
            path = os.path.join(self._dir("runs"), run_id + ".json")
            if not os.path.isfile(path):
                return False
            os.remove(path)
            if not keep_feedback:
                for f in self._all("feedback"):
                    if f["run_id"] == run_id:
                        os.remove(os.path.join(self._dir("feedback"), f["id"] + ".json"))
            return True

    def run_ids_for_pruning(self, created_before=None, keep_newest=None):
        with self._lock:
            runs = sorted(self._all("runs"), key=lambda r: (r["created_at"], r["id"]))
        ids = []
        if created_before:
            ids += [r["id"] for r in runs if r["created_at"] < created_before]
        if keep_newest is not None and len(runs) > keep_newest:
            ids += [r["id"] for r in runs[:len(runs) - keep_newest]]
        return sorted(set(ids), key=lambda i: next(k for k, r in enumerate(runs) if r["id"] == i))

    def delete_jobs(self, statuses, finished_before):
        out = []
        with self._lock:
            for job in self._all("jobs"):
                if job["status"] in statuses and (job.get("finished_at") or job["created_at"]) < finished_before:
                    os.remove(os.path.join(self._dir("jobs"), job["id"] + ".json")); out.append(job["id"])
        return out

    def count_runs(self):
        return len([f for f in os.listdir(self._dir("runs")) if f.endswith(".json")])

    # jobs
    def create_job(self, job):
        with self._lock:
            key = job.get("idempotency_key")
            if key and any(j.get("idempotency_key") == key for j in self._all("jobs")):
                raise ValueError(f"job with idempotency_key {key!r} already exists")
            self._write("jobs", job["id"], job)

    def cancel_job(self, job_id, finished_at):
        with self._lock:
            job = self._read("jobs", job_id)
            if job and job["status"] == "queued":
                job["status"] = "cancelled"; job["finished_at"] = finished_at
                self._write("jobs", job_id, job)
            return job

    def get_job(self, job_id):
        return self._read("jobs", job_id)

    def find_job_by_key(self, key):
        with self._lock:
            return next((j for j in self._all("jobs") if j.get("idempotency_key") == key), None)

    def list_jobs(self, status=None, limit=50):
        with self._lock:
            jobs = sorted(self._all("jobs"), key=lambda j: j["created_at"], reverse=True)
        if status:
            jobs = [j for j in jobs if j["status"] == status]
        return jobs[:limit]

    def update_job(self, job_id, **fields):
        with self._lock:
            job = self._read("jobs", job_id)
            if not job:
                return None
            job.update(fields); self._write("jobs", job_id, job); return job

    def claim_next_job(self, worker_id):
        with self._lock:
            queued = sorted((j for j in self._all("jobs") if j["status"] == "queued"), key=lambda j: j["created_at"])
            if not queued:
                return None
            job = queued[0]
            job["status"] = "running"; job["worker"] = worker_id; job["attempts"] = int(job.get("attempts", 0)) + 1
            self._write("jobs", job["id"], job); return job

    def recover_running(self, max_attempts):
        n = 0
        with self._lock:
            for job in self._all("jobs"):
                if job["status"] != "running":
                    continue
                if int(job.get("attempts", 0)) >= max_attempts:
                    job["status"] = "failed"; job["error"] = "worker died and max attempts reached"
                else:
                    job["status"] = "queued"; job["error"] = "recovered after worker restart"
                self._write("jobs", job["id"], job); n += 1
        return n

    def job_counts(self):
        out = {}
        for j in self._all("jobs"):
            out[j["status"]] = out.get(j["status"], 0) + 1
        return out

    # feedback
    def add_feedback(self, fb):
        with self._lock:
            self._write("feedback", fb["id"], fb)

    def list_feedback(self, run_id):
        with self._lock:
            return sorted((f for f in self._all("feedback") if f["run_id"] == run_id), key=lambda f: f["created_at"])

    def iter_feedback(self, since=None):
        with self._lock:
            items = sorted(self._all("feedback"), key=lambda f: f["created_at"])
        for f in items:
            if since and f["created_at"] < since:
                continue
            yield f
