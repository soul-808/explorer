"""content-comparer: compare two marketing assets and flag differences.

Zero required dependencies. Optional engines register themselves when their
libraries import cleanly; missing ones report `unavailable` and never break a run.
"""
__version__ = "0.2.0"
