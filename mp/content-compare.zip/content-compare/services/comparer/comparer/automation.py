"""Automation layer: run persistence, background jobs, folder intake, feedback export.

Everything lives behind `Automation`, created once by the server (or a test). With no
configuration it still records every manual comparison as a run; the worker thread and the
intake poller only start when enabled.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
import secrets
import shutil
import threading
import time
import traceback
from typing import Optional

from . import __version__, pipeline
from .adapters import Source, Store, load_plugin
from .store_json import JsonFilesStore
from .store_sqlite import SqliteStore


def vision_llm_plugin_errors() -> list[str]:
    from .engines import vision_llm
    vision_llm.plugin_providers()
    return list(vision_llm.PLUGIN_ERRORS)


ORPHAN_GRACE_SECONDS = int(os.environ.get("COMPARER_ORPHAN_GRACE_SECONDS", "900"))
import re as _re
ID_PATTERN = _re.compile(r"^(run|job|cmp)_[0-9]{8}T[0-9]{6}_[0-9a-f]{4,32}$")   # cleanup only ever touches these
LOCK_NAME = "server.lock"

SERVICE_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.environ.get("COMPARER_DATA_DIR") or os.path.join(SERVICE_ROOT, ".data")
INPUT_LIMIT = int(os.environ.get("COMPARER_MAX_INPUT_MB", "30")) * 1024 * 1024
FEEDBACK_VERDICTS = ("correct", "false_positive", "missed", "wrong_severity", "acceptable_difference", "other")


def now_iso():
    # millisecond precision so records created in the same second still sort in creation order
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


MAX_MANIFEST_BYTES = int(os.environ.get("COMPARER_MAX_MANIFEST_KB", "1024")) * 1024
MAX_MANIFEST_PAIRS = int(os.environ.get("COMPARER_MAX_MANIFEST_PAIRS", "200"))
FEEDBACK_SEVERITIES = ("high", "medium", "low", "info")
FEEDBACK_CATEGORIES = ("text_missing", "text_extra", "text_changed", "text_moved", "visual_diff", "layout_shift",
                       "llm_observation", "rule_violation")


def new_id(prefix):
    return f"{prefix}_{_dt.datetime.now(_dt.timezone.utc).strftime('%Y%m%dT%H%M%S')}_{secrets.token_hex(8)}"


class ConfigError(ValueError):
    pass


# --------------------------------------------------------------------------- config

def _load_config_file(path: str) -> dict:
    """COMPARER_CONFIG=path.json: {"brand": {...}, "store": "...", "store_path": "...", "workers": 1,
    "inbox": "...", "intake_interval": 5, "job_attempts": 2}. Environment variables override file values."""
    with open(path) as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ConfigError(f"{path}: top level must be an object")
    return data


def build_config(env=None) -> dict:
    env = os.environ if env is None else env
    file_cfg = {}
    if env.get("COMPARER_CONFIG"):
        file_cfg = _load_config_file(env["COMPARER_CONFIG"])   # raises loudly on a bad file
    fb = file_cfg.get("brand") if isinstance(file_cfg.get("brand"), dict) else {}
    def pick(env_key, file_key, default):
        v = env.get(env_key)
        return v if v not in (None, "") else file_cfg.get(file_key, default)
    data_dir = pick("COMPARER_DATA_DIR", "data_dir", DATA_DIR)
    store = str(pick("COMPARER_STORE", "store", "sqlite"))
    cfg = {
        "config_file": env.get("COMPARER_CONFIG") or None,
        "store_explicit": bool(env.get("COMPARER_STORE") or file_cfg.get("store")),
        "data_dir": data_dir,
        "store": store,
        "store_path": pick("COMPARER_STORE_PATH", "store_path", None) or (os.path.join(data_dir, "comparer.db") if store == "sqlite" else os.path.join(data_dir, "store")),
        "workers": max(0, min(4, int(pick("COMPARER_WORKERS", "workers", 1)))),
        "job_attempts": max(1, int(pick("COMPARER_JOB_ATTEMPTS", "job_attempts", 2))),
        "inbox": pick("COMPARER_INBOX", "inbox", None) or None,
        "intake_interval": max(1.0, float(pick("COMPARER_INTAKE_INTERVAL", "intake_interval", 5))),
        "sources": [x for x in str(pick("COMPARER_SOURCES", "sources", "")).split(",") if x.strip()] if not isinstance(file_cfg.get("sources"), list) or env.get("COMPARER_SOURCES") else list(file_cfg["sources"]),
        "token": env.get("COMPARER_TOKEN") or None,     # secrets come from the environment only, never the file
        # retention / cleanup (0 disables a rule)
        "retention_days": max(0, float(pick("COMPARER_RETENTION_DAYS", "retention_days", 30))),
        "max_runs": max(0, int(pick("COMPARER_MAX_RUNS", "max_runs", 500))),
        "max_data_mb": max(0, int(pick("COMPARER_MAX_DATA_MB", "max_data_mb", 2048))),
        "job_retention_days": max(0, float(pick("COMPARER_JOB_RETENTION_DAYS", "job_retention_days", 7))),
        "scratch_ttl_minutes": max(1, int(pick("COMPARER_SCRATCH_TTL_MINUTES", "scratch_ttl_minutes", 120))),
        "inbox_ttl_days": max(0, float(pick("COMPARER_INBOX_TTL_DAYS", "inbox_ttl_days", 7))),
        "cleanup_interval": max(30.0, float(pick("COMPARER_CLEANUP_INTERVAL", "cleanup_interval", 600))),
        "keep_feedback_on_prune": str(pick("COMPARER_KEEP_FEEDBACK", "keep_feedback_on_prune", "1")).lower() in ("1", "true", "yes"),
        "brand": {"name": str(pick("COMPARER_BRAND_NAME", "_", fb.get("name", "Content Compare")))[:120],
                  "logo_url": pick("COMPARER_BRAND_LOGO", "_", fb.get("logo_url")) or None,
                  "accent": str(pick("COMPARER_BRAND_ACCENT", "_", fb.get("accent", "#2f6d4b")))[:32],
                  "tagline": str(fb.get("tagline") or env.get("COMPARER_BRAND_TAGLINE") or "")[:200] or None},
    }
    if fb.get("logo_url") and not str(cfg["brand"]["logo_url"]).startswith(("/", "http://", "https://", "data:image/")):
        cfg["brand"]["logo_url"] = None
    return cfg


# --------------------------------------------------------------------------- intake source

class InboxSource(Source):
    """Folder harness: `<inbox>/*.json` manifests referencing files relative to the inbox."""
    kind = "inbox"

    def __init__(self, inbox: str):
        self.inbox = os.path.realpath(inbox)
        self.seen = 0
        self.errors: list[str] = []
        self.last_poll: Optional[str] = None

    def status(self):
        return {"kind": self.kind, "inbox": self.inbox, "enabled": True, "last_poll": self.last_poll,
                "manifests_seen": self.seen, "errors": self.errors[-10:]}

    def resolve(self, rel: str) -> str:
        """Inbox-relative path -> absolute, rejecting absolute paths, traversal and symlinks."""
        if not isinstance(rel, str) or not rel or os.path.isabs(rel) or rel.startswith(("~", "\\\\")):
            raise ConfigError(f"path must be relative to the inbox: {rel!r}")
        if any(part in ("..", "") for part in rel.replace("\\", "/").split("/")):
            raise ConfigError(f"path may not contain '..': {rel!r}")
        full = os.path.join(self.inbox, rel)
        # no symlink anywhere on the path (file or any directory component)
        probe = self.inbox
        for part in rel.replace("\\", "/").split("/"):
            probe = os.path.join(probe, part)
            if os.path.islink(probe):
                raise ConfigError(f"symlinks are not allowed: {rel!r}")
        real = os.path.realpath(full)
        if not real.startswith(self.inbox + os.sep):
            raise ConfigError(f"path escapes the inbox: {rel!r}")
        if not os.path.isfile(real):
            raise ConfigError(f"file not found in inbox: {rel!r}")
        if os.path.getsize(real) > INPUT_LIMIT:
            raise ConfigError(f"file over {INPUT_LIMIT // (1024 * 1024)} MB: {rel!r}")
        return real

    def read(self, rel: str) -> tuple[str, bytes]:
        path = self.resolve(rel)
        with open(path, "rb") as f:
            data = f.read(INPUT_LIMIT + 1)      # bounded read: the size check above is only a hint (TOCTOU)
        if len(data) > INPUT_LIMIT:
            raise ConfigError(f"file over {INPUT_LIMIT // (1024 * 1024)} MB: {rel!r}")
        return os.path.basename(path), data

    def poll(self, enqueue=None):
        """Scan the inbox. For each manifest: parse + validate EVERY pair first (nothing is read into
        jobs until the whole manifest is good), then hand the pairs to `enqueue` (which must return
        only after the store has the job), and only then rename the manifest `.done`. Any failure
        leaves the manifest as `.failed` + `.error.txt` so the work stays visible for retry; jobs
        already created keep their idempotency keys, so a retry never duplicates them."""
        self.last_poll = now_iso()
        items = []
        if not os.path.isdir(self.inbox):
            self.errors.append(f"{now_iso()} inbox missing: {self.inbox}")
            return items
        for fn in sorted(os.listdir(self.inbox)):
            if not fn.endswith(".json"):
                continue
            path = os.path.join(self.inbox, fn)
            if os.path.islink(path) or not os.path.isfile(path):
                continue
            self.seen += 1
            try:
                if os.path.getsize(path) > MAX_MANIFEST_BYTES:
                    raise ConfigError(f"manifest over {MAX_MANIFEST_BYTES // 1024} KB")
                with open(path) as f:
                    manifest = json.load(f)
                if not isinstance(manifest, dict):
                    raise ConfigError("manifest must be a JSON object")
                pairs = manifest.get("pairs")
                if not isinstance(pairs, list) or not pairs:
                    raise ConfigError("manifest needs a non-empty 'pairs' list")
                if len(pairs) > MAX_MANIFEST_PAIRS:
                    raise ConfigError(f"manifest has {len(pairs)} pairs; cap is {MAX_MANIFEST_PAIRS}")
                prefix = str(manifest.get("idempotency_prefix") or os.path.splitext(fn)[0])[:120]
                batch = manifest.get("batch")
                batch = str(batch)[:120] if batch is not None else None
                # phase 1: validate everything
                resolved = []
                for i, p in enumerate(pairs):
                    if not isinstance(p, dict) or not isinstance(p.get("source"), str) or not isinstance(p.get("target"), str):
                        raise ConfigError(f"pairs[{i}] must be an object with string 'source' and 'target'")
                    if p.get("labels") is not None and not isinstance(p["labels"], dict):
                        raise ConfigError(f"pairs[{i}].labels must be an object")
                    if p.get("options") is not None and not isinstance(p["options"], dict):
                        raise ConfigError(f"pairs[{i}].options must be an object")
                    resolved.append((self.resolve(p["source"]), self.resolve(p["target"]), p))
                # phase 2: read + enqueue durably
                batch_items = []
                for s_path, t_path, p in resolved:
                    _, sb = self.read(p["source"]); _, tb = self.read(p["target"])
                    batch_items.append({"source": (os.path.basename(s_path), sb), "target": (os.path.basename(t_path), tb),
                                        "labels": p.get("labels") or {}, "options": p.get("options") or {}, "batch": batch,
                                        "idempotency_key": f"{prefix}:{p['source']}:{p['target']}"})
                if enqueue is not None:
                    for item in batch_items:
                        enqueue(item)          # raises -> manifest marked failed, nothing acknowledged
                items.extend(batch_items)
                os.replace(path, path + ".done")
            except Exception as e:
                self.errors.append(f"{now_iso()} {fn}: {e}")
                try:
                    os.replace(path, path + ".failed")
                    with open(path + ".error.txt", "w") as f:
                        f.write(str(e))
                except OSError:
                    pass
        return items


# --------------------------------------------------------------------------- automation

class Automation:
    def __init__(self, config: Optional[dict] = None):
        self.cfg = config or build_config()
        self.plugin_errors: list[str] = []
        self.sources: list[Source] = []
        self.store: Store = self._make_store()
        self._threads: list[threading.Thread] = []
        self._stop = threading.Event()
        self._enqueue_lock = threading.Lock()   # idempotency find+create is atomic in-process
        self._poll_lock = threading.Lock()      # one intake pass at a time
        self._cleanup_lock = threading.Lock()
        self.last_cleanup: Optional[dict] = None
        self._active: set = set()                # run/job ids whose files are being written right now
        self._active_lock = threading.Lock()
        self.plugin_errors += vision_llm_plugin_errors()
        self.started_at = None
        self._load_sources()

    # ---- setup
    def _make_store(self) -> Store:
        kind = self.cfg["store"]
        path = self.cfg["store_path"]
        # A store that was explicitly configured must fail LOUDLY: silently switching stores would split
        # or lose history. Only the implicit default may not exist yet (sqlite creates its file).
        try:
            if kind == "sqlite":
                store = SqliteStore(path)
            elif kind == "jsonfiles":
                store = JsonFilesStore(path)
            else:
                store = load_plugin(kind)(path)
            store.open()
            health = store.health()
            if not health.get("ok", True):
                raise ConfigError(health.get("error") or "store health check failed")
        except Exception as e:
            raise ConfigError(f"store {kind!r} at {path!r} could not be opened: {e}") from e
        return store

    def _load_sources(self):
        if self.cfg["inbox"]:
            self.sources.append(InboxSource(self.cfg["inbox"]))
        for spec in self.cfg["sources"]:
            try:
                self.sources.append(load_plugin(spec)())
            except Exception as e:
                self.plugin_errors.append(f"source plugin {spec!r}: {e}")

    # ---- server lock: lets the CLI refuse to clean up while a server owns the data dir
    def lock_path(self):
        return os.path.join(self.cfg["data_dir"], LOCK_NAME)

    def acquire_lock(self):
        os.makedirs(self.cfg["data_dir"], exist_ok=True)
        with open(self.lock_path(), "w") as f:
            json.dump({"pid": os.getpid(), "started_at": now_iso()}, f)

    def release_lock(self):
        try:
            os.remove(self.lock_path())
        except OSError:
            pass

    def lock_holder(self) -> Optional[dict]:
        """The live server holding this data dir, or None (stale locks from dead pids are ignored)."""
        try:
            with open(self.lock_path()) as f:
                info = json.load(f)
            pid = int(info.get("pid", 0))
            os.kill(pid, 0)                     # raises if no such process
            return info if pid != os.getpid() else None
        except (OSError, ValueError, TypeError):
            return None

    def start(self):
        self.started_at = now_iso()
        self.acquire_lock()
        recovered = self.store.recover_running(self.cfg["job_attempts"])
        if recovered:
            print(f"automation: recovered {recovered} interrupted job(s)", flush=True)
        for i in range(self.cfg["workers"]):
            t = threading.Thread(target=self._worker_loop, args=(f"w{i + 1}",), daemon=True, name=f"comparer-worker-{i + 1}")
            t.start(); self._threads.append(t)
        if self.sources:
            t = threading.Thread(target=self._intake_loop, daemon=True, name="comparer-intake")
            t.start(); self._threads.append(t)
        t = threading.Thread(target=self._cleanup_loop, daemon=True, name="comparer-cleanup")
        t.start(); self._threads.append(t)

    def stop(self):
        self._stop.set()
        for t in self._threads:
            t.join(timeout=5)
        if self.started_at:
            self.release_lock()
        self.store.close()

    # ---- runs
    def record_run(self, result_dict: dict, options: dict, origin="manual", job_id=None, batch=None,
                   source_bytes=None, target_bytes=None, run_id=None) -> dict:
        """Persist a comparison as a run. Artifacts are copied under .data/runs/<id>/ and every URL in
        the stored result is rewritten to /api/runs/<id>/artifacts/..., so history never depends on the
        scratch .artifacts directory. `run_id` is only written into result_dict after the store accepted it."""
        import hashlib
        run_id = run_id or result_dict["id"].replace("cmp_", "run_", 1)
        labels = options.get("labels") if isinstance(options.get("labels"), dict) else {}
        labels = {str(k)[:64]: str(v)[:256] for k, v in labels.items()}
        with self._active_lock:
            self._active.add(run_id)                    # before any file is written, so cleanup never sees a half run
        stored = json.loads(json.dumps(result_dict))   # deep copy; the caller's dict is untouched until success
        prefix_old = f"/api/artifacts/{result_dict['id']}/"
        prefix_new = f"/api/runs/{run_id}/artifacts/"
        warnings = stored.setdefault("stats", {}).setdefault("warnings", [])
        d = os.path.join(self.cfg["data_dir"], "runs", run_id)
        originals = {}
        try:
            os.makedirs(d, exist_ok=True)
            src_art = os.path.join(pipeline.ARTIFACT_DIR, result_dict["id"])
            if os.path.isdir(src_art):
                for fn in os.listdir(src_art):
                    if fn != "result.json":
                        shutil.copy2(os.path.join(src_art, fn), os.path.join(d, fn))
            for name, data in (("source", source_bytes), ("target", target_bytes)):
                if data:
                    ext = os.path.splitext(stored[name]["name"])[1][:8] or ".bin"
                    with open(os.path.join(d, f"{name}-original{ext}"), "wb") as f:
                        f.write(data)
                    originals[f"{name}_original"] = f"{prefix_new}{name}-original{ext}"
        except OSError as e:
            warnings.append(f"artifacts not stored: {e}")
        for side in ("source", "target"):
            for page in stored.get(side, {}).get("pages", []):
                if (page.get("image_url") or "").startswith(prefix_old):
                    page["image_url"] = prefix_new + page["image_url"][len(prefix_old):]
        for side in ("source", "target"):
            for ov in stored.get("overlays", {}).get(side, []):
                if (ov.get("image_url") or "").startswith(prefix_old):
                    ov["image_url"] = prefix_new + ov["image_url"][len(prefix_old):]
        stored["run_id"] = run_id
        prov = {"engines": [{"name": e["name"], "backend": e.get("backend"), "version": e.get("version")}
                            for e in stored.get("engines", []) if e.get("status") == "ok"],
                "vision": next(({"provider": e.get("backend"), "model": e.get("version")}
                                for e in stored.get("engines", []) if e["name"] == "vision_llm" and e.get("status") == "ok"), None),
                "rules": len(options.get("rules") or []) if isinstance(options.get("rules"), list) else 0,
                "guidance": bool(options.get("rule_guidance")),
                "comparer_version": __version__}
        run = {"id": run_id, "created_at": now_iso(), "origin": origin, "provenance": prov,
               "source_sha256": hashlib.sha256(source_bytes).hexdigest() if source_bytes else None,
               "target_sha256": hashlib.sha256(target_bytes).hexdigest() if target_bytes else None,
               "source_name": stored["source"]["name"], "target_name": stored["target"]["name"],
               "verdict": stored["verdict"], "base_verdict": stored.get("base_verdict"),
               "counts": {"findings": len(stored["findings"]),
                          "flagged": sum(f.get("disposition") == "flagged" for f in stored["findings"]),
                          "ignored": sum(f.get("disposition") == "ignored" for f in stored["findings"])},
               "job_id": job_id, "batch": batch, "labels": labels, "feedback_count": 0, **originals,
               "result": stored, "options": {k: v for k, v in options.items() if k != "labels"}}
        try:
            self.store.save_run(run)                   # raises -> caller reports; nothing claims a run_id
        except Exception:
            shutil.rmtree(d, ignore_errors=True)       # no record -> no folder left behind
            with self._active_lock:
                self._active.discard(run_id)
            raise
        try:
            with open(os.path.join(d, "result.json"), "w") as f:
                json.dump(stored, f, indent=2)
        except OSError:
            pass
        with self._active_lock:
            self._active.discard(run_id)
        # the scratch copy is now redundant: every URL points at the run folder
        shutil.rmtree(os.path.join(pipeline.ARTIFACT_DIR, result_dict["id"]), ignore_errors=True)
        # success: reflect the stored view back to the caller
        result_dict.clear(); result_dict.update(stored)
        return run

    def run_artifact_path(self, run_id: str, file: str) -> Optional[str]:
        root = os.path.realpath(os.path.join(self.cfg["data_dir"], "runs"))
        path = os.path.realpath(os.path.join(root, run_id, file))
        return path if path.startswith(root + os.sep) and os.path.isfile(path) else None

    # ---- jobs
    def enqueue(self, source: tuple[str, bytes], target: tuple[str, bytes], options=None, labels=None,
                idempotency_key=None, origin="api", batch=None) -> tuple[dict, bool]:
        """Returns (job, created). Inputs are bytes already validated by the caller."""
        for name, data in (source, target):
            if len(data) > INPUT_LIMIT:
                raise ConfigError(f"{name} is over {INPUT_LIMIT // (1024 * 1024)} MB")
        if not isinstance(options or {}, dict):
            raise ConfigError("options must be an object")
        if not isinstance(labels or {}, dict):
            raise ConfigError("labels must be an object")
        key = str(idempotency_key)[:200] if idempotency_key else None
        with self._enqueue_lock:
            if key:
                existing = self.store.find_job_by_key(key)
                if existing:
                    return existing, False
            return self._create_job(source, target, options, labels, key, origin, batch), True

    def _create_job(self, source, target, options, labels, key, origin, batch):
        job_id = new_id("job")
        with self._active_lock:
            self._active.add(job_id)
        try:
            return self._create_job_files(job_id, source, target, options, labels, key, origin, batch)
        finally:
            with self._active_lock:
                self._active.discard(job_id)

    def _create_job_files(self, job_id, source, target, options, labels, key, origin, batch):
        d = os.path.join(self.cfg["data_dir"], "jobs", job_id)
        os.makedirs(d, exist_ok=True)
        paths = {}
        for side, (name, data) in (("source", source), ("target", target)):
            safe = "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in os.path.basename(name))[:120] or side
            p = os.path.join(d, f"{side}-{safe}")
            with open(p, "wb") as f:
                f.write(data)
            paths[side] = p
        job = {"id": job_id, "status": "queued", "created_at": now_iso(), "started_at": None, "finished_at": None,
               "attempts": 0, "run_id": None, "error": None, "origin": origin, "batch": batch,
               "labels": {str(k)[:64]: str(v)[:256] for k, v in (labels or {}).items()},
               "idempotency_key": key,
               "source_name": source[0], "target_name": target[0], "options": options or {}, "paths": paths}
        try:
            self.store.create_job(job)
        except Exception:
            shutil.rmtree(d, ignore_errors=True)
            raise
        return job

    def cancel(self, job_id) -> Optional[dict]:
        """Atomic: only a still-queued job flips to cancelled; a job the worker has claimed is returned as is."""
        return self.store.cancel_job(job_id, now_iso())

    @staticmethod
    def run_id_for_job(job_id: str) -> str:
        return "run_" + job_id[len("job_"):]

    def run_job(self, job: dict) -> dict:
        """Execute one claimed job synchronously (used by the worker and by tests). The run id is derived
        from the job id, so a crash between save_run and the status update cannot create a duplicate run:
        on retry the saved run is found and the job is simply marked done."""
        rid = self.run_id_for_job(job["id"])
        existing = self.store.get_run(rid)
        if existing:
            return self.store.update_job(job["id"], status="done", finished_at=now_iso(), run_id=rid,
                                         error="completed on a previous attempt")
        self.store.update_job(job["id"], started_at=now_iso())
        with self._active_lock:
            self._active.update((rid, job["id"]))
        try:
            return self._run_job_body(job, rid)
        finally:
            with self._active_lock:
                self._active.difference_update((rid, job["id"]))

    def _run_job_body(self, job, rid):
        try:
            with open(job["paths"]["source"], "rb") as f:
                sb = f.read()
            with open(job["paths"]["target"], "rb") as f:
                tb = f.read()
            options = dict(job.get("options") or {})
            options["labels"] = job.get("labels") or {}
            result = pipeline.compare(job["source_name"], sb, job["target_name"], tb, options)
            run = self.record_run(result.to_dict(), options, origin="intake" if job["origin"] == "intake" else "job",
                                  job_id=job["id"], batch=job.get("batch"), source_bytes=sb, target_bytes=tb, run_id=rid)
            done = self.store.update_job(job["id"], status="done", finished_at=now_iso(), run_id=run["id"], error=None)
            self._remove_job_inputs(job)              # the run keeps the originals
            return done
        except Exception as e:
            err = f"{type(e).__name__}: {e}"[:500]
            if int(job.get("attempts", 1)) < self.cfg["job_attempts"]:
                return self.store.update_job(job["id"], status="queued", error=err + " (will retry)")
            return self.store.update_job(job["id"], status="failed", finished_at=now_iso(), error=err)

    def _remove_job_inputs(self, job):
        root = os.path.realpath(os.path.join(self.cfg["data_dir"], "jobs"))
        d = os.path.realpath(os.path.join(root, job["id"]))
        if d.startswith(root + os.sep):
            shutil.rmtree(d, ignore_errors=True)

    # ---- cleanup / retention
    def cleanup(self, dry_run: bool = False) -> dict:
        """Apply the retention policy. Safe to call any time; serialized. Returns what was (or would be) removed."""
        if not self._cleanup_lock.acquire(blocking=False):
            return {"busy": True}
        try:
            return self._cleanup(dry_run)
        finally:
            self._cleanup_lock.release()

    def _cleanup(self, dry_run):
        cfg = self.cfg
        now = _dt.datetime.now(_dt.timezone.utc)
        rep = {"dry_run": dry_run, "at": now_iso(), "runs_pruned": [], "jobs_pruned": [], "job_inputs_removed": 0,
               "scratch_removed": 0, "inbox_manifests_removed": 0, "orphans_removed": 0, "errors": []}
        def iso(days):
            return (now - _dt.timedelta(days=days)).isoformat(timespec="seconds").replace("+00:00", "Z")
        data = cfg["data_dir"]
        runs_dir = os.path.join(data, "runs"); jobs_dir = os.path.join(data, "jobs")

        # 1. runs: age, count, then size
        ids = []
        try:
            if cfg["retention_days"]:
                ids += self.store.run_ids_for_pruning(created_before=iso(cfg["retention_days"]))
            if cfg["max_runs"]:
                ids += self.store.run_ids_for_pruning(keep_newest=cfg["max_runs"])
            ids = list(dict.fromkeys(ids))
            if cfg["max_data_mb"]:
                budget = cfg["max_data_mb"] * 1024 * 1024
                remaining, cursor = self.store.list_runs(limit=200), None
                sizes = {}
                if os.path.isdir(runs_dir):
                    for rid in os.listdir(runs_dir):
                        sizes[rid] = _dir_size(os.path.join(runs_dir, rid))
                total = sum(sizes.values())
                if total > budget:
                    oldest = self.store.run_ids_for_pruning(keep_newest=0)   # all, oldest first
                    for rid in oldest:
                        if total <= budget:
                            break
                        if rid not in ids:
                            ids.append(rid)
                        total -= sizes.get(rid, 0)
        except Exception as e:
            rep["errors"].append(f"run selection: {e}")
        with self._active_lock:
            active = set(self._active)
        active |= {self.run_id_for_job(j["id"]) for j in self.store.list_jobs(status="running", limit=1000)}
        active |= {j["id"] for j in self.store.list_jobs(status="running", limit=1000)}
        ids = [i for i in ids if i not in active]
        for rid in ids:
            rep["runs_pruned"].append(rid)
            if dry_run:
                continue
            try:
                self.store.delete_run(rid, keep_feedback=cfg["keep_feedback_on_prune"])
                if ID_PATTERN.match(rid):
                    shutil.rmtree(os.path.join(runs_dir, rid), ignore_errors=True)
            except Exception as e:
                rep["errors"].append(f"run {rid}: {e}")

        # 2. terminal jobs older than job retention (+ their input copies)
        if cfg["job_retention_days"]:
            try:
                before = iso(cfg["job_retention_days"])
                if dry_run:
                    rep["jobs_pruned"] = [j["id"] for j in self.store.list_jobs(limit=10000)
                                          if j["status"] in ("done", "failed", "cancelled") and (j.get("finished_at") or j["created_at"]) < before]
                else:
                    rep["jobs_pruned"] = self.store.delete_jobs(("done", "failed", "cancelled"), before)
                    for jid in rep["jobs_pruned"]:
                        if ID_PATTERN.match(jid):
                            shutil.rmtree(os.path.join(jobs_dir, jid), ignore_errors=True)
            except Exception as e:
                rep["errors"].append(f"jobs: {e}")

        # 3. job input folders whose job no longer exists or is terminal (orphans). A folder is only an
        #    orphan once it is older than the grace period, so a job being created right now is safe.
        def stale(path):
            try:
                return time.time() - os.path.getmtime(path) > ORPHAN_GRACE_SECONDS
            except OSError:
                return False
        if os.path.isdir(jobs_dir):
            for jid in os.listdir(jobs_dir):
                if jid in active or not ID_PATTERN.match(jid):
                    continue
                job = self.store.get_job(jid)
                if job is None and not stale(os.path.join(jobs_dir, jid)):
                    continue
                if job is None or job["status"] in ("done", "failed", "cancelled"):
                    rep["job_inputs_removed"] += 1
                    if not dry_run:
                        shutil.rmtree(os.path.join(jobs_dir, jid), ignore_errors=True)

        # 4. scratch artifacts (persist:false compares, CLI runs) older than the TTL
        ttl = cfg["scratch_ttl_minutes"] * 60
        if os.path.isdir(pipeline.ARTIFACT_DIR):
            for name in os.listdir(pipeline.ARTIFACT_DIR):
                if not ID_PATTERN.match(name):
                    continue
                d = os.path.join(pipeline.ARTIFACT_DIR, name)
                try:
                    if os.path.isdir(d) and time.time() - os.path.getmtime(d) > ttl:
                        rep["scratch_removed"] += 1
                        if not dry_run:
                            shutil.rmtree(d, ignore_errors=True)
                except OSError:
                    pass

        # 5. run folders with no store record (orphans)
        if os.path.isdir(runs_dir):
            for rid in os.listdir(runs_dir):
                if rid in rep["runs_pruned"] or rid in active or not ID_PATTERN.match(rid):
                    continue
                if self.store.get_run(rid) is None and stale(os.path.join(runs_dir, rid)):
                    rep["orphans_removed"] += 1
                    if not dry_run:
                        shutil.rmtree(os.path.join(runs_dir, rid), ignore_errors=True)

        # 6. acknowledged inbox manifests (.done/.failed/.error.txt) older than the inbox TTL; producer files untouched
        if cfg["inbox_ttl_days"]:
            for src in self.sources:
                inbox = getattr(src, "inbox", None)
                if not inbox or not os.path.isdir(inbox):
                    continue
                cutoff = time.time() - cfg["inbox_ttl_days"] * 86400
                for fn in os.listdir(inbox):
                    if fn.endswith((".json.done", ".json.failed", ".json.error.txt")):
                        p = os.path.join(inbox, fn)
                        try:
                            if not os.path.islink(p) and os.path.getmtime(p) < cutoff:
                                rep["inbox_manifests_removed"] += 1
                                if not dry_run:
                                    os.remove(p)
                        except OSError:
                            pass
        rep["data_dir_mb"] = round(_dir_size(data) / (1024 * 1024), 1) if os.path.isdir(data) else 0
        rep["runs_dir_mb"] = round(_dir_size(runs_dir) / (1024 * 1024), 1) if os.path.isdir(runs_dir) else 0
        if not dry_run:
            self.last_cleanup = rep
        return rep

    def _cleanup_loop(self):
        self._stop.wait(5)
        while not self._stop.is_set():
            try:
                self.cleanup()
            except Exception:
                traceback.print_exc()
            self._stop.wait(self.cfg["cleanup_interval"])

    def process_one(self, worker_id="inline") -> Optional[dict]:
        job = self.store.claim_next_job(worker_id)
        return self.run_job(job) if job else None

    def _worker_loop(self, worker_id):
        while not self._stop.is_set():
            try:
                if self.process_one(worker_id) is None:
                    self._stop.wait(1.0)
            except Exception:
                traceback.print_exc()
                self._stop.wait(2.0)

    # ---- intake
    def poll_once(self) -> dict:
        """One intake pass over every source, serialized so two callers can never double-enqueue."""
        if not self._poll_lock.acquire(blocking=False):
            return {"created": 0, "skipped_duplicates": 0, "errors": [], "busy": True}
        try:
            created = 0; skipped = 0; errors = []
            def enqueue(item):
                nonlocal created, skipped
                _, made = self.enqueue(item["source"], item["target"], item.get("options"), item.get("labels"),
                                       item.get("idempotency_key"), origin="intake", batch=item.get("batch"))
                created += made; skipped += (not made)
            for src in self.sources:
                try:
                    if isinstance(src, InboxSource):
                        src.poll(enqueue)               # acknowledges manifests only after durable enqueue
                    else:
                        for item in src.poll():
                            try:
                                enqueue(item)
                            except Exception as e:
                                errors.append(f"{src.kind}: {type(e).__name__}: {e}")
                except Exception as e:
                    errors.append(f"{src.kind}: {type(e).__name__}: {e}")
            return {"created": created, "skipped_duplicates": skipped, "errors": errors}
        finally:
            self._poll_lock.release()

    def _intake_loop(self):
        while not self._stop.is_set():
            try:
                self.poll_once()
            except Exception:
                traceback.print_exc()
            self._stop.wait(self.cfg["intake_interval"])

    # ---- feedback
    def add_feedback(self, run_id: str, body: dict) -> dict:
        run = self.store.get_run(run_id)
        if not run:
            raise KeyError(run_id)
        verdict = body.get("verdict")
        if verdict not in FEEDBACK_VERDICTS:
            raise ConfigError(f"verdict must be one of {FEEDBACK_VERDICTS}")
        if body.get("expected_severity") not in (None,) + FEEDBACK_SEVERITIES:
            raise ConfigError(f"expected_severity must be one of {FEEDBACK_SEVERITIES}")
        if body.get("expected_category") not in (None,) + FEEDBACK_CATEGORIES:
            raise ConfigError(f"expected_category must be one of {FEEDBACK_CATEGORIES}")
        for k in ("comment", "reviewer"):
            if body.get(k) is not None and not isinstance(body[k], str):
                raise ConfigError(f"{k} must be a string")
        finding_id = body.get("finding_id")
        finding = None
        if finding_id is not None:
            finding = next((f for f in run["result"]["findings"] if f["id"] == finding_id), None)
            if finding is None:
                raise ConfigError(f"finding {finding_id!r} not in run")
        fb = {"id": new_id("fb"), "run_id": run_id, "created_at": now_iso(),
              "finding_id": finding_id, "verdict": verdict,
              "provenance": {**run.get("provenance", {}), "options": run.get("options", {}),
                             "source_sha256": run.get("source_sha256"), "target_sha256": run.get("target_sha256")},
              "expected_category": body.get("expected_category"), "expected_severity": body.get("expected_severity"),
              "comment": str(body.get("comment") or "")[:4000], "reviewer": str(body.get("reviewer") or "")[:200],
              "finding": finding,
              "context": {"source_kind": run["result"]["source"]["kind"], "target_kind": run["result"]["target"]["kind"],
                          "engines": [e["name"] for e in run["result"]["engines"] if e["status"] == "ok"],
                          "labels": run.get("labels", {}), "verdict": run["verdict"]["status"],
                          "source_text_excerpt": _excerpt(run["result"]["source"]), "target_text_excerpt": _excerpt(run["result"]["target"])}}
        self.store.add_feedback(fb)
        return fb

    def export_feedback(self, since=None):
        for fb in self.store.iter_feedback(since):
            yield {"feedback_id": fb["id"], "run_id": fb["run_id"], "finding_id": fb.get("finding_id"),
                   "finding": fb.get("finding"), "verdict": fb["verdict"],
                   "expected": {"category": fb.get("expected_category"), "severity": fb.get("expected_severity")},
                   "comment": fb.get("comment", ""), "reviewer": fb.get("reviewer", ""),
                   "context": fb.get("context", {}), "provenance": fb.get("provenance", {}), "created_at": fb["created_at"]}

    # ---- status / config
    def status(self) -> dict:
        counts = self.store.job_counts()
        return {"intake": self.sources[0].status() if self.sources else {"enabled": False},
                "sources": [s.status() for s in self.sources],
                "worker": {"running": any(t.is_alive() for t in self._threads if t.name.startswith("comparer-worker")),
                           "workers": self.cfg["workers"], "queued": counts.get("queued", 0), "running_jobs": counts.get("running", 0),
                           "done": counts.get("done", 0), "failed": counts.get("failed", 0), "cancelled": counts.get("cancelled", 0)},
                "store": {**self.store.health(), "runs": self.store.count_runs()},
                "cleanup": {"policy": {k: self.cfg[k] for k in ("retention_days", "max_runs", "max_data_mb", "job_retention_days",
                                                                 "scratch_ttl_minutes", "inbox_ttl_days", "cleanup_interval", "keep_feedback_on_prune")},
                            "last": self.last_cleanup,
                            "data_dir_mb": round(_dir_size(self.cfg["data_dir"]) / (1024 * 1024), 1) if os.path.isdir(self.cfg["data_dir"]) else 0,
                            "scratch_mb": round(_dir_size(pipeline.ARTIFACT_DIR) / (1024 * 1024), 1) if os.path.isdir(pipeline.ARTIFACT_DIR) else 0},
                "plugin_errors": self.plugin_errors, "started_at": self.started_at}

    def public_config(self) -> dict:
        from .engines import vision_llm
        return {"brand": self.cfg["brand"], "config_file": bool(self.cfg.get("config_file")),
                "automation": {"enabled": True, "intake_enabled": bool(self.sources), "worker": "thread" if self.cfg["workers"] else "none",
                               "workers": self.cfg["workers"], "token_required": bool(self.cfg["token"])},
                "store": {"kind": self.store.kind, "path": self.cfg["store_path"]},
                "vision": {"providers_configured": vision_llm.configured_providers(),
                           "provider_plugins": vision_llm.plugin_providers(),
                           "pinned": os.environ.get("COMPARER_VISION_PROVIDER") or None,
                           "error": vision_llm.pin_error(),
                           "model_default": os.environ.get("COMPARER_VISION_MODEL"),
                           "models_allowed": [m for m in os.environ.get("COMPARER_VISION_MODELS", "").split(",") if m.strip()]},
                "engines": pipeline.engine_availability(), "version": __version__}


def _dir_size(path: str) -> int:
    total = 0
    for root, _, files in os.walk(path):
        for fn in files:
            try:
                total += os.path.getsize(os.path.join(root, fn))
            except OSError:
                pass
    return total


def _excerpt(doc: dict, n=400) -> str:
    return " ".join(p.get("text", "") for p in doc.get("pages", []))[:n]
