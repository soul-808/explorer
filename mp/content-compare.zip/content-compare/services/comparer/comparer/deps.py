"""Optional dependency probing. Import once, never raise."""
from __future__ import annotations

import importlib
import shutil
import subprocess
from functools import lru_cache
from typing import Optional


@lru_cache(maxsize=None)
def module(name: str):
    try:
        return importlib.import_module(name)
    except Exception:  # ImportError or a broken native lib
        return None


def version_of(mod) -> Optional[str]:
    if mod is None:
        return None
    for attr in ("__version__", "VERSION", "version"):
        v = getattr(mod, attr, None)
        if isinstance(v, str):
            return v
        if isinstance(v, tuple):
            return ".".join(str(x) for x in v)
    return None


@lru_cache(maxsize=None)
def binary(name: str) -> Optional[str]:
    return shutil.which(name)


@lru_cache(maxsize=None)
def binary_version(name: str, flag: str = "--version") -> Optional[str]:
    path = binary(name)
    if not path:
        return None
    try:
        out = subprocess.run([path, flag], capture_output=True, text=True, timeout=10)
        line = (out.stdout or out.stderr).strip().splitlines()
        return line[0][:80] if line else None
    except Exception:
        return None


def pillow():
    return module("PIL.Image")


def numpy():
    return module("numpy")
