"""Turn an uploaded file into a Document of Pages (image + text + word boxes).

Every backend is optional. Order of preference per kind:
  image : Pillow -> header-only (dimensions, raw bytes kept for the vision engine)
  pdf   : render  pypdfium2 -> pdftoppm CLI -> PyMuPDF (opt-in) -> none
          text    pypdfium2 charboxes (word boxes) -> pypdf -> pdftotext CLI -> PyMuPDF (opt-in)
  docx  : stdlib zipfile + xml
  txt   : stdlib
"""
from __future__ import annotations

import io
import os
import re
import struct
import subprocess
import tempfile
import threading
import zipfile
from xml.etree import ElementTree as ET

# PDFium is not thread-safe; the HTTP server is threaded, so serialise all pypdfium2 work.
_PDFIUM_LOCK = threading.Lock()

from . import deps
from .models import Document, Page, Word

MAX_PAGES = int(os.environ.get("COMPARER_MAX_PAGES", "10"))
RENDER_DPI = int(os.environ.get("COMPARER_RENDER_DPI", "110"))
MAX_ZIP_EXPANDED = int(os.environ.get("COMPARER_MAX_ZIP_MB", "200")) * 1024 * 1024
ALLOW_PYMUPDF = os.environ.get("COMPARER_ALLOW_PYMUPDF", "").lower() in ("1", "true", "yes")

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tif", ".tiff"}
TEXT_EXT = {".txt", ".md", ".markdown", ".csv", ".json", ".html", ".htm"}


def detect_kind(name: str, data: bytes) -> str:
    ext = os.path.splitext(name or "")[1].lower()
    head = data[:16]
    if head.startswith(b"%PDF"):
        return "pdf"
    if head.startswith(b"PK\x03\x04") and (ext == ".docx" or b"word/" in data[:4096]):
        return "docx"
    if head.startswith((b"\x89PNG", b"\xff\xd8", b"GIF8", b"BM", b"RIFF", b"II*\x00", b"MM\x00*")):
        return "image"
    if ext in IMAGE_EXT:
        return "image"
    if ext == ".pdf":
        return "pdf"
    if ext == ".docx":
        return "docx"
    if ext in TEXT_EXT:
        return "txt"
    # last resort: does it decode as text?
    try:
        data[:4096].decode("utf-8")
        return "txt"
    except UnicodeDecodeError:
        return "image"


def load(name: str, data: bytes) -> Document:
    kind = detect_kind(name, data)
    doc = Document(name=name, kind=kind)
    if kind == "image":
        _load_image(doc, data)
    elif kind == "pdf":
        _load_pdf(doc, data)
    elif kind == "docx":
        _load_docx(doc, data)
    else:
        _load_txt(doc, data)
    return doc


# --------------------------------------------------------------------------- images

def _image_dims(data: bytes) -> tuple[int, int, str]:
    """Header-only dimension sniffing (PNG/GIF/JPEG/BMP) when Pillow is missing."""
    if data.startswith(b"\x89PNG") and len(data) >= 24:
        w, h = struct.unpack(">II", data[16:24])
        return w, h, "png"
    if data.startswith(b"GIF8") and len(data) >= 10:
        w, h = struct.unpack("<HH", data[6:10])
        return w, h, "gif"
    if data.startswith(b"BM") and len(data) >= 26:
        w, h = struct.unpack("<ii", data[18:26])
        return w, abs(h), "bmp"
    if data.startswith(b"\xff\xd8"):
        i = 2
        while i + 9 < len(data):
            if data[i] != 0xFF:
                i += 1
                continue
            marker = data[i + 1]
            if marker in (0xC0, 0xC1, 0xC2):
                h, w = struct.unpack(">HH", data[i + 5:i + 9])
                return w, h, "jpeg"
            seglen = struct.unpack(">H", data[i + 2:i + 4])[0]
            i += 2 + seglen
        return 0, 0, "jpeg"
    return 0, 0, "unknown"


def _load_image(doc: Document, data: bytes) -> None:
    page = Page(index=0, image_bytes=data)
    PIL = deps.pillow()
    if PIL is not None:
        try:
            im = PIL.open(io.BytesIO(data))
            im.load()
            page.image_format = (im.format or "png").lower()
            try:  # honour camera/EXIF orientation so boxes match what a viewer shows
                from PIL import ImageOps
                im = ImageOps.exif_transpose(im) or im
            except Exception:
                pass
            if im.mode not in ("RGB", "RGBA"):
                im = im.convert("RGB")
            page.image = im
            page.width, page.height = im.size
            doc.pages.append(page)
            return
        except Exception as e:  # corrupt or unsupported image
            doc.notes.append(f"Pillow could not decode image: {e}")
    w, h, fmt = _image_dims(data)
    page.width, page.height, page.image_format = w, h, fmt
    if PIL is None:
        doc.notes.append("Pillow not installed: image kept as bytes only (no pixel/OCR engines).")
    doc.pages.append(page)


# --------------------------------------------------------------------------- pdf

def _load_pdf(doc: Document, data: bytes) -> None:
    rendered = False
    texted = False
    pdfium = deps.module("pypdfium2")
    if pdfium is not None:
        try:
            with _PDFIUM_LOCK:
                rendered, texted = _pdf_pdfium(doc, data, pdfium)
        except Exception as e:
            doc.notes.append(f"pypdfium2 failed: {e}")
    if not rendered and deps.binary("pdftoppm"):
        try:
            rendered = _pdf_pdftoppm(doc, data)
        except Exception as e:
            doc.notes.append(f"pdftoppm failed: {e}")
    if not texted:
        pypdf = deps.module("pypdf")
        if pypdf is not None:
            try:
                texted = _pdf_pypdf(doc, data, pypdf)
            except Exception as e:
                doc.notes.append(f"pypdf failed: {e}")
    if not texted and deps.binary("pdftotext"):
        try:
            texted = _pdf_pdftotext(doc, data)
        except Exception as e:
            doc.notes.append(f"pdftotext failed: {e}")
    if (not rendered or not texted) and ALLOW_PYMUPDF and deps.module("fitz") is not None:
        try:
            r, t = _pdf_pymupdf(doc, data, rendered, texted)
            rendered, texted = rendered or r, texted or t
        except Exception as e:
            doc.notes.append(f"PyMuPDF failed: {e}")
    if doc.total_pages is None and len(doc.pages) >= MAX_PAGES:
        reason = f"PDF reached the {MAX_PAGES}-page limit; total page count could not be verified."
        doc.coverage_limits.append(reason)
        doc.notes.append(reason)
    if not doc.pages:
        doc.pages.append(Page(index=0))
    if not rendered:
        doc.notes.append("PDF pages not rendered (install pypdfium2, or poppler's pdftoppm). Visual engines skipped.")
    if not texted:
        doc.notes.append("PDF text not extracted (install pypdfium2 or pypdf, or poppler's pdftotext).")


def _record_page_count(doc: Document, count: int) -> None:
    doc.total_pages = count
    if count > MAX_PAGES:
        reason = f"PDF has {count} pages; only the first {MAX_PAGES} compared."
        if reason not in doc.coverage_limits:
            doc.coverage_limits.append(reason)
            doc.notes.append(reason)


def _record_pdfinfo(doc: Document, filename: str) -> None:
    if doc.total_pages is not None or not deps.binary("pdfinfo"):
        return
    try:
        out = subprocess.run(["pdfinfo", filename], check=True, capture_output=True, timeout=15)
        match = re.search(r"^Pages:\s+(\d+)", out.stdout.decode("utf-8", "replace"), re.M)
        if match:
            _record_page_count(doc, int(match.group(1)))
    except (OSError, subprocess.SubprocessError):
        pass  # Unknown totals are treated conservatively if the cap is reached.


def _ensure_page(doc: Document, i: int) -> Page:
    while len(doc.pages) <= i:
        doc.pages.append(Page(index=len(doc.pages)))
    return doc.pages[i]


def _pdf_pdfium(doc, data, pdfium) -> tuple[bool, bool]:
    pdf = pdfium.PdfDocument(data)
    n = min(len(pdf), MAX_PAGES)
    _record_page_count(doc, len(pdf))
    PIL = deps.pillow()
    rendered = texted = False
    scale = RENDER_DPI / 72.0
    for i in range(n):
        pg = pdf[i]
        page = _ensure_page(doc, i)
        pw, ph = pg.get_width(), pg.get_height()
        try:
            rotation = pg.get_rotation()
        except Exception:
            rotation = 0
        # text + word boxes from character boxes
        try:
            tp = pg.get_textpage()
            count = tp.count_chars()
            text = tp.get_text_range(0, count) if count else ""
            page.text = text
            page.text_source = "native"
            texted = True
            if count and pw and ph:
                if rotation == 0:
                    page.words = _words_from_charboxes(tp, text, count, pw, ph)
                else:
                    doc.notes.append(f"Page {i + 1} has /Rotate {rotation}: text compared but word boxes not mapped.")
        except Exception as e:
            doc.notes.append(f"pypdfium2 text failed on page {i}: {e}")
        # render
        try:
            bitmap = pg.render(scale=scale)
            if PIL is not None:
                im = bitmap.to_pil().convert("RGB")
                page.image = im
                page.width, page.height = im.size
                page.image_format = "png"
                rendered = True
            else:
                page.width, page.height = int(pw * scale), int(ph * scale)
        except Exception as e:
            doc.notes.append(f"pypdfium2 render failed on page {i}: {e}")
    return rendered, texted


def _words_from_charboxes(tp, text, count, pw, ph) -> list[Word]:
    words: list[Word] = []
    cur: list[str] = []
    box = None
    def flush():
        nonlocal cur, box
        if cur and box:
            l, b, r, t = box
            words.append(Word("".join(cur), (l / pw, 1 - t / ph, max(r - l, 0) / pw, max(t - b, 0) / ph)))
        cur, box = [], None
    for i in range(count):
        ch = text[i] if i < len(text) else " "
        if ch.isspace():
            flush()
            continue
        try:
            l, b, r, t = tp.get_charbox(i)
        except Exception:
            continue
        cur.append(ch)
        box = (l, b, r, t) if box is None else (min(box[0], l), min(box[1], b), max(box[2], r), max(box[3], t))
    flush()
    return words


def _pdf_pdftoppm(doc, data) -> bool:
    PIL = deps.pillow()
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, "in.pdf")
        with open(src, "wb") as f:
            f.write(data)
        _record_pdfinfo(doc, src)
        subprocess.run(["pdftoppm", "-png", "-r", str(RENDER_DPI), "-l", str(MAX_PAGES), src, os.path.join(td, "p")],
                       check=True, capture_output=True, timeout=120)
        files = sorted(f for f in os.listdir(td) if f.startswith("p") and f.endswith(".png"))
        for i, fn in enumerate(files):
            page = _ensure_page(doc, i)
            with open(os.path.join(td, fn), "rb") as f:
                page.image_bytes = f.read()
            page.image_format = "png"
            if PIL is not None:
                im = PIL.open(io.BytesIO(page.image_bytes)).convert("RGB")
                page.image = im
                page.width, page.height = im.size
            else:
                page.width, page.height, _ = _image_dims(page.image_bytes)
        return bool(files)


def _pdf_pypdf(doc, data, pypdf) -> bool:
    reader = pypdf.PdfReader(io.BytesIO(data))
    _record_page_count(doc, len(reader.pages))
    n = min(len(reader.pages), MAX_PAGES)
    for i in range(n):
        page = _ensure_page(doc, i)
        if not page.text:
            page.text = reader.pages[i].extract_text() or ""
            page.text_source = "native"
    return n > 0


def _pdf_pdftotext(doc, data) -> bool:
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, "in.pdf")
        with open(src, "wb") as f:
            f.write(data)
        _record_pdfinfo(doc, src)
        out = subprocess.run(["pdftotext", "-layout", "-l", str(MAX_PAGES), src, "-"],
                             check=True, capture_output=True, timeout=60)
        pages = out.stdout.decode("utf-8", "replace").split("\f")
        for i, t in enumerate(pages[:MAX_PAGES]):
            if not t.strip() and i >= len(doc.pages):
                continue
            page = _ensure_page(doc, i)
            if not page.text:
                page.text = t
                page.text_source = "native"
        return True


def _pdf_pymupdf(doc, data, rendered, texted) -> tuple[bool, bool]:
    fitz = deps.module("fitz")
    PIL = deps.pillow()
    d = fitz.open(stream=data, filetype="pdf")
    _record_page_count(doc, len(d))
    r = t = False
    for i, pg in enumerate(d):
        if i >= MAX_PAGES:
            break
        page = _ensure_page(doc, i)
        if not texted:
            page.text = pg.get_text()
            page.text_source = "native"
            rect = pg.rect
            page.words = [Word(w[4], (w[0] / rect.width, w[1] / rect.height, (w[2] - w[0]) / rect.width, (w[3] - w[1]) / rect.height))
                          for w in pg.get_text("words")]
            t = True
        if not rendered:
            pix = pg.get_pixmap(dpi=RENDER_DPI)
            page.image_bytes = pix.tobytes("png")
            page.image_format = "png"
            page.width, page.height = pix.width, pix.height
            if PIL is not None:
                page.image = PIL.open(io.BytesIO(page.image_bytes)).convert("RGB")
            r = True
    doc.notes.append("PyMuPDF used (AGPL-3.0 / commercial license; enabled via COMPARER_ALLOW_PYMUPDF).")
    return r, t


# --------------------------------------------------------------------------- docx / txt

_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def _load_docx(doc: Document, data: bytes) -> None:
    page = Page(index=0)
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            total = sum(i.file_size for i in z.infolist())
            if total > MAX_ZIP_EXPANDED:
                raise ValueError(f"DOCX expands to {total // (1024 * 1024)} MB, over the {MAX_ZIP_EXPANDED // (1024 * 1024)} MB cap")
            names = set(z.namelist())
            headers = sorted(n for n in names if re.match(r"word/header\d*\.xml$", n))
            footers = sorted(n for n in names if re.match(r"word/footer\d*\.xml$", n))
            body = _docx_paras(z.read("word/document.xml"))
            head = [t for n in headers for t in _docx_paras(z.read(n)) if t.strip()]
            foot = [t for n in footers for t in _docx_paras(z.read(n)) if t.strip()]
        parts = []
        if head:
            parts.append("[HEADER]\n" + "\n".join(dict.fromkeys(head)))
        parts.append("\n".join(body))
        if foot:
            parts.append("[FOOTER]\n" + "\n".join(dict.fromkeys(foot)))
        page.text = "\n".join(parts)
        page.text_source = "native"
    except Exception as e:
        doc.notes.append(f"DOCX parse failed: {e}")
    doc.pages.append(page)


def _docx_paras(xml: bytes) -> list[str]:
    root = ET.fromstring(xml)
    paras: list[str] = []
    for p in root.iter(_W + "p"):
        parts: list[str] = []
        for el in p.iter():
            if el.tag == _W + "t":
                parts.append(el.text or "")
            elif el.tag == _W + "tab":
                parts.append("\t")
            elif el.tag in (_W + "br", _W + "cr"):
                parts.append("\n")
        paras.append("".join(parts))
    return paras


def _load_txt(doc: Document, data: bytes) -> None:
    for enc in ("utf-8-sig", "utf-16", "latin-1"):
        try:
            text = data.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        text = data.decode("utf-8", "replace")
    if doc.name.lower().endswith((".html", ".htm")):
        text = re.sub(r"<[^>]+>", " ", text)
    doc.pages.append(Page(index=0, text=text, text_source="native"))
