"""Orchestrates loaders -> extractors -> comparators -> verdict -> overlays."""
from __future__ import annotations

import datetime as _dt
import os
import secrets
import time
import traceback

from . import __version__, loaders, overlay, rules
from .engines import ALL, COMPARATORS, EXTRACTORS
from .models import CompareResult, Document, EngineReport, Finding, Locus

ARTIFACT_DIR = os.environ.get("COMPARER_ARTIFACT_DIR") or os.path.join(os.path.dirname(os.path.dirname(__file__)), ".artifacts")
SEV_RANK = {"high": 3, "medium": 2, "low": 1, "info": 0}


def clamp_bbox(b):
    """Clamp [x, y, w, h] into the unit square; None if it collapses."""
    try:
        x, y, w, h = (float(v) for v in b)
    except (TypeError, ValueError):
        return None
    x0, y0 = min(max(x, 0.0), 1.0), min(max(y, 0.0), 1.0)
    x1, y1 = min(max(x + w, 0.0), 1.0), min(max(y + h, 0.0), 1.0)
    if x1 - x0 <= 0 or y1 - y0 <= 0:
        return None
    return (round(x0, 4), round(y0, 4), round(x1 - x0, 4), round(y1 - y0, 4))


def _coverage(source: Document, target: Document) -> dict:
    def side(doc):
        srcs = {p.text_source.split(":")[0] for p in doc.pages if p.text.strip()}
        text = "native" if "native" in srcs else "ocr" if "ocr" in srcs else "none"
        words = [w for p in doc.pages for w in p.words if p.text_source.startswith("ocr")]
        conf = round(sum(w.conf for w in words) / len(words), 3) if words else None
        readable = lambda p: bool(p.text.strip() or p.image is not None or p.image_bytes)
        return {"text": text, "ocr_confidence": conf, "pages": len(doc.pages),
                "page_indexes": [p.index for p in doc.pages], "total_pages": doc.total_pages,
                "coverage_limits": doc.coverage_limits,
                "image": any(p.image is not None or p.image_bytes for p in doc.pages),
                "unreadable_pages": [p.index for p in doc.pages if not readable(p)],
                "empty": not any(readable(p) for p in doc.pages)}
    return {"source": side(source), "target": side(target)}


class Context:
    def __init__(self, source: Document, target: Document, options: dict):
        self.source, self.target, self.options = source, target, options or {}
        self.reports: dict[str, EngineReport] = {}
        self.stats: dict = {}
        self._n = 0

    def opt(self, section, key, default=None):
        sec = self.options.get(section) or {}
        return sec.get(key, default) if isinstance(sec, dict) else default

    def finding(self, category, severity, engine, confidence, message, source=None, target=None, extra=None):
        self._n += 1
        for loc in (source, target):
            if loc is not None and loc.bbox is not None:
                loc.bbox = clamp_bbox(loc.bbox)
        return Finding(f"f{self._n}", category, severity, engine, confidence, message, source, target, extra or {})

    def report(self, name, status, **kw):
        self.reports[name] = EngineReport(name=name, status=status, **kw)

    def skip(self, name, message):
        self.report(name, "skipped", message=message)

    def unavailable(self, name, message):
        self.report(name, "unavailable", message=message)


def engine_availability() -> list[dict]:
    out = []
    for m in ALL:
        try:
            status, backend, version, message = m.availability()
        except Exception as e:  # never let a probe crash health
            status, backend, version, message = "failed", None, None, str(e)
        r = EngineReport(m.NAME, status, backend=backend, version=version, message=message)
        out.append(r.to_dict())
    return out


def compare(source_name: str, source_bytes: bytes, target_name: str, target_bytes: bytes,
            options: dict | None = None, artifact_dir: str | None = None) -> CompareResult:
    options = options or {}
    run_id = "cmp_" + _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%dT%H%M%S") + "_" + secrets.token_hex(8)
    source = loaders.load(source_name, source_bytes)
    target = loaders.load(target_name, target_bytes)
    _select_pages(source, options.get("pages", {}).get("source") if isinstance(options.get("pages"), dict) else None)
    _select_pages(target, options.get("pages", {}).get("target") if isinstance(options.get("pages"), dict) else None)

    ctx = Context(source, target, options)
    wanted = options.get("engines")
    wanted = set(str(w) for w in wanted) if isinstance(wanted, list) else None  # [] means "none", not "all"
    unknown = sorted(wanted - {m.NAME for m in ALL}) if wanted else []
    findings: list[Finding] = []
    for m in EXTRACTORS + COMPARATORS:
        if wanted is not None and m.NAME not in wanted:
            ctx.skip(m.NAME, "not requested")
            continue
        t0 = time.time()
        try:
            findings.extend(m.run(ctx))
            if m.NAME not in ctx.reports:  # engine returned without reporting -> ok
                ctx.report(m.NAME, "ok")
        except Exception as e:
            ctx.report(m.NAME, "failed", message=f"{type(e).__name__}: {e}"[:400])
            ctx.stats.setdefault("errors", []).append({"engine": m.NAME, "trace": traceback.format_exc()[-1500:]})
        ctx.reports[m.NAME].duration_ms = int((time.time() - t0) * 1000)
    # sort: severity desc, then page, then y
    findings.sort(key=lambda f: (-SEV_RANK.get(f.severity, 0),
                                 (f.target or f.source or Locus(0)).page,
                                 ((f.target or f.source or Locus(0)).bbox or (0, 0))[1]))
    for i, f in enumerate(findings, 1):
        f.id = f"f{i}"
    if unknown:
        ctx.stats["unknown_engines"] = unknown
    ctx.stats["coverage"] = _coverage(source, target)
    for side, doc in (("source", source), ("target", target)):
        cov = ctx.stats["coverage"][side]
        for limitation in doc.coverage_limits:
            reason = f"{side}: {limitation}"
            ctx.stats.setdefault("coverage_limits", []).append(reason)
            ctx.stats.setdefault("warnings", []).append(reason)
        if cov["empty"]:
            ctx.stats.setdefault("warnings", []).append(f"{side}: no readable text or image")
        elif cov["unreadable_pages"]:
            ctx.stats.setdefault("warnings", []).append(f"{side}: pages {[i + 1 for i in cov['unreadable_pages']]} unreadable")
        if doc.kind == "image" and cov["text"] == "none":
            ctx.stats.setdefault("warnings", []).append(f"{side}: image has no text layer and OCR did not run; copy not compared")

    result = CompareResult(
        id=run_id, created_at=_dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
        source=source, target=target, engines=[ctx.reports[m.NAME] for m in ALL if m.NAME in ctx.reports],
        findings=findings, stats=ctx.stats)
    result.base_verdict = _verdict(result, result.findings)
    rules.apply(result, options, ctx)
    active = [f for f in result.findings if f.disposition == "flagged"]
    result.verdict = _verdict(result, active)
    if result.base_verdict["status"] == "inconclusive":
        # rules can never turn an unverified comparison into a verified match
        result.verdict = {**result.verdict, "status": "inconclusive", "confidence": 0.0,
                          "summary": result.base_verdict["summary"]}
    result.verdict["after_rules"] = bool(options.get("rules") or options.get("rule_guidance"))
    if options.get("render_overlays", True):
        _write_artifacts(result, artifact_dir or ARTIFACT_DIR, flat=artifact_dir is not None)
    return result


def _select_pages(doc: Document, idxs):
    if isinstance(idxs, list) and idxs:
        keep = [p for p in doc.pages if p.index in idxs]
        missing = [i for i in idxs if i not in {p.index for p in keep}]
        if missing:
            doc.coverage_limits.append(f"Requested page indexes {missing} could not be loaded.")
        doc.pages = keep
        doc.notes.append(f"Comparison scoped to requested page indexes {idxs} (zero-based).")


def _verdict(r: CompareResult, findings=None) -> dict:
    findings = r.findings if findings is None else findings
    ran = [e for e in r.engines if e.status == "ok" and e.name in {m.NAME for m in COMPARATORS}]
    r.stats["engines_ran"] = len(ran)
    cov = r.stats.get("coverage", {})
    if any(cov.get(k, {}).get("empty") for k in ("source", "target")):
        return {"status": "inconclusive", "confidence": 0.0,
                "summary": "One side has no readable text or image; nothing to compare."}
    if not ran:
        why = "; ".join(f"{e.name}: {e.message}" for e in r.engines if e.message)
        return {"status": "inconclusive", "confidence": 0.0,
                "summary": "No comparison engine could run. " + (why or "")}
    counts = {}
    for f in findings:
        counts[f.category] = counts.get(f.category, 0) + 1
    real = [f for f in findings if f.severity != "info"]   # every detected difference is a mismatch
    base = min(0.95, 0.45 + 0.17 * len(ran))
    if real:
        status = "mismatch"
        weight = sum({"high": 1.0, "medium": 0.7, "low": 0.35}[f.severity] for f in real)
        conf = min(0.98, base + 0.05 * min(weight, 4))
    elif findings:
        status = "match"   # only informational notes
        conf = base * 0.9
    else:
        status = "match"
        conf = base
    if status == "match" and r.stats.get("coverage_limits"):
        return {"status": "inconclusive", "confidence": 0.0, "counts": counts,
                "summary": "Compared content has no flagged differences, but coverage is incomplete: " + "; ".join(dict.fromkeys(r.stats["coverage_limits"]))}
    unreadable = sum(len(cov.get(k, {}).get("unreadable_pages", [])) for k in ("source", "target"))
    if status == "match" and unreadable:
        return {"status": "inconclusive", "confidence": 0.0, "counts": counts,
                "summary": f"Readable pages match, but {unreadable} page(s) could not be read; see source/target notes."}
    ts = r.stats.get("text_similarity")
    if status == "match" and ts is not None:
        conf = conf * (0.5 + 0.5 * ts)
    if status == "match":
        # a match established only through OCR is only as good as the OCR was
        for k in ("source", "target"):
            oc = cov.get(k, {}).get("ocr_confidence")
            if oc is not None:
                conf = conf * (0.6 + 0.4 * oc)
        if all(cov.get(k, {}).get("text") == "none" for k in ("source", "target")) and \
                not any(e.name in ("pixel", "ssim", "vision_llm") for e in ran):
            return {"status": "inconclusive", "confidence": 0.0, "summary": "No text on either side and no visual engine ran."}
    parts = [f"{n} {c.replace('_', ' ')}" for c, n in sorted(counts.items(), key=lambda kv: -kv[1])]
    summary = ", ".join(parts) if parts else "No differences detected by " + ", ".join(e.name for e in ran)
    if r.stats.get("llm_summary"):
        summary += ". Model: " + r.stats["llm_summary"]
    return {"status": status, "confidence": round(conf, 3), "summary": summary, "counts": counts}


def _write_artifacts(r: CompareResult, root: str, flat: bool = False):
    d = root if flat else os.path.join(root, r.id)
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        return
    for side, doc in (("source", r.source), ("target", r.target)):
        for p in doc.pages:
            base = f"{side}-{p.index}"
            if p.image is not None:
                try:
                    p.image.save(os.path.join(d, base + ".png"))
                    p.image_url = f"/api/artifacts/{r.id}/{base}.png"
                    ann = overlay.annotate(p.image, [f for f in r.findings if f.disposition == "flagged"], side, p.index)
                    if ann is not None:
                        ann.save(os.path.join(d, base + "-annotated.png"))
                        r.overlays[side].append({"page": p.index, "image_url": f"/api/artifacts/{r.id}/{base}-annotated.png"})
                except Exception:
                    pass
            elif p.image_bytes:
                ext = "jpg" if p.image_format == "jpeg" else (p.image_format or "png")
                with open(os.path.join(d, f"{base}.{ext}"), "wb") as f:
                    f.write(p.image_bytes)
                p.image_url = f"/api/artifacts/{r.id}/{base}.{ext}"
    try:
        import json
        with open(os.path.join(d, "result.json"), "w") as f:
            json.dump(r.to_dict(), f, indent=2)
    except Exception:
        pass
