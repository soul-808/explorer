"""CLI: python -m comparer {health|compare|serve}"""
from __future__ import annotations

import argparse
import json
import os
import sys


def main(argv=None):
    ap = argparse.ArgumentParser(prog="comparer", description="Compare two marketing assets and flag differences.")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("health", help="show which engines are available")

    c = sub.add_parser("compare", help="compare SOURCE (reference) against TARGET (produced)")
    c.add_argument("source"); c.add_argument("target")
    c.add_argument("--out", help="directory for result.json and annotated PNGs (default: .artifacts/<id>)")
    c.add_argument("--json", action="store_true", help="print full JSON result instead of a summary")
    c.add_argument("--engines", help="comma list, e.g. text,ocr,pixel")
    c.add_argument("--options", help="JSON options (same shape as the API)")
    c.add_argument("--vision-provider"); c.add_argument("--vision-model")
    c.add_argument("--rules", help="JSON file: either a list of rules or {\"rules\": [...], \"rule_guidance\": \"...\"}")
    c.add_argument("--guidance", help="free-form SME guidance (needs a configured vision model)")

    s = sub.add_parser("serve", help="run the HTTP API")
    s.add_argument("--host", default=os.environ.get("COMPARER_HOST", "127.0.0.1"))
    s.add_argument("--port", type=int, default=int(os.environ.get("COMPARER_PORT", "8765")))
    s.add_argument("--no-automation", action="store_true", help="manual API only: no store, jobs, intake or history")

    cl = sub.add_parser("cleanup", help="apply the retention policy to .data and scratch artifacts (server must be stopped; use POST /api/automation/cleanup while it runs)")
    cl.add_argument("--dry-run", action="store_true")
    cl.add_argument("--force", action="store_true", help="run even if a server lock is present (unsafe while it is serving)")

    a = ap.parse_args(argv)
    if a.cmd == "cleanup":
        from .automation import Automation
        auto = Automation()
        try:
            holder = auto.lock_holder()
            if holder and not a.force and not a.dry_run:
                print(json.dumps({"error": f"a comparer server (pid {holder['pid']}, started {holder['started_at']}) owns this data dir; "
                                           "use POST /api/automation/cleanup while it runs, stop it first, or pass --force"}, indent=2))
                return 2
            rep = auto.cleanup(dry_run=a.dry_run)
        finally:
            auto.stop()
        print(json.dumps(rep, indent=2))
        return 0
    if a.cmd == "health":
        from . import __version__, pipeline
        rows = pipeline.engine_availability()
        print(f"content-comparer {__version__}")
        for r in rows:
            extra = " ".join(filter(None, [r.get("backend"), r.get("version")]))
            msg = f"  - {r.get('message')}" if r.get("message") else ""
            print(f"  {r['name']:<12} {r['status']:<12} {extra}{msg}")
        return 0
    if a.cmd == "serve":
        from .server import serve
        serve(a.host, a.port, automation=not a.no_automation)
        return 0

    from . import pipeline
    options = json.loads(a.options) if a.options else {}
    if a.engines:
        options["engines"] = [e.strip() for e in a.engines.split(",") if e.strip()]
    if a.vision_provider or a.vision_model:
        options["vision"] = {k: v for k, v in (("provider", a.vision_provider), ("model", a.vision_model)) if v}
    if a.rules:
        with open(a.rules) as f:
            loaded = json.load(f)
        if isinstance(loaded, list):
            options["rules"] = loaded
        else:
            options["rules"] = loaded.get("rules", [])
            if loaded.get("rule_guidance"):
                options["rule_guidance"] = loaded["rule_guidance"]
    if a.guidance:
        options["rule_guidance"] = a.guidance
    with open(a.source, "rb") as f:
        sb = f.read()
    with open(a.target, "rb") as f:
        tb = f.read()
    res = pipeline.compare(os.path.basename(a.source), sb, os.path.basename(a.target), tb, options, artifact_dir=a.out)
    d = res.to_dict()
    if a.json:
        print(json.dumps(d, indent=2))
        return 0
    v = d["verdict"]
    print(f"{v['status'].upper()}  confidence={v['confidence']}  {v['summary']}")
    for e in d["engines"]:
        print(f"  engine {e['name']:<12} {e['status']:<12} {e.get('backend') or ''} {('- ' + e['message']) if e.get('message') else ''}")
    for f in d["findings"]:
        loc = f.get("target") or f.get("source") or {}
        where = f" p{loc.get('page', 0) + 1} bbox={loc.get('bbox')}" if loc else ""
        tag = "" if f["disposition"] == "flagged" else f"  (ignored by {', '.join(m['rule_id'] for m in f['rule_matches'])})"
        print(f"  [{f['id']}] {f['severity']:<6} {f['category']:<16} {f['message']}{where}{tag}")
    if d["verdict"].get("after_rules"):
        rr = d["rules_report"]
        print(f"rules: base={d['base_verdict']['status']} -> after rules={v['status']}; flagged={rr['counts']['flagged']} ignored={rr['counts']['ignored']} added={rr['counts']['added']}; guidance={rr['guidance']['status']}")
        for row in rr["rules"]:
            print(f"  rule {row['rule_id']:<12} {row['type']:<16} {row['status']:<10} {row.get('reason') or ''}")
    out_dir = a.out or os.path.join(pipeline.ARTIFACT_DIR, d["id"])
    print(f"artifacts: {out_dir}")
    return 0 if v["status"] == "match" else 2 if v["status"] == "mismatch" else 3


if __name__ == "__main__":
    sys.exit(main())
