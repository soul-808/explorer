"""SSIM engine: structural similarity (scikit-image).

Emits a whole-page `visual_diff` finding when a page's score falls below
options.ssim.threshold (default 0.90), so SSIM alone can never call two
different images a match. Also flags pages present on one side only.
"""
from __future__ import annotations

from .. import deps
from ..models import Locus
from .pagepairs import pair_pages

NAME = "ssim"


def availability():
    if deps.pillow() is None or deps.numpy() is None:
        return "unavailable", None, None, "needs Pillow and numpy"
    sk = deps.module("skimage.metrics")
    if sk is None:
        return "unavailable", None, None, "scikit-image not installed"
    import skimage
    return "ok", "scikit-image", getattr(skimage, "__version__", None), None


def run(ctx):
    status, backend, version, msg = availability()
    if status != "ok":
        ctx.unavailable(NAME, msg)
        return []
    import numpy as np
    from PIL import Image, ImageOps
    from skimage.metrics import structural_similarity

    threshold = float(ctx.opt("ssim", "threshold", 0.90))
    scores, findings = [], []
    pairs, findings = pair_pages(ctx, NAME, need_image=True)
    for sp, tp in pairs:
        a = ImageOps.grayscale(sp.image)
        b = ImageOps.grayscale(tp.image).resize(a.size, Image.BILINEAR)
        score = float(structural_similarity(np.asarray(a), np.asarray(b)))
        scores.append(score)
        if score < threshold:
            sev = "high" if score < 0.5 else "medium" if score < 0.75 else "low"
            findings.append(ctx.finding(
                "visual_diff", sev, NAME, min(0.9, 1 - score),
                f"Page {sp.index + 1} structural similarity {score:.3f} is below {threshold:.2f}",
                source=Locus(sp.index, (0, 0, 1, 1)), target=Locus(tp.index, (0, 0, 1, 1)), extra={"ssim": round(score, 4)}))
    if not scores and not findings:
        ctx.skip(NAME, "need images on both sides")
        return []
    if scores:
        ctx.stats["ssim"] = round(sum(scores) / len(scores), 4)
    ctx.report(NAME, "ok", backend=backend, version=version)
    return findings
