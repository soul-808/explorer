"""Pair source/target pages positionally and flag pages that exist on one side only."""
from __future__ import annotations

from ..models import Locus


def pair_pages(ctx, engine, need_image=True):
    """Return (pairs, findings). pairs = [(source_page, target_page)] where both usable.
    Pages beyond the shorter side produce a `layout_shift` finding so a pixel/ssim-only run
    can never report a clean match while pages are missing."""
    src, tgt = ctx.source.pages, ctx.target.pages
    n = min(len(src), len(tgt))
    pairs = []
    for i in range(n):
        sp, tp = src[i], tgt[i]
        if need_image and (sp.image is None or tp.image is None):
            continue
        pairs.append((sp, tp))
    findings = []
    for p in src[n:]:
        findings.append(ctx.finding("layout_shift", "medium", engine, 0.9,
                                    f"Page {p.index + 1} exists only in the source", source=Locus(p.index, (0, 0, 1, 1))))
    for p in tgt[n:]:
        findings.append(ctx.finding("layout_shift", "medium", engine, 0.9,
                                    f"Page {p.index + 1} exists only in the target", target=Locus(p.index, (0, 0, 1, 1))))
    return pairs, findings
