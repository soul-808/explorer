"""Pixel engine: absolute difference of the two page images, clustered into regions.

Pure Pillow (numpy optional, opencv not needed). The diff mask is reduced to a
coarse grid and flood-filled so it stays fast without native extensions.
"""
from __future__ import annotations

from .. import deps
from ..models import Finding, Locus
from .pagepairs import pair_pages

NAME = "pixel"


def availability():
    PIL = deps.pillow()
    if PIL is None:
        return "unavailable", None, None, "Pillow not installed"
    import PIL as _p
    return "ok", "pillow", getattr(_p, "__version__", None), None


def run(ctx):
    status, backend, version, msg = availability()
    if status != "ok":
        ctx.unavailable(NAME, msg)
        return []
    from PIL import Image, ImageChops, ImageOps

    threshold = int(ctx.opt("pixel", "threshold", 32))
    min_region = int(ctx.opt("pixel", "min_region_px", 24))
    cell = int(ctx.opt("pixel", "cell_px", 12))

    pairs, findings = pair_pages(ctx, NAME, need_image=True)
    if not pairs and not findings:
        ctx.skip(NAME, "need a decodable image on both sides (text-only documents have none)")
        return []

    ratios = []
    for sp, tp in pairs:
        pi = sp.index
        ti = tp.index
        a = sp.image.convert("RGB")
        b = tp.image.convert("RGB")
        ar = a.width / a.height
        br = b.width / b.height
        if abs(ar - br) / max(ar, br) > 0.05:
            findings.append(ctx.finding(
                "layout_shift", "medium", NAME, 0.8,
                f"Page {pi + 1} geometry differs (source {a.width}x{a.height} vs target {b.width}x{b.height}); "
                "pixel regions not computed for this page because a pixel overlay would be meaningless",
                source=Locus(pi, (0, 0, 1, 1)), target=Locus(ti, (0, 0, 1, 1))))
            continue
        if a.size != b.size:
            b = b.resize(a.size, Image.BILINEAR)
        diff = ImageOps.grayscale(ImageChops.difference(a, b))
        mask = diff.point(lambda v: 255 if v > threshold else 0)
        hist = mask.histogram()
        changed = hist[255] if len(hist) > 255 else 0
        ratio = changed / float(a.width * a.height)
        ratios.append(ratio)

        # coarse grid: mean of mask in each cell
        gw, gh = max(1, a.width // cell), max(1, a.height // cell)
        grid = mask.resize((gw, gh), Image.BOX)
        get = getattr(grid, "get_flattened_data", None) or grid.getdata
        vals = list(get())
        hot = [v > 40 for v in vals]  # >~16% of the cell changed
        for (cx0, cy0, cx1, cy1, n) in _regions(hot, gw, gh):
            pw = (cx1 - cx0 + 1) * cell
            ph = (cy1 - cy0 + 1) * cell
            if pw < min_region and ph < min_region:
                continue
            bbox = (round(cx0 * cell / a.width, 4), round(cy0 * cell / a.height, 4),
                    round(pw / a.width, 4), round(ph / a.height, 4))
            area = pw * ph / float(a.width * a.height)
            sev = "high" if area > 0.05 else "medium" if area > 0.005 else "low"
            findings.append(ctx.finding(
                "visual_diff", sev, NAME, 0.7,
                f"Visual difference region {int(pw)}x{int(ph)}px at ({int(cx0 * cell)}, {int(cy0 * cell)})",
                source=Locus(pi, bbox), target=Locus(ti, bbox), extra={"cells": n}))
    if ratios:
        ctx.stats["pixel_diff_ratio"] = round(sum(ratios) / len(ratios), 5)
    ctx.report(NAME, "ok", backend=backend, version=version)
    return findings


def _regions(hot, gw, gh):
    """Flood-fill 8-connected hot cells; yield (x0, y0, x1, y1, count)."""
    seen = [False] * (gw * gh)
    for start in range(gw * gh):
        if not hot[start] or seen[start]:
            continue
        stack = [start]
        seen[start] = True
        x0 = x1 = start % gw
        y0 = y1 = start // gw
        n = 0
        while stack:
            i = stack.pop()
            n += 1
            x, y = i % gw, i // gw
            x0, x1, y0, y1 = min(x0, x), max(x1, x), min(y0, y), max(y1, y)
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < gw and 0 <= ny < gh:
                        j = ny * gw + nx
                        if hot[j] and not seen[j]:
                            seen[j] = True
                            stack.append(j)
        yield x0, y0, x1, y1, n
