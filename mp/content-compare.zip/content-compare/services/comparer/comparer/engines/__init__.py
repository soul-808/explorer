"""Engine registry. Each engine module exposes:

    NAME: str
    availability() -> (status, backend, version, message)
    run(ctx) -> list[Finding]          # may raise; the pipeline records `failed`

`ctx` is a comparer.pipeline.Context.
"""
from __future__ import annotations

from . import ocr, pixel, ssim, text, vision_llm

# Extraction engines run first (they enrich pages), comparison engines second.
EXTRACTORS = [ocr]
COMPARATORS = [text, pixel, ssim, vision_llm]
ALL = EXTRACTORS + COMPARATORS

BY_NAME = {m.NAME: m for m in ALL}
