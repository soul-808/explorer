"""Text normalisation + token diff shared by the text and OCR engines."""
from __future__ import annotations

import difflib
import re
import unicodedata

_PUNCT = re.compile(r"[^\w\s%$€£&@#+/-]", re.UNICODE)
_WS = re.compile(r"\s+")

# OCR/typography confusions we don't want to flag as copy differences.
_EQUIV = str.maketrans({
    "‘": "'", "’": "'", "“": '"', "”": '"',
    "–": "-", "—": "-", "−": "-", " ": " ", "…": "...",
})


def normalize(text: str, ignore_case=True, ignore_punct=False) -> str:
    t = unicodedata.normalize("NFKC", text or "").translate(_EQUIV)
    if ignore_case:
        t = t.lower()
    if ignore_punct:
        t = _PUNCT.sub(" ", t)
    return _WS.sub(" ", t).strip()


def tokens(text: str, **kw) -> list[str]:
    return normalize(text, **kw).split()


def similarity(a: str, b: str, **kw) -> float:
    ta, tb = tokens(a, **kw), tokens(b, **kw)
    if not ta and not tb:
        return 1.0
    return difflib.SequenceMatcher(a=ta, b=tb, autojunk=False).ratio()


def diff_ops(a_tokens: list[str], b_tokens: list[str]):
    """Yield (tag, i1, i2, j1, j2) for non-equal opcodes, merging tiny gaps."""
    sm = difflib.SequenceMatcher(a=a_tokens, b=b_tokens, autojunk=False)
    return [op for op in sm.get_opcodes() if op[0] != "equal"]


def token_similarity(a: str, b: str) -> float:
    return difflib.SequenceMatcher(a=a, b=b).ratio()
