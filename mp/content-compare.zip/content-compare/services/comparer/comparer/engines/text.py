"""Text engine: token diff of extracted text (native or OCR) between source and target.

Maps each differing token run back to word boxes when a side has geometry.
"""
from __future__ import annotations

from ..models import Finding, Locus, Word
from . import textnorm

NAME = "text"


def availability():
    return "ok", "difflib", None, None


def _page_tokens(page, opts):
    """Return (tokens, boxes) aligned lists. boxes[i] may be None."""
    if page.words:
        toks, boxes = [], []
        for w in page.words:
            for t in textnorm.tokens(w.text, **opts):
                toks.append(t)
                boxes.append(w.bbox)
        return toks, boxes
    toks = textnorm.tokens(page.text, **opts)
    return toks, [None] * len(toks)


def _union(boxes):
    boxes = [b for b in boxes if b]
    if not boxes:
        return None
    x0 = min(b[0] for b in boxes); y0 = min(b[1] for b in boxes)
    x1 = max(b[0] + b[2] for b in boxes); y1 = max(b[1] + b[3] for b in boxes)
    return (round(x0, 4), round(y0, 4), round(x1 - x0, 4), round(y1 - y0, 4))


def run(ctx):
    opts = {"ignore_case": ctx.opt("text", "ignore_case", True),
            "ignore_punct": ctx.opt("text", "ignore_punctuation", False)}
    if ctx.opt("text", "ignore_whitespace", True) is False:
        ctx.stats.setdefault("warnings", []).append(
            "text.ignore_whitespace=false is not supported: whitespace runs are always collapsed before diffing")
    src_pages = [p for p in ctx.source.pages if p.text.strip()]
    tgt_pages = [p for p in ctx.target.pages if p.text.strip()]
    if not src_pages or not tgt_pages:
        missing = "source" if not src_pages else "target"
        ctx.skip(NAME, f"{missing} has no extractable text (native or OCR)")
        return []

    findings = []
    sims = []
    if len(ctx.source.pages) != len(ctx.target.pages):
        # e.g. a one-page copy deck vs a 3-page PDF: compare the whole text stream, not page by page
        return _compare_streams(ctx, opts, sims, findings)
    n = max(len(ctx.source.pages), len(ctx.target.pages))
    for pi in range(n):
        sp = ctx.source.pages[pi]
        tp = ctx.target.pages[pi]
        spi, tpi = sp.index, tp.index
        a, abox = _page_tokens(sp, opts)
        b, bbox = _page_tokens(tp, opts)
        same_geom = _same_geometry(sp, tp)
        sims.append(textnorm.similarity(" ".join(a), " ".join(b)))
        for tag, i1, i2, j1, j2 in textnorm.diff_ops(a, b):
            a_txt = " ".join(a[i1:i2]); b_txt = " ".join(b[j1:j2])
            if tag == "replace":
                cat = "text_changed"
                sev = "high" if textnorm.token_similarity(a_txt, b_txt) < 0.6 else "medium"
                msg = f'Source says "{a_txt}" but target shows "{b_txt}"'
                conf = 0.85
            elif tag == "delete":
                cat, sev, conf = "text_missing", "high", 0.85
                msg = f'Missing in target: "{a_txt}"'
            else:
                cat, sev, conf = "text_extra", "medium", 0.8
                msg = f'Extra in target: "{b_txt}"'
            # OCR text is noisier: downgrade single-token, near-identical replacements.
            noisy = sp.text_source.startswith("ocr") or tp.text_source.startswith("ocr")
            if noisy and tag == "replace":
                sev, conf, msg = _ocr_noise_downgrade(a_txt, b_txt, i2 - i1, j2 - j1, sev, conf, msg)
            a_box, b_box = _union(abox[i1:i2]), _union(bbox[j1:j2])
            if tag == "insert":
                # nothing on the source side: mark where the extra text sits (mirror the target box
                # if the source has geometry, else point at the neighbouring word)
                src = Locus(spi, b_box if same_geom and b_box else _anchor_box(abox, i1), None)
                tgt = Locus(tpi, b_box, b_txt)
            elif tag == "delete":
                src = Locus(spi, a_box, a_txt)
                tgt = Locus(tpi, a_box if same_geom and a_box else _anchor_box(bbox, j1), None)
            else:
                src, tgt = Locus(spi, a_box, a_txt), Locus(tpi, b_box, b_txt)
            findings.append(ctx.finding(cat, sev, NAME, conf, msg, source=src, target=tgt))
    if sims:
        ctx.stats["text_similarity"] = round(sum(sims) / len(sims), 4)
    return pair_moved(findings, ctx)


def _ocr_noise_downgrade(a_txt, b_txt, na, nb, sev, conf, msg):
    """OCR text is noisy: near-identical single tokens ('fees' vs 'fees.') and spacing-only
    splits ('APY is' vs 'APYis') are downgraded. Anything involving a digit is never
    downgraded: '4.25%' vs '4.75%' is exactly the kind of change this tool exists to catch."""
    if any(ch.isdigit() for ch in a_txt + b_txt):
        return sev, conf, msg
    if a_txt.replace(" ", "") == b_txt.replace(" ", ""):
        return "low", 0.4, msg + " (spacing only; likely OCR word split)"
    if na == 1 and nb == 1 and textnorm.token_similarity(a_txt, b_txt) >= 0.8:
        return "low", 0.5, msg + " (possible OCR noise)"
    return sev, conf, msg


def _doc_tokens(doc, opts):
    toks, metas = [], []
    for p in doc.pages:
        t, b = _page_tokens(p, opts)
        toks.extend(t)
        metas.extend((p.index, bb) for bb in b)
    return toks, metas


def _locus(metas, i1, i2, text):
    if i2 <= i1:
        return None
    page = metas[i1][0]
    boxes = [b for (pg, b) in metas[i1:i2] if pg == page]
    return Locus(page, _union(boxes), text)


def _compare_streams(ctx, opts, sims, findings):
    a, am = _doc_tokens(ctx.source, opts)
    b, bm = _doc_tokens(ctx.target, opts)
    sims.append(textnorm.similarity(" ".join(a), " ".join(b)))
    for tag, i1, i2, j1, j2 in textnorm.diff_ops(a, b):
        a_txt = " ".join(a[i1:i2]); b_txt = " ".join(b[j1:j2])
        if tag == "replace":
            cat = "text_changed"; conf = 0.85
            sev = "high" if textnorm.token_similarity(a_txt, b_txt) < 0.6 else "medium"
            msg = f'Source says "{a_txt}" but target shows "{b_txt}"'
            if any(p.text_source.startswith("ocr") for p in ctx.source.pages + ctx.target.pages):
                sev, conf, msg = _ocr_noise_downgrade(a_txt, b_txt, i2 - i1, j2 - j1, sev, conf, msg)
        elif tag == "delete":
            cat, sev, conf, msg = "text_missing", "high", 0.85, f'Missing in target: "{a_txt}"'
        else:
            cat, sev, conf, msg = "text_extra", "medium", 0.8, f'Extra in target: "{b_txt}"'
        src = _locus(am, i1, i2, a_txt) or Locus(am[min(max(i1 - 1, 0), len(am) - 1)][0] if am else 0)
        tgt = _locus(bm, j1, j2, b_txt) or Locus(bm[min(max(j1 - 1, 0), len(bm) - 1)][0] if bm else 0)
        findings.append(ctx.finding(cat, sev, NAME, conf, msg, source=src, target=tgt))
    ctx.stats["text_similarity"] = round(sims[0], 4)
    ctx.stats["text_mode"] = "whole_document"
    return pair_moved(findings, ctx)


def pair_moved(findings, ctx):
    """A delete and an insert with the same normalised text are one 'text_moved' finding
    (order differs, e.g. OCR column interleaving vs. a copy deck), not missing + extra copy."""
    missing = [f for f in findings if f.category == "text_missing" and f.source and f.source.text]
    extra = [f for f in findings if f.category == "text_extra" and f.target and f.target.text]
    used = set()
    out = []
    cross_kind = ctx.source.kind != ctx.target.kind
    for m in missing:
        key = textnorm.normalize(m.source.text)
        match = next((e for e in extra if id(e) not in used and textnorm.normalize(e.target.text) == key), None)
        if match is None or len(key.split()) < 2 and len(key) < 4:
            out.append(m)
            continue
        used.add(id(match))
        out.append(ctx.finding("text_moved", "info" if cross_kind else "low", NAME, 0.7,
                               f'"{m.source.text}" appears in a different position in the target',
                               source=m.source, target=match.target))
    for f in findings:
        if f.category == "text_missing" and f in missing:
            continue
        if f.category == "text_extra" and id(f) in used:
            continue
        if f.category == "text_missing":
            continue
        out.append(f)
    return out


def _same_geometry(sp, tp) -> bool:
    """True when both pages have images of (nearly) the same aspect ratio, so a box on one
    side can be mirrored onto the other as 'expected here'."""
    if not (sp.has_geometry() and tp.has_geometry()):
        return False
    ar, br = sp.width / sp.height, tp.width / tp.height
    return abs(ar - br) / max(ar, br) <= 0.05


def _anchor_box(boxes, idx):
    """Neighbouring word box on the side that lacks the text (or None)."""
    for k in (idx - 1, idx):
        if 0 <= k < len(boxes) and boxes[k]:
            return boxes[k]
    return None
