"""Vision-LLM engine: provider-neutral wrapper over HTTP (urllib only).

Providers: gemini | openai (any OpenAI-compatible base_url: OpenAI, Azure-style
gateways, vLLM, LM Studio, Ollama's /v1) | anthropic | ollama (native API).

Never runs unless a provider is configured. Keys come from env only:
  GEMINI_API_KEY, OPENAI_API_KEY (+OPENAI_BASE_URL), ANTHROPIC_API_KEY, OLLAMA_BASE_URL
No default model is chosen; options.vision.model or COMPARER_VISION_MODEL is required.
"""
from __future__ import annotations

import base64
import json
import os
import re
import urllib.error
import urllib.request

from ..models import Locus

NAME = "vision_llm"
TIMEOUT = int(os.environ.get("COMPARER_VISION_TIMEOUT", "120"))

PROMPT = """You are a marketing QA reviewer. Compare the SOURCE (approved reference) with the TARGET (produced asset).
Report every difference in copy (wording, numbers, prices, dates, disclaimers, CTA labels), and any notable visual
difference (missing/extra elements, wrong logo, color, layout). Ignore tiny rendering/anti-aliasing noise.

Respond with JSON only, no prose, shaped exactly like:
{"summary": "<one sentence>",
 "match": true|false,
 "findings": [
   {"category": "text_missing|text_extra|text_changed|visual_diff|layout_shift|llm_observation",
    "severity": "high|medium|low|info",
    "message": "<what differs, quoting the exact text on each side when it is text>",
    "source_page": <0-based page index as labelled below>, "target_page": <0-based page index>,
    "source_bbox": [x, y, w, h] or null,
    "target_bbox": [x, y, w, h] or null}
 ]}
bbox values are fractions of the image width/height from the top-left (0..1). Use null when the side is text-only.
If you cannot compare, set "match": false and explain in "summary"."""

MAX_IMAGES_PER_SIDE = int(os.environ.get("COMPARER_VISION_MAX_IMAGES", "4"))
MAX_TEXT_PER_SIDE = int(os.environ.get("COMPARER_VISION_MAX_TEXT", "20000"))


PROVIDER_ENV = (("gemini", "GEMINI_API_KEY"), ("openai", "OPENAI_API_KEY"),
                ("anthropic", "ANTHROPIC_API_KEY"), ("ollama", "OLLAMA_BASE_URL"))

# Provider registry. Built-ins are filled in at the bottom of this module. A custom provider is a
# plain function with the same signature as the built-ins:
#     fn(model: str, base_url: str | None, s_imgs: list[(page, mime, b64)], s_txt: str,
#        t_imgs: list[(page, mime, b64)], t_txt: str, prompt: str = "") -> str   # raw model reply text
# Register it with COMPARER_PROVIDER_PLUGIN="<name>=<module>:<function>" (several separated by commas).
# Plugins count as configured providers; they read their own credentials from the environment.
PROVIDERS: dict = {}
PLUGIN_ERRORS: list[str] = []
_PLUGINS_LOADED = False


def _load_provider_plugins():
    global _PLUGINS_LOADED
    if _PLUGINS_LOADED:
        return
    _PLUGINS_LOADED = True
    spec = os.environ.get("COMPARER_PROVIDER_PLUGIN", "").strip()
    if not spec:
        return
    from ..adapters import load_plugin
    for item in spec.split(","):
        item = item.strip()
        if not item:
            continue
        try:
            if "=" not in item:
                raise ImportError("expected <name>=<module>:<function>")
            name, target = item.split("=", 1)
            name = name.strip().lower()
            if not name or not re.fullmatch(r"[a-z0-9_-]{1,40}", name):
                raise ImportError(f"bad provider name {name!r}")
            fn = load_plugin(target.strip())
            if not callable(fn):
                raise ImportError(f"{target} is not callable")
            PROVIDERS[name] = fn
        except Exception as e:
            PLUGIN_ERRORS.append(f"provider plugin {item!r}: {e}")


def plugin_providers() -> list[str]:
    _load_provider_plugins()
    return [n for n in PROVIDERS if n not in ("gemini", "openai", "anthropic", "ollama")]


def configured_providers() -> list[str]:
    """Providers the server operator enabled via environment. Requests can only pick among these.
    `openai` also counts as configured with only OPENAI_BASE_URL (keyless local servers: vLLM, LM Studio,
    Ollama's /v1); the Authorization header is then a placeholder."""
    out = [p for p, k in PROVIDER_ENV if os.environ.get(k)]
    if "openai" not in out and os.environ.get("OPENAI_BASE_URL"):
        out.append("openai")
    out += plugin_providers()
    pinned = (os.environ.get("COMPARER_VISION_PROVIDER") or "").strip().lower()
    if pinned:
        # strict: a pinned provider that is not configured/loadable disables vision entirely, so an
        # operator typo can never fall back to a different (e.g. cloud) provider that happens to have a key
        return [pinned] if pinned in out else []
    return out


def pin_error() -> str | None:
    pinned = (os.environ.get("COMPARER_VISION_PROVIDER") or "").strip().lower()
    if not pinned:
        return None
    available = [p for p, k in PROVIDER_ENV if os.environ.get(k)]
    if "openai" not in available and os.environ.get("OPENAI_BASE_URL"):
        available.append("openai")
    available += plugin_providers()
    if pinned in available:
        return None
    return f"COMPARER_VISION_PROVIDER={pinned!r} is not a configured provider (configured: {available or 'none'}); vision disabled"


def _config(ctx):
    """Resolve provider/model/base_url. Security: the request body may choose a *model* and pick
    among *server-configured* providers, but never supplies a base_url or credentials, so a
    client cannot redirect the server's API key to an arbitrary host."""
    v = ctx.options.get("vision") or {}
    if not isinstance(v, dict):
        v = {}
    allowed = configured_providers()
    err = pin_error()
    if err:
        return None, None, None, err
    req_provider = v.get("provider")
    if req_provider and req_provider not in allowed:
        return None, None, None, f"provider '{req_provider}' is not configured on the server (configured: {allowed or 'none'})"
    provider = req_provider or (allowed[0] if allowed else None)
    model = v.get("model") or os.environ.get("COMPARER_VISION_MODEL")
    allow_models = [m.strip() for m in os.environ.get("COMPARER_VISION_MODELS", "").split(",") if m.strip()]
    if model and allow_models and model not in allow_models:
        return None, None, None, f"model '{model}' not in COMPARER_VISION_MODELS allow-list"
    if v.get("base_url"):
        ctx.stats.setdefault("warnings", []).append("options.vision.base_url ignored: base URLs come from server environment only")
    base_url = os.environ.get("COMPARER_VISION_BASE_URL") or None
    return provider, model, base_url, None


def availability():
    allowed = configured_providers()
    provider = allowed[0] if allowed else None
    err = pin_error()
    if err:
        return "unavailable", None, None, err
    if not provider:
        return "skipped", None, None, "no provider configured (set GEMINI_API_KEY / OPENAI_API_KEY / ANTHROPIC_API_KEY / OLLAMA_BASE_URL)"
    model = os.environ.get("COMPARER_VISION_MODEL")
    return "ok", provider, model, None if model else "provider found; pass options.vision.model or set COMPARER_VISION_MODEL"


def _side_parts(doc, warnings, label, coverage_limits=None):
    """Return (images[(page_index, mime, b64)], text). Records truncation in warnings."""
    images, texts = [], []
    for p in doc.pages:
        if len(images) >= MAX_IMAGES_PER_SIDE and (p.image is not None or p.image_bytes):
            reason = f"vision_llm: {label} page {p.index + 1} not sent (limit {MAX_IMAGES_PER_SIDE} images per side)"
            warnings.append(reason)
            if coverage_limits is not None and reason not in coverage_limits:
                coverage_limits.append(reason)
            continue
        if p.image is not None:
            import io
            buf = io.BytesIO()
            im = p.image
            if max(im.size) > 1600:
                im = im.copy(); im.thumbnail((1600, 1600))
            im.convert("RGB").save(buf, format="JPEG", quality=85)
            images.append((p.index, "image/jpeg", base64.b64encode(buf.getvalue()).decode()))
        elif p.image_bytes:
            mime = {"png": "image/png", "jpeg": "image/jpeg", "gif": "image/gif"}.get(p.image_format or "", "image/png")
            images.append((p.index, mime, base64.b64encode(p.image_bytes).decode()))
        elif p.text.strip():
            texts.append(f"[page {p.index}]\n{p.text}")
    text = "\n\n".join(texts)
    if len(text) > MAX_TEXT_PER_SIDE:
        reason = f"vision_llm: {label} text truncated to {MAX_TEXT_PER_SIDE} chars"
        warnings.append(reason)
        if coverage_limits is not None and reason not in coverage_limits:
            coverage_limits.append(reason)
        text = text[:MAX_TEXT_PER_SIDE]
    return images, text


def run(ctx):
    provider, model, base_url, err = _config(ctx)
    if err:
        ctx.skip(NAME, err)
        return []
    if not provider:
        ctx.skip(NAME, "no vision provider configured; nothing sent to any model")
        return []
    if not model:
        ctx.skip(NAME, f"provider '{provider}' configured but no model given (options.vision.model or COMPARER_VISION_MODEL)")
        return []
    warnings = ctx.stats.setdefault("warnings", [])
    s_imgs, s_txt = _side_parts(ctx.source, warnings, "source", ctx.stats.setdefault("coverage_limits", []))
    t_imgs, t_txt = _side_parts(ctx.target, warnings, "target", ctx.stats.setdefault("coverage_limits", []))
    if not (s_imgs or s_txt) or not (t_imgs or t_txt):
        ctx.skip(NAME, "nothing to send (no image or text on one side)")
        return []
    call = PROVIDERS.get(provider)
    if call is None:
        ctx.unavailable(NAME, f"unknown provider '{provider}'")
        return []
    raw = call(model, base_url, s_imgs, s_txt, t_imgs, t_txt)
    data = _parse_json(raw)  # raises ValueError on malformed output -> engine 'failed', never a match
    findings = []
    s_pages = {p.index for p in ctx.source.pages}; t_pages = {p.index for p in ctx.target.pages}
    for f in data["findings"]:
        if not isinstance(f, dict):
            continue
        cat = f.get("category") if f.get("category") in ("text_missing", "text_extra", "text_changed", "visual_diff", "layout_shift", "llm_observation") else "llm_observation"
        sev = f.get("severity") if f.get("severity") in ("high", "medium", "low", "info") else "medium"
        extra = {}
        findings.append(ctx.finding(
            cat, sev, NAME, 0.6, str(f.get("message", "")).strip() or "Model flagged a difference",
            source=Locus(_page(f.get("source_page"), s_pages), _bbox(f.get("source_bbox"))),
            target=Locus(_page(f.get("target_page"), t_pages), _bbox(f.get("target_bbox"))), extra=extra))
    match = data["match"]
    if match is False and not findings:
        findings.append(ctx.finding("llm_observation", "medium", NAME, 0.5,
                                    "Model reports the assets do not match: " + (str(data.get("summary", ""))[:300] or "no detail given")))
    ctx.stats["llm_match"] = bool(match)
    ctx.stats["llm_summary"] = str(data.get("summary", ""))[:500]
    ctx.report(NAME, "ok", backend=provider, version=model)
    return findings


def chat(ctx, prompt: str):
    """Second-pass helper for the rules stage: send `prompt` plus both sides' images/text to the
    configured model and return the raw reply. Returns (raw, None) or (None, reason)."""
    provider, model, base_url, err = _config(ctx)
    if err:
        return None, err
    if not provider:
        return None, "no vision provider configured"
    if not model:
        return None, "no model given (options.vision.model or COMPARER_VISION_MODEL)"
    warnings = ctx.stats.setdefault("warnings", [])
    s_imgs, s_txt = _side_parts(ctx.source, warnings, "source", ctx.stats.setdefault("coverage_limits", []))
    t_imgs, t_txt = _side_parts(ctx.target, warnings, "target", ctx.stats.setdefault("coverage_limits", []))
    call = PROVIDERS.get(provider)
    if call is None:
        return None, f"unknown provider '{provider}'"
    try:
        return call(model, base_url, s_imgs, s_txt, t_imgs, t_txt, prompt), None
    except Exception as e:
        return None, f"{type(e).__name__}: {e}"[:300]


def _bbox(v):
    try:
        x, y, w, h = [float(n) for n in v]
        if w <= 0 or h <= 0:
            return None
        return (max(0.0, min(1.0, x)), max(0.0, min(1.0, y)), min(1.0, w), min(1.0, h))
    except Exception:
        return None


def _page(v, valid):
    try:
        i = int(v)
    except (TypeError, ValueError):
        i = 0
    return i if i in valid else (min(valid) if valid else 0)


def _parse_json(raw: str) -> dict:
    """Strict: the reply must contain a JSON object with a boolean `match` and a `findings` list.
    Anything else raises so the engine is recorded as failed instead of silently matching."""
    raw = (raw or "").strip()
    m = re.search(r"\{.*\}", raw, re.S)
    if not m:
        raise ValueError(f"model returned no JSON object: {raw[:120]!r}")
    try:
        data = json.loads(m.group(0))
    except json.JSONDecodeError as e:
        raise ValueError(f"model returned malformed JSON: {e}")
    if not isinstance(data, dict) or not isinstance(data.get("match"), bool) or not isinstance(data.get("findings"), list):
        raise ValueError("model JSON missing boolean 'match' or list 'findings'")
    return data


def _post(url, body, headers):
    req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST",
                                 headers={"Content-Type": "application/json", **headers})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:500]
        raise RuntimeError(f"HTTP {e.code} from {url}: {detail}") from None


def _user_content_text(s_txt, t_txt, guidance=""):
    # `guidance` is the full prompt override used by the second (rules) pass; the base pass never sees SME guidance.
    parts = [guidance or PROMPT]
    if s_txt:
        parts.append("SOURCE TEXT:\n" + s_txt)
    if t_txt:
        parts.append("TARGET TEXT:\n" + t_txt)
    return "\n\n".join(parts)


def _gemini(model, base_url, s_imgs, s_txt, t_imgs, t_txt, guidance=""):
    key = os.environ["GEMINI_API_KEY"]
    base = base_url or "https://generativelanguage.googleapis.com/v1beta"
    parts = [{"text": _user_content_text(s_txt, t_txt, guidance)}]
    for label, imgs in (("SOURCE", s_imgs), ("TARGET", t_imgs)):
        for page, mime, b64 in imgs:
            parts.append({"text": f"{label} IMAGE page {page}:"})
            parts.append({"inline_data": {"mime_type": mime, "data": b64}})
    body = {"contents": [{"role": "user", "parts": parts}],
            "generationConfig": {"temperature": 0, "responseMimeType": "application/json"}}
    out = _post(f"{base}/models/{model}:generateContent", body, {"x-goog-api-key": key})
    return out["candidates"][0]["content"]["parts"][0]["text"]


def _openai(model, base_url, s_imgs, s_txt, t_imgs, t_txt, guidance=""):
    key = os.environ.get("OPENAI_API_KEY", "none")
    base = (base_url or os.environ.get("OPENAI_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
    content = [{"type": "text", "text": _user_content_text(s_txt, t_txt, guidance)}]
    for label, imgs in (("SOURCE", s_imgs), ("TARGET", t_imgs)):
        for page, mime, b64 in imgs:
            content.append({"type": "text", "text": f"{label} IMAGE page {page}:"})
            content.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}"}})
    body = {"model": model, "temperature": 0, "messages": [{"role": "user", "content": content}]}
    out = _post(f"{base}/chat/completions", body, {"Authorization": f"Bearer {key}"})
    return out["choices"][0]["message"]["content"]


def _anthropic(model, base_url, s_imgs, s_txt, t_imgs, t_txt, guidance=""):
    key = os.environ["ANTHROPIC_API_KEY"]
    base = (base_url or "https://api.anthropic.com/v1").rstrip("/")
    content = [{"type": "text", "text": _user_content_text(s_txt, t_txt, guidance)}]
    for label, imgs in (("SOURCE", s_imgs), ("TARGET", t_imgs)):
        for page, mime, b64 in imgs:
            content.append({"type": "text", "text": f"{label} IMAGE page {page}:"})
            content.append({"type": "image", "source": {"type": "base64", "media_type": mime, "data": b64}})
    body = {"model": model, "max_tokens": 4096, "temperature": 0, "messages": [{"role": "user", "content": content}]}
    out = _post(f"{base}/messages", body, {"x-api-key": key, "anthropic-version": "2023-06-01"})
    return "".join(b.get("text", "") for b in out.get("content", []))


def _ollama(model, base_url, s_imgs, s_txt, t_imgs, t_txt, guidance=""):
    base = (base_url or os.environ.get("OLLAMA_BASE_URL") or "http://127.0.0.1:11434").rstrip("/")
    order = ", ".join([f"source page {p}" for p, _, _ in s_imgs] + [f"target page {p}" for p, _, _ in t_imgs])
    text = _user_content_text(s_txt, t_txt, guidance) + f"\n\nImages are attached in this order: {order}."
    body = {"model": model, "stream": False, "format": "json", "options": {"temperature": 0},
            "messages": [{"role": "user", "content": text, "images": [b for _, _, b in s_imgs + t_imgs]}]}
    out = _post(f"{base}/api/chat", body, {})
    return out["message"]["content"]


PROVIDERS.update({"gemini": _gemini, "openai": _openai, "anthropic": _anthropic, "ollama": _ollama})
