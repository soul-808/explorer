"""OCR extraction for pages that have an image but no native text.

Backends (first available wins, or choose with options.ocr.backend):
  pytesseract  (Apache-2.0; needs the tesseract binary)
  rapidocr_onnxruntime (Apache-2.0; bundles PP-OCR models, no system deps)
  easyocr      (Apache-2.0; PyTorch, heavy)
"""
from __future__ import annotations

import re

from .. import deps
from ..models import Word

NAME = "ocr"


def _backends():
    out = []
    if deps.pillow() is not None:
        pt = deps.module("pytesseract")
        if pt is not None and deps.binary("tesseract"):
            out.append(("pytesseract", deps.binary_version("tesseract") or deps.version_of(pt)))
        ro = deps.module("rapidocr_onnxruntime")
        if ro is not None:
            out.append(("rapidocr", deps.version_of(ro)))
        eo = deps.module("easyocr")
        if eo is not None:
            out.append(("easyocr", deps.version_of(eo)))
    return out


def availability():
    b = _backends()
    if not b:
        msg = "no OCR backend: install Pillow plus pytesseract (+tesseract binary), rapidocr-onnxruntime or easyocr"
        if deps.pillow() is None:
            msg = "Pillow not installed (required by every OCR backend)"
        return "unavailable", None, None, msg
    return "ok", b[0][0], b[0][1], None


def run(ctx):
    status, backend, version, msg = availability()
    if status != "ok":
        ctx.unavailable(NAME, msg)
        return []
    want = ctx.opt("ocr", "backend", None)
    if want:
        names = [b[0] for b in _backends()]
        if want in names:
            backend = want
        else:
            ctx.unavailable(NAME, f"requested OCR backend '{want}' not installed; have {names}")
            return []
    targets = [(side, p) for side, doc in (("source", ctx.source), ("target", ctx.target))
               for p in doc.pages if p.image is not None and not p.text.strip()]
    if not targets:
        ctx.skip(NAME, "every page already has native text or no decodable image")
        return []
    fn = {"pytesseract": _tesseract_multi, "rapidocr": _rapidocr, "easyocr": _easyocr}[backend]
    min_conf = float(ctx.opt("ocr", "min_conf", 30)) / 100.0
    for side, page in targets:
        words = [w for w in fn(page.image) if w.conf >= min_conf]
        words = reading_order(words)
        page.words = words
        page.text = " ".join(w.text for w in words)
        page.text_source = f"ocr:{backend}"
    ctx.report(NAME, "ok", backend=backend, version=version,
               message=f"OCR'd {len(targets)} page(s)")
    return []


def _overlap(a, b):
    """Intersection over the smaller box's area (0..1)."""
    ax, ay, aw, ah = a; bx, by, bw, bh = b
    ix = max(0.0, min(ax + aw, bx + bw) - max(ax, bx))
    iy = max(0.0, min(ay + ah, by + bh) - max(ay, by))
    return (ix * iy) / max(1e-9, min(aw * ah, bw * bh))


def _vertical_overlap(a, b):
    ay, ah = a[1], a[3]; by, bh = b[1], b[3]
    iy = max(0.0, min(ay + ah, by + bh) - max(ay, by))
    return iy / max(1e-9, min(ah, bh))


def _lines(words):
    """Group words into lines by vertical overlap (>=50% of the smaller height)."""
    lines = []
    for w in sorted(words, key=lambda w: (w.bbox[1], w.bbox[0])):
        best, best_ov = None, 0.0
        for ln in lines:
            ov = _vertical_overlap((0, ln["y"], 1, ln["h"]), w.bbox)
            # words on one line have comparable heights; a 60px display number must not
            # swallow the 13px lines of a neighbouring column it happens to span. A word with
            # a moderately taller box (descenders, merged 'APYis') still joins when the
            # vertical centres of word and line fall inside each other.
            ratio = min(ln["wh"], w.bbox[3]) / max(ln["wh"], w.bbox[3], 1e-9)
            wc = w.bbox[1] + w.bbox[3] / 2; lc = ln["y"] + ln["h"] / 2
            centred = ln["y"] <= wc <= ln["y"] + ln["h"] and w.bbox[1] <= lc <= w.bbox[1] + w.bbox[3]
            if ov > best_ov and (ratio >= 0.5 or (centred and ratio >= 0.3)):
                best, best_ov = ln, ov
        if best is not None and best_ov >= 0.5:
            best["words"].append(w)
            y0 = min(best["y"], w.bbox[1]); y1 = max(best["y"] + best["h"], w.bbox[1] + w.bbox[3])
            best["y"], best["h"] = y0, y1 - y0
            best["wh"] = sum(x.bbox[3] for x in best["words"]) / len(best["words"])
        else:
            lines.append({"y": w.bbox[1], "h": w.bbox[3], "wh": w.bbox[3], "words": [w]})
    for ln in lines:
        ln["words"].sort(key=lambda w: w.bbox[0])
    lines.sort(key=lambda ln: ln["y"])
    return lines


def _segments(line, gap_factor=2.5):
    """Split a line into segments at horizontal gaps wider than gap_factor x the line height
    (column gaps), so 'left column text  |  right column text' is not one run."""
    segs = []
    cur = []
    for w in line["words"]:
        if cur:
            prev = cur[-1]
            gap = w.bbox[0] - (prev.bbox[0] + prev.bbox[2])
            if gap > gap_factor * max(line["h"], 1e-6):
                segs.append(cur); cur = []
        cur.append(w)
    if cur:
        segs.append(cur)
    out = []
    for seg in segs:
        x0 = min(w.bbox[0] for w in seg); x1 = max(w.bbox[0] + w.bbox[2] for w in seg)
        out.append({"x0": x0, "x1": x1, "y": line["y"], "h": line["h"], "words": seg})
    return out


def reading_order(words):
    """Reading order that respects columns: words -> lines (vertical overlap) -> segments
    (split at column-sized gaps) -> blocks (segments chained to the segment below them when
    their x-ranges overlap and the vertical gap is small). Blocks are emitted top-to-bottom,
    left-to-right; inside a block, line by line."""
    if not words:
        return []
    segs = [sg for ln in _lines(words) for sg in _segments(ln)]
    n = len(segs)
    parent = list(range(n))
    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]; i = parent[i]
        return i
    for i in range(n):
        a = segs[i]
        # nearest segment below with x-overlap
        best, best_gap = None, None
        for j in range(n):
            if j == i:
                continue
            b = segs[j]
            gap = b["y"] - (a["y"] + a["h"])
            if gap < -0.25 * a["h"]:
                continue  # not below
            ox = min(a["x1"], b["x1"]) - max(a["x0"], b["x0"])
            if ox <= 0 or ox < 0.5 * min(a["x1"] - a["x0"], b["x1"] - b["x0"]):
                continue
            if best_gap is None or gap < best_gap:
                best, best_gap = j, gap
        if best is not None and best_gap <= 1.2 * max(a["h"], segs[best]["h"]):
            parent[find(i)] = find(best)
    blocks = {}
    for i in range(n):
        blocks.setdefault(find(i), []).append(segs[i])
    ordered = sorted(blocks.values(), key=lambda b: (min(sg["y"] for sg in b), min(sg["x0"] for sg in b)))
    out = []
    for block in ordered:
        for sg in sorted(block, key=lambda sg: (sg["y"], sg["x0"])):
            out.extend(sg["words"])
    return out


def merge_passes(primary, secondary):
    """Merge two OCR passes over the same image. Words are clustered by box overlap; inside a
    cluster the pass with the higher mean confidence wins, with a preference for the pass that
    reads the cluster as fewer tokens (e.g. '4.25%' over '4', '2', '5', '%') when its confidence
    is at least comparable. Words only one pass saw are kept."""
    if not primary:
        return list(secondary)
    if not secondary:
        return list(primary)
    items = [("A", w) for w in primary] + [("B", w) for w in secondary]
    n = len(items)
    parent = list(range(n))
    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]; i = parent[i]
        return i
    for i in range(n):
        for j in range(i + 1, n):
            if items[i][0] != items[j][0] and _overlap(items[i][1].bbox, items[j][1].bbox) >= 0.3:
                parent[find(i)] = find(j)
    clusters = {}
    for i in range(n):
        clusters.setdefault(find(i), []).append(items[i])
    out = []
    for members in clusters.values():
        a = [w for src, w in members if src == "A"]
        b = [w for src, w in members if src == "B"]
        if not a or not b:
            out.extend(a or b)
            continue
        ma = sum(w.conf for w in a) / len(a); mb = sum(w.conf for w in b) / len(b)
        if len(b) < len(a) and mb >= ma - 0.10:
            out.extend(b)
        elif len(a) < len(b) and ma >= mb - 0.10:
            out.extend(a)
        else:
            out.extend(a if ma >= mb else b)
    return out


def _tesseract(im, config=""):
    import pytesseract
    W, H = im.size
    data = pytesseract.image_to_data(im, output_type=pytesseract.Output.DICT, config=config)
    words = []
    for i, txt in enumerate(data["text"]):
        txt = (txt or "").strip()
        if not txt:
            continue
        conf = float(data["conf"][i]) if str(data["conf"][i]) not in ("-1", "") else 0.0
        if conf < 0:
            continue
        x, y, w, h = data["left"][i], data["top"][i], data["width"][i], data["height"][i]
        words.append(Word(txt, (x / W, y / H, w / W, h / H), conf / 100.0))
    return words


_JUNK = re.compile(r"^[^A-Za-z0-9]*[A-Za-z0-9]?[^A-Za-z0-9]*$")


def _is_junk(word) -> bool:
    """Tokens like '(0)', '(e)', 'e' that tesseract emits when it fails on large display text."""
    t = word.text
    if not any(ch.isalnum() for ch in t):
        return True
    if _JUNK.match(t) and len(t) >= 2 and word.conf < 0.7:
        return True
    return False


def _tesseract_multi(im):
    """Passes: (A) default layout psm 3, (B) sparse psm 11, (L) sparse psm 11 on a half-scale
    copy to read large display text (tesseract mis-segments glyphs taller than ~40px), and
    (R) OCR of saturated colour regions (buttons/badges, light-on-dark). Later, more specific
    passes override earlier words they overlap."""
    from PIL import Image, ImageOps
    rgb = im.convert("RGB")
    W, H = rgb.size
    a = _tesseract(rgb, "--psm 3")
    b = _tesseract(rgb, "--psm 11")
    merged = merge_passes(a, b)
    # large-text pass
    if min(W, H) >= 200:
        small = rgb.resize((W // 2, H // 2), Image.LANCZOS)
        large = [w for w in _tesseract(small, "--psm 11") if w.bbox[3] * H >= 36 and w.conf >= 0.6 and not _is_junk(w)]
        for lw in large:
            hit = [m for m in merged if _overlap(m.bbox, lw.bbox) >= 0.3]
            good = [m for m in hit if not _is_junk(m)]
            # override only when the half-scale read beats what full resolution produced there
            if not hit or not good or lw.conf > sum(m.conf for m in good) / len(good):
                merged = [m for m in merged if m not in hit]
                merged.append(lw)
    # colour-region pass
    for (x, y, w, h) in _colour_regions(rgb):
        crop = ImageOps.grayscale(rgb.crop((x, y, x + w, y + h)))
        px = list(getattr(crop, "get_flattened_data", crop.getdata)())
        if px and sum(px) / len(px) < 128:
            crop = ImageOps.invert(crop)
        scale = 2 if h < 80 else 1
        if scale != 1:
            crop = crop.resize((w * scale, h * scale))
        found = []
        for wd in _tesseract(crop, "--psm 6"):
            cx, cy, cw, ch = wd.bbox   # normalised to the crop
            found.append(Word(wd.text, ((x + cx * w) / W, (y + cy * h) / H, cw * w / W, ch * h / H), wd.conf))
        found = [f for f in found if not _is_junk(f)]
        if found and sum(f.conf for f in found) / len(found) >= 0.6:
            region = (x / W, y / H, w / W, h / H)
            merged = [m for m in merged if not _center_in(m.bbox, region)]
            merged.extend(found)
    return [w for w in merged if not _is_junk(w)]


def _center_in(bbox, region):
    cx, cy = bbox[0] + bbox[2] / 2, bbox[1] + bbox[3] / 2
    return region[0] <= cx <= region[0] + region[2] and region[1] <= cy <= region[1] + region[3]


def _colour_regions(rgb, cell=10, min_w=40, min_h=16, max_regions=20):
    """Bounding boxes (px) of saturated, mid/dark colour blobs: buttons, badges, banners."""
    import colorsys
    from PIL import Image
    W, H = rgb.size
    gw, gh = max(1, W // cell), max(1, H // cell)
    small = rgb.resize((gw, gh), Image.BOX)
    px = list(getattr(small, "get_flattened_data", small.getdata)())
    hot = []
    for (r, g, b) in px:
        _, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
        hot.append(s > 0.35 and v < 0.7)
    seen = [False] * len(hot)
    regions = []
    for i in range(len(hot)):
        if not hot[i] or seen[i]:
            continue
        stack = [i]; seen[i] = True
        x0 = x1 = i % gw; y0 = y1 = i // gw; n = 0
        while stack:
            j = stack.pop(); n += 1
            x, y = j % gw, j // gw
            x0, x1, y0, y1 = min(x0, x), max(x1, x), min(y0, y), max(y1, y)
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < gw and 0 <= ny < gh:
                        k = ny * gw + nx
                        if hot[k] and not seen[k]:
                            seen[k] = True; stack.append(k)
        w, h = (x1 - x0 + 1) * cell, (y1 - y0 + 1) * cell
        fill = n / float((x1 - x0 + 1) * (y1 - y0 + 1))
        if w >= min_w and h >= min_h and fill >= 0.6 and w * h < 0.5 * W * H:
            regions.append((x0 * cell, y0 * cell, min(w, W - x0 * cell), min(h, H - y0 * cell)))
    regions.sort(key=lambda r: -(r[2] * r[3]))
    return regions[:max_regions]


def _rapidocr(im):
    from rapidocr_onnxruntime import RapidOCR
    np = deps.numpy()
    W, H = im.size
    engine = RapidOCR()
    result, _ = engine(np.array(im.convert("RGB")))
    return _lines_to_words(result or [], W, H)


def _easyocr(im):
    import easyocr
    np = deps.numpy()
    W, H = im.size
    reader = easyocr.Reader(["en"], gpu=False, verbose=False)
    result = reader.readtext(np.array(im.convert("RGB")))
    return _lines_to_words(result, W, H)


def _lines_to_words(result, W, H):
    """Both rapidocr and easyocr return [(quad, text, conf)] per text line.
    Split each line into words, distributing the box horizontally by character share."""
    words = []
    for quad, text, conf in result:
        xs = [p[0] for p in quad]; ys = [p[1] for p in quad]
        x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
        parts = text.split()
        total = sum(len(p) for p in parts) + max(len(parts) - 1, 0)
        if total == 0:
            continue
        cursor = x0
        span = x1 - x0
        for p in parts:
            w = span * (len(p) / total)
            words.append(Word(p, (cursor / W, y0 / H, w / W, (y1 - y0) / H), float(conf)))
            cursor += w + span * (1 / total)
    return words
