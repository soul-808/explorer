from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Any, Optional

# Category -> overlay/legend color. Keep in sync with API.md.
LEGEND = {
    "text_missing": "#e5484d",
    "text_extra": "#f76b15",
    "text_changed": "#f5d90a",
    "text_moved": "#0f766e",
    "visual_diff": "#d6409f",
    "layout_shift": "#8e4ec6",
    "llm_observation": "#3e63dd",
    "rule_violation": "#b42318",
}

TEXT_PREVIEW_CHARS = 20000

SEVERITIES = ("high", "medium", "low", "info")
ENGINE_STATUSES = ("ok", "unavailable", "failed", "skipped")


@dataclass
class Word:
    text: str
    bbox: tuple[float, float, float, float]  # x, y, w, h normalized 0..1
    conf: float = 1.0


@dataclass
class Page:
    index: int
    width: int = 0
    height: int = 0
    image: Any = None            # PIL.Image when available
    image_bytes: bytes | None = None
    image_format: str | None = None
    text: str = ""               # native text (pdf/docx/txt) or OCR text
    words: list[Word] = field(default_factory=list)
    text_source: str = ""        # "native" | "ocr:<backend>" | ""
    image_path: str | None = None
    image_url: str | None = None

    def has_geometry(self) -> bool:
        return self.width > 0 and self.height > 0


@dataclass
class Document:
    name: str
    kind: str                    # image | pdf | docx | txt
    pages: list[Page] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    total_pages: int | None = None
    coverage_limits: list[str] = field(default_factory=list)

    def full_text(self) -> str:
        return "\n".join(p.text for p in self.pages if p.text)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "kind": self.kind,
            "notes": self.notes,
            "total_pages": self.total_pages,
            "coverage_limits": self.coverage_limits,
            "pages": [
                {"index": p.index, "width": p.width, "height": p.height,
                 "image_url": p.image_url, "text_source": p.text_source,
                 "text_chars": len(p.text), "text": p.text[:TEXT_PREVIEW_CHARS],
                 "text_truncated": len(p.text) > TEXT_PREVIEW_CHARS}
                for p in self.pages
            ],
        }


@dataclass
class Locus:
    page: int
    bbox: Optional[tuple[float, float, float, float]] = None
    text: Optional[str] = None

    def to_dict(self) -> dict:
        return {"page": self.page, "bbox": list(self.bbox) if self.bbox else None, "text": self.text}


@dataclass
class Finding:
    id: str
    category: str
    severity: str
    engine: str
    confidence: float
    message: str
    source: Optional[Locus] = None
    target: Optional[Locus] = None
    extra: dict = field(default_factory=dict)
    disposition: str = "flagged"          # flagged | ignored (set by the rules stage)
    rule_matches: list = field(default_factory=list)

    def to_dict(self) -> dict:
        d = {
            "id": self.id, "category": self.category, "severity": self.severity,
            "engine": self.engine, "confidence": round(self.confidence, 3), "message": self.message,
            "source": self.source.to_dict() if self.source else None,
            "target": self.target.to_dict() if self.target else None,
            "disposition": self.disposition, "rule_matches": self.rule_matches,
        }
        if self.extra:
            d["extra"] = self.extra
        return d


@dataclass
class EngineReport:
    name: str
    status: str                  # ok | unavailable | failed | skipped
    backend: Optional[str] = None
    version: Optional[str] = None
    duration_ms: Optional[int] = None
    message: Optional[str] = None

    def to_dict(self) -> dict:
        return {k: v for k, v in dataclasses.asdict(self).items() if v is not None}


@dataclass
class CompareResult:
    id: str
    created_at: str
    source: Document
    target: Document
    engines: list[EngineReport] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)
    stats: dict = field(default_factory=dict)
    verdict: dict = field(default_factory=dict)
    overlays: dict = field(default_factory=lambda: {"source": [], "target": []})
    base_findings: list[Finding] = field(default_factory=list)
    base_verdict: dict = field(default_factory=dict)
    rules_report: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "created_at": self.created_at,
            "source": self.source.to_dict(),
            "target": self.target.to_dict(),
            "engines": [e.to_dict() for e in self.engines],
            "verdict": self.verdict,
            "base_verdict": self.base_verdict,
            "stats": self.stats,
            "findings": [f.to_dict() for f in self.findings],
            "base_findings": [f.to_dict() for f in self.base_findings],
            "rules_report": self.rules_report,
            "overlays": self.overlays,
            "legend": LEGEND,
        }
