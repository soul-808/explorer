"""Draw finding boxes onto page images (Pillow). Returns nothing if Pillow is absent."""
from __future__ import annotations

from . import deps
from .models import LEGEND


def _hex(c: str):
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def annotate(page_image, findings, side: str, page_index: int):
    PIL = deps.pillow()
    if PIL is None or page_image is None:
        return None
    from PIL import ImageDraw, ImageFont
    im = page_image.convert("RGB").copy()
    draw = ImageDraw.Draw(im)
    W, H = im.size
    stroke = max(2, W // 400)
    try:
        font = ImageFont.load_default(size=max(12, W // 80))
    except TypeError:  # older Pillow
        font = ImageFont.load_default()
    for f in findings:
        loc = getattr(f, side)
        if not loc or loc.page != page_index or not loc.bbox:
            continue
        x, y, w, h = loc.bbox
        x0, y0, x1, y1 = x * W, y * H, (x + w) * W, (y + h) * H
        pad = stroke * 2
        x0, y0, x1, y1 = max(0, x0 - pad), max(0, y0 - pad), min(W, x1 + pad), min(H, y1 + pad)
        color = _hex(LEGEND.get(f.category, "#3e63dd"))
        draw.rectangle([x0, y0, x1, y1], outline=color, width=stroke)
        label = f.id
        try:
            tb = draw.textbbox((0, 0), label, font=font)
            tw, th = tb[2] - tb[0], tb[3] - tb[1]
        except Exception:
            tw, th = 8 * len(label), 12
        ly = y0 - th - 4 if y0 - th - 4 > 0 else y1 + 2
        draw.rectangle([x0, ly, x0 + tw + 6, ly + th + 4], fill=color)
        draw.text((x0 + 3, ly + 1), label, fill=(255, 255, 255), font=font)
    return im
