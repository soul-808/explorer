"""Stdlib-only HTTP server.

Manual API : GET /api/health, POST /api/compare, GET /api/artifacts/<id>/<file>
Automation : GET /api/config, /api/automation, POST /api/automation/poll,
             GET /api/runs[,/<id>[,/artifacts/<file>|/feedback]], DELETE /api/runs/<id>, POST /api/runs/<id>/feedback,
             GET/POST /api/jobs[,/<id>], POST /api/jobs/<id>/cancel, GET /api/feedback/export
See API.md and AUTOMATION_API.md.
"""
from __future__ import annotations

import base64
import json
import os
import re
from email.parser import BytesParser
from email.policy import HTTP
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

from . import __version__, pipeline
from .loaders import MAX_PAGES

MAX_BODY = int(os.environ.get("COMPARER_MAX_BODY_MB", "60")) * 1024 * 1024
# ids: <prefix>_<utc stamp>_<hex>; hex is 16 chars since 0.2, 4 chars in 0.1 artifacts (kept readable)
ID_RE = re.compile(r"^cmp_[0-9]{8}T[0-9]{6}_(?:[0-9a-f]{4}|[0-9a-f]{16,32})$")
RUN_RE = re.compile(r"^run_[0-9]{8}T[0-9]{6}_(?:[0-9a-f]{4}|[0-9a-f]{16,32})$")
JOB_RE = re.compile(r"^job_[0-9]{8}T[0-9]{6}_(?:[0-9a-f]{4}|[0-9a-f]{16,32})$")
FILE_RE = re.compile(r"^(source|target)-[0-9]{1,3}(-annotated)?\.(png|jpg)$|^result\.json$|^(source|target)-original\.[A-Za-z0-9]{1,8}$")
# Origins allowed to call the API from a browser. Default: any localhost/127.0.0.1 port (the Next.js
# dev/prod server). Set COMPARER_CORS_ORIGIN to a comma list to restrict, or "*" to allow all.
_CORS = os.environ.get("COMPARER_CORS_ORIGIN", "localhost")
_LOCAL_RE = re.compile(r"^https?://(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$")

AUTOMATION = None   # set by serve() or tests; None -> manual API only, nothing persisted


def origin_allowed(origin: str | None) -> bool:
    if not origin:
        return True  # curl, server-to-server proxy: no browser origin to police
    if _CORS == "*":
        return True
    if _CORS == "localhost":
        return bool(_LOCAL_RE.match(origin))
    return origin in {o.strip() for o in _CORS.split(",")}


class Handler(BaseHTTPRequestHandler):
    server_version = f"content-comparer/{__version__}"

    def log_message(self, fmt, *args):  # quieter default log
        if os.environ.get("COMPARER_QUIET"):
            return
        super().log_message(fmt, *args)

    # ---- helpers
    def _json(self, code: int, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _bytes(self, code: int, data: bytes, ctype: str, cache=True):
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        if cache:
            self.send_header("Cache-Control", "private, max-age=3600")
        self.end_headers()
        self.wfile.write(data)

    def _cors(self):
        origin = self.headers.get("Origin")
        if origin and origin_allowed(origin):
            self.send_header("Access-Control-Allow-Origin", "*" if _CORS == "*" else origin)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")

    def _authorized(self) -> bool:
        """Protected routes need the bearer token when COMPARER_TOKEN is configured."""
        token = AUTOMATION.cfg.get("token") if AUTOMATION else None
        if not token:
            return True
        return self.headers.get("Authorization", "") == f"Bearer {token}"

    def _read_body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            raise ValueError("empty body")
        if length > MAX_BODY:
            raise ValueError(f"body exceeds {MAX_BODY // (1024 * 1024)} MB")
        return self.rfile.read(length)

    def _parse_inputs(self):
        body = self._read_body()
        ctype = self.headers.get("Content-Type", "")
        if ctype.startswith("multipart/form-data"):
            return _parse_multipart(ctype, body)
        return _parse_json(body)

    def _route(self):
        u = urlsplit(self.path)
        return u.path.rstrip("/") or "/", {k: v[0] for k, v in parse_qs(u.query).items()}

    @staticmethod
    def _limit(q, default=50, cap=200):
        raw = q.get("limit", str(default))
        if not re.fullmatch(r"[0-9]{1,4}", raw or ""):
            raise ValueError("limit must be a positive integer")
        return max(1, min(cap, int(raw)))

    def do_OPTIONS(self):
        if not origin_allowed(self.headers.get("Origin")):
            return self._json(403, {"error": "origin not allowed"})
        self.send_response(204)
        self._cors()
        self.end_headers()

    # ---- GET
    def do_GET(self):
        path, q = self._route()
        if path in ("/api/health", "/health"):
            store = AUTOMATION.store.health() if AUTOMATION else None
            return self._json(200, {"status": "ok" if (store is None or store.get("ok")) else "degraded",
                                    "version": __version__, "engines": pipeline.engine_availability(),
                                    "supported_kinds": ["image", "pdf", "docx", "txt"], "max_pages": MAX_PAGES,
                                    "automation": AUTOMATION is not None, "store": store})
        m = re.match(r"^/api/artifacts/([^/]+)/([^/]+)$", path)
        if m and ID_RE.match(m.group(1)) and FILE_RE.match(m.group(2)):
            root = os.path.realpath(pipeline.ARTIFACT_DIR)
            full = os.path.realpath(os.path.join(root, m.group(1), m.group(2)))
            if full.startswith(root + os.sep) and os.path.isfile(full):
                return self._send_file(full)
            return self._json(404, {"error": "not found"})
        if path.startswith(("/api/config", "/api/automation", "/api/runs", "/api/jobs", "/api/feedback")):
            if AUTOMATION is None:
                return self._json(503, {"error": "automation layer not started (run `python -m comparer serve`)"})
            try:
                return self._get_automation(path, q)
            except ValueError as e:
                return self._json(400, {"error": str(e)})
            except Exception as e:      # store failures must reach the client, not vanish
                return self._json(500, {"error": f"{type(e).__name__}: {e}"[:300]})
        self._json(404, {"error": "not found"})

    def _send_file(self, full):
        ctype = "application/json" if full.endswith(".json") else "image/jpeg" if full.endswith((".jpg", ".jpeg")) else \
            "image/png" if full.endswith(".png") else "application/pdf" if full.endswith(".pdf") else "application/octet-stream"
        with open(full, "rb") as f:
            data = f.read()
        self._bytes(200, data, ctype)

    def _get_automation(self, path, q):
        a = AUTOMATION
        if path == "/api/config":
            return self._json(200, a.public_config())
        if path == "/api/automation":
            return self._json(200, a.status())
        if path == "/api/runs":
            limit = self._limit(q)
            runs, cursor = a.store.list_runs(limit=limit, cursor=q.get("cursor"), origin=q.get("origin"), status=q.get("status"))
            return self._json(200, {"runs": runs, "next_cursor": cursor})
        m = re.match(r"^/api/runs/([^/]+)$", path)
        if m:
            if not RUN_RE.match(m.group(1)):
                return self._json(400, {"error": "bad run id"})
            run = a.store.get_run(m.group(1))
            return self._json(200, run) if run else self._json(404, {"error": "run not found"})
        m = re.match(r"^/api/runs/([^/]+)/feedback$", path)
        if m:
            if not RUN_RE.match(m.group(1)):
                return self._json(400, {"error": "bad run id"})
            return self._json(200, a.store.list_feedback(m.group(1)))
        m = re.match(r"^/api/runs/([^/]+)/artifacts/([^/]+)$", path)
        if m:
            if RUN_RE.match(m.group(1)) and FILE_RE.match(m.group(2)):
                full = a.run_artifact_path(m.group(1), m.group(2))
                if full:
                    return self._send_file(full)
            return self._json(404, {"error": "not found"})
        if path == "/api/jobs":
            limit = self._limit(q)
            return self._json(200, {"jobs": [_public_job(j) for j in a.store.list_jobs(status=q.get("status"), limit=limit)]})
        m = re.match(r"^/api/jobs/([^/]+)$", path)
        if m:
            if not JOB_RE.match(m.group(1)):
                return self._json(400, {"error": "bad job id"})
            job = a.store.get_job(m.group(1))
            return self._json(200, _public_job(job)) if job else self._json(404, {"error": "job not found"})
        if path == "/api/feedback/export":
            if not self._authorized():
                return self._json(401, {"error": "bearer token required"})
            lines = [json.dumps(row) for row in a.export_feedback(since=q.get("since"))]
            data = ("\n".join(lines) + ("\n" if lines else "")).encode()
            return self._bytes(200, data, "application/x-ndjson; charset=utf-8", cache=False)
        self._json(404, {"error": "not found"})

    # ---- POST
    def do_POST(self):
        path, q = self._route()
        if not origin_allowed(self.headers.get("Origin")):
            return self._json(403, {"error": "origin not allowed"})
        if path in ("/api/compare", "/compare"):
            return self._post_compare()
        if AUTOMATION is None:
            return self._json(503 if path.startswith("/api/") else 404, {"error": "automation layer not started"})
        a = AUTOMATION
        try:
            if path == "/api/jobs":
                if not self._authorized():
                    return self._json(401, {"error": "bearer token required"})
                return self._post_job()
            m = re.match(r"^/api/jobs/([^/]+)/cancel$", path)
            if m:
                if not self._authorized():
                    return self._json(401, {"error": "bearer token required"})
                if not JOB_RE.match(m.group(1)):
                    return self._json(400, {"error": "bad job id"})
                job = a.cancel(m.group(1))
                return self._json(200, _public_job(job)) if job else self._json(404, {"error": "job not found"})
            m = re.match(r"^/api/runs/([^/]+)/feedback$", path)
            if m:
                if not RUN_RE.match(m.group(1)):
                    return self._json(400, {"error": "bad run id"})
                try:
                    body = json.loads(self._read_body().decode("utf-8"))
                except Exception as e:
                    return self._json(400, {"error": f"JSON body required: {e}"})
                try:
                    return self._json(201, a.add_feedback(m.group(1), body if isinstance(body, dict) else {}))
                except KeyError:
                    return self._json(404, {"error": "run not found"})
            if path == "/api/automation/poll":
                if not self._authorized():
                    return self._json(401, {"error": "bearer token required"})
                return self._json(200, a.poll_once())
            if path == "/api/automation/cleanup":
                if not self._authorized():
                    return self._json(401, {"error": "bearer token required"})
                return self._json(200, a.cleanup(dry_run=q.get("dry_run") in ("1", "true")))
        except ValueError as e:   # ConfigError is a ValueError
            return self._json(400, {"error": str(e)})
        except Exception as e:
            return self._json(500, {"error": f"{type(e).__name__}: {e}"[:300]})
        self._json(404, {"error": "not found"})

    def _post_compare(self):
        try:
            src, tgt, options = self._parse_inputs()
        except ValueError as e:
            return self._json(400, {"error": str(e)})
        try:
            result = pipeline.compare(src[0], src[1], tgt[0], tgt[1], options)
        except Exception as e:  # last line of defence; engines already isolate their own errors
            return self._json(500, {"error": f"{type(e).__name__}: {e}"})
        d = result.to_dict()
        if AUTOMATION is not None and options.get("persist", True) is not False:
            try:
                AUTOMATION.record_run(d, options, origin="manual", source_bytes=src[1], target_bytes=tgt[1])
            except Exception as e:
                d.setdefault("stats", {}).setdefault("warnings", []).append(f"run not saved: {type(e).__name__}: {e}")
        self._json(200, d)

    def _post_job(self):
        a = AUTOMATION
        ctype = self.headers.get("Content-Type", "")
        body = self._read_body()
        labels, key, batch = {}, None, None
        if ctype.startswith("multipart/form-data"):
            src, tgt, options = _parse_multipart(ctype, body, extra=("labels", "idempotency_key", "batch"))
            labels = options.pop("_labels", {}) or {}
            key = options.pop("_idempotency_key", None)
            batch = options.pop("_batch", None)
        else:
            try:
                data = json.loads(body.decode("utf-8"))
            except Exception as e:
                raise ValueError(f"body must be multipart/form-data or JSON: {e}")
            if not isinstance(data, dict):
                raise ValueError("JSON body must be an object")
            inbox = next((s for s in a.sources if getattr(s, "kind", "") == "inbox"), None)
            sides = []
            for keyname in ("source", "target"):
                item = data.get(keyname)
                if not isinstance(item, dict):
                    raise ValueError(f"'{keyname}' must be an object")
                if "content_base64" in item:
                    try:
                        raw = base64.b64decode(item["content_base64"], validate=False)
                    except Exception:
                        raise ValueError(f"'{keyname}.content_base64' is not valid base64")
                    sides.append((str(item.get("name") or keyname), raw))
                elif "path" in item:
                    if inbox is None:
                        raise ValueError("'path' inputs need COMPARER_INBOX to be configured")
                    sides.append(inbox.read(item["path"]))   # validated inbox-relative path
                else:
                    raise ValueError(f"'{keyname}' needs content_base64 or an inbox-relative path")
            src, tgt = sides
            options = data.get("options"); options = {} if options is None else options
            labels = data.get("labels"); labels = {} if labels is None else labels
            key = data.get("idempotency_key")
            batch = data.get("batch")
        if not isinstance(options, dict):
            raise ValueError("options must be an object")
        if not isinstance(labels, dict) or any(not isinstance(v, (str, int, float, bool)) for v in labels.values()):
            raise ValueError("labels must be an object of scalar values")
        if key is not None and not isinstance(key, (str, int)):
            raise ValueError("idempotency_key must be a string")
        if batch is not None and not isinstance(batch, (str, int)):
            raise ValueError("batch must be a string")
        job, created = a.enqueue(src, tgt, options, labels, key, origin="api", batch=batch)
        self._json(202 if created else 200, {"job": _public_job(job), "created": created})

    # ---- DELETE
    def do_DELETE(self):
        path, _ = self._route()
        if not origin_allowed(self.headers.get("Origin")):
            return self._json(403, {"error": "origin not allowed"})
        if AUTOMATION is None:
            return self._json(503, {"error": "automation layer not started"})
        m = re.match(r"^/api/runs/([^/]+)$", path)
        if m and RUN_RE.match(m.group(1)):
            if not self._authorized():
                return self._json(401, {"error": "bearer token required"})
            if AUTOMATION.store.delete_run(m.group(1)):
                d = os.path.join(AUTOMATION.cfg["data_dir"], "runs", m.group(1))
                import shutil
                shutil.rmtree(d, ignore_errors=True)
                self.send_response(204); self._cors(); self.end_headers(); return
            return self._json(404, {"error": "run not found"})
        self._json(404, {"error": "not found"})


def _public_job(job):
    return {k: v for k, v in job.items() if k not in ("paths", "worker")}


def _parse_multipart(ctype: str, body: bytes, extra=()):
    msg = BytesParser(policy=HTTP).parsebytes(b"Content-Type: " + ctype.encode() + b"\r\nMIME-Version: 1.0\r\n\r\n" + body)
    if not msg.is_multipart():
        raise ValueError("malformed multipart body")
    parts = {}
    for part in msg.iter_parts():
        name = part.get_param("name", header="content-disposition")
        if not name:
            continue
        filename = part.get_filename() or ""
        parts[name] = (filename, part.get_payload(decode=True) or b"")
    if "source" not in parts or "target" not in parts:
        raise ValueError("multipart form needs 'source' and 'target' files")
    options = {}
    if "options" in parts and parts["options"][1].strip():
        try:
            options = json.loads(parts["options"][1].decode("utf-8"))
        except Exception as e:
            raise ValueError(f"options must be JSON: {e}")
    if not isinstance(options, dict):
        raise ValueError("options must be a JSON object")
    for name in extra:
        if name in parts and parts[name][1].strip():
            raw = parts[name][1].decode("utf-8")
            if name == "labels":
                try:
                    options["_labels"] = json.loads(raw)
                except Exception as e:
                    raise ValueError(f"labels must be JSON: {e}")
            else:
                options["_" + name] = raw.strip()
    return (parts["source"][0] or "source", parts["source"][1]), (parts["target"][0] or "target", parts["target"][1]), options


def _parse_json(body: bytes):
    try:
        data = json.loads(body.decode("utf-8"))
    except Exception as e:
        raise ValueError(f"body must be multipart/form-data or JSON: {e}")
    out = []
    for key in ("source", "target"):
        item = data.get(key)
        if not isinstance(item, dict) or "content_base64" not in item:
            raise ValueError(f"'{key}' must be {{name, content_base64}}")
        try:
            raw = base64.b64decode(item["content_base64"], validate=False)
        except Exception:
            raise ValueError(f"'{key}.content_base64' is not valid base64")
        out.append((str(item.get("name") or key), raw))
    options = data.get("options") or {}
    if not isinstance(options, dict):
        raise ValueError("options must be an object")
    return out[0], out[1], options


def serve(host="127.0.0.1", port=8765, automation=True):
    global AUTOMATION
    if automation:
        from .automation import Automation
        AUTOMATION = Automation()
        AUTOMATION.start()
    httpd = ThreadingHTTPServer((host, port), Handler)
    extra = ""
    if AUTOMATION:
        st = AUTOMATION.status()
        extra = f"; store={st['store']['kind']} runs={st['store']['runs']} workers={st['worker']['workers']}" + \
                (f"; inbox={AUTOMATION.sources[0].inbox}" if AUTOMATION.sources else "; inbox off")
        for err in AUTOMATION.plugin_errors:
            print("automation plugin error:", err, flush=True)
    print(f"content-comparer {__version__} listening on http://{host}:{port}  (artifacts: {pipeline.ARTIFACT_DIR}{extra})", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
        if AUTOMATION:
            AUTOMATION.stop()
