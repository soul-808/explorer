"""Adapter protocols and plugin loading.

Built-in: Store -> sqlite (default) | jsonfiles.  Source -> inbox folder.  Anything else is an
extension point: subclass, then point COMPARER_STORE / COMPARER_SOURCES at `module:Class`.
A configured Store that cannot be opened fails startup loudly (never a silent switch to another
store). A Source plugin that fails to load is reported in /api/automation.plugin_errors and skipped.
"""
from __future__ import annotations

import importlib
from typing import Iterator, Optional


class Store:
    """Persistence for runs, jobs and feedback. All methods must be thread-safe."""
    kind = "abstract"

    # ---- lifecycle
    def open(self) -> None: ...
    def close(self) -> None: ...
    def health(self) -> dict:
        return {"kind": self.kind, "ok": True}

    # ---- runs
    def save_run(self, run: dict) -> None: raise NotImplementedError
    def get_run(self, run_id: str) -> Optional[dict]: raise NotImplementedError
    def list_runs(self, limit=50, cursor=None, origin=None, status=None) -> tuple[list[dict], Optional[str]]: raise NotImplementedError
    def delete_run(self, run_id: str, keep_feedback: bool = False) -> bool: raise NotImplementedError
    def count_runs(self) -> int: raise NotImplementedError
    def run_ids_for_pruning(self, created_before: Optional[str] = None, keep_newest: Optional[int] = None) -> list[str]:
        """Ids of runs older than `created_before` and/or beyond the newest `keep_newest`, oldest first."""
        raise NotImplementedError

    # ---- jobs
    def create_job(self, job: dict) -> None: raise NotImplementedError
    def get_job(self, job_id: str) -> Optional[dict]: raise NotImplementedError
    def find_job_by_key(self, key: str) -> Optional[dict]: raise NotImplementedError
    def list_jobs(self, status=None, limit=50) -> list[dict]: raise NotImplementedError
    def update_job(self, job_id: str, **fields) -> Optional[dict]: raise NotImplementedError
    def cancel_job(self, job_id: str, finished_at: str) -> Optional[dict]:
        """Atomically cancel a job if (and only if) it is still queued; return the job either way."""
        raise NotImplementedError
    def claim_next_job(self, worker_id: str) -> Optional[dict]:
        """Atomically move the oldest queued job to running and return it."""
        raise NotImplementedError
    def recover_running(self, max_attempts: int) -> int:
        """Jobs left 'running' by a dead process -> queued (or failed past max_attempts). Returns count."""
        raise NotImplementedError
    def job_counts(self) -> dict: raise NotImplementedError
    def delete_jobs(self, statuses: tuple, finished_before: str) -> list[str]:
        """Delete terminal jobs finished before the timestamp; return their ids."""
        raise NotImplementedError

    # ---- feedback
    def add_feedback(self, fb: dict) -> None: raise NotImplementedError
    def list_feedback(self, run_id: str) -> list[dict]: raise NotImplementedError
    def iter_feedback(self, since: Optional[str] = None) -> Iterator[dict]: raise NotImplementedError


class Source:
    """Where inputs arrive from. Built-in: the inbox folder poller. A Source's poll() returns
    a list of {"source": (name, bytes), "target": (name, bytes), "labels": {...}, "options": {...},
    "idempotency_key": str, "batch": str|None} that the automation layer turns into jobs."""
    kind = "abstract"

    def poll(self) -> list[dict]:
        raise NotImplementedError

    def status(self) -> dict:
        return {"kind": self.kind}


def load_plugin(spec: str):
    """'package.module:Attr' -> object. Raises ImportError/AttributeError with a clear message."""
    if ":" not in spec:
        raise ImportError(f"plugin spec {spec!r} must look like module:Attr")
    mod, attr = spec.split(":", 1)
    module = importlib.import_module(mod)
    try:
        return getattr(module, attr)
    except AttributeError:
        raise ImportError(f"{mod} has no attribute {attr}")
