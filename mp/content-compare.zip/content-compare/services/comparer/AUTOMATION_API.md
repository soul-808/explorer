# Automation & history API (v1)

Extends the manual `/api/compare` contract (see API.md, unchanged) with persistent runs,
background jobs, automatic intake, reviewer feedback, and pluggable adapters. Everything
here is optional: with no configuration the service behaves exactly as before, plus every
manual comparison is recorded as a run.

Base URL and CORS policy are the same as the manual API. All JSON.

## Concepts

| term | meaning |
|---|---|
| **run** | one completed comparison (manual upload, job, or intake) with its full `CompareResult`, stored originals and overlays |
| **job** | a queued request to compare two inputs later, executed by the in-process worker; produces a run |
| **intake** | a producer drops files + a manifest into a configured inbox folder; the intake poller turns each manifest into a job |
| **feedback** | a reviewer's verdict on a run or on a single finding, exportable as JSONL for evaluation/training prep |
| **adapter** | a small Python protocol with a built-in implementation and a documented extension point: `Store`, `Source`, vision `Provider` |

## Endpoints

### `GET /api/config`
Sanitised, brand-safe configuration for the UI. Never includes keys or the token.
Sources, in precedence order: environment variables (`COMPARER_BRAND_NAME`, `COMPARER_BRAND_LOGO`,
`COMPARER_BRAND_ACCENT`, `COMPARER_BRAND_TAGLINE`), then `COMPARER_CONFIG=path.json`:
```json
{"brand": {"name": "Acme Review", "logo_url": "/brand/logo.svg", "accent": "#123456", "tagline": "Creative QA"},
 "store": "sqlite", "store_path": ".data/comparer.db", "workers": 1, "inbox": "/srv/inbox", "intake_interval": 5}
```
`logo_url` must be a `/path`, `http(s)://` or `data:image/` URL; anything else is dropped. Secrets (`COMPARER_TOKEN`,
API keys) are never read from the file. A missing or malformed config file fails startup loudly.
The shipped UI applies a stricter rule: it displays only a local absolute path such as `/brand/logo.png`,
not external or data URLs. With the root npm launchers, environment path settings resolve from the project
root; use absolute filesystem paths for `store_path`, `data_dir`, and `inbox` inside JSON configuration.
```json
{"brand": {"name": "Content Compare", "logo_url": null, "accent": "#2f6d4b", "tagline": null}, "config_file": false,
 "automation": {"enabled": true, "intake_enabled": false, "worker": "thread"},
 "store": {"kind": "sqlite", "path": ".data/comparer.db"},
 "vision": {"providers_configured": ["openai"], "model_default": null, "models_allowed": []},
 "engines": [ ...same as /api/health engines... ],
 "version": "0.2.0"}
```

### Runs
- `GET /api/runs?limit=50&cursor=<id>&origin=manual|job|intake&status=match|mismatch|inconclusive` → `{"runs": [RunSummary], "next_cursor": null}`
- `GET /api/runs/{run_id}` → `Run` (summary + full `result`, feedback list)
- `GET /api/runs/{run_id}/artifacts/{file}` → stored original / overlay (same file rules as `/api/artifacts`)
- `DELETE /api/runs/{run_id}` → 204 (requires the integration token when one is configured)

```json
RunSummary = {"id": "run_20260917T160000_ab12", "created_at": "...", "origin": "manual|job|intake",
              "source_name": "design.png", "target_name": "app.png",
              "verdict": {"status": "mismatch", "confidence": 0.9, "summary": "...", "after_rules": true},
              "counts": {"findings": 5, "flagged": 4, "ignored": 1},
              "job_id": null, "batch": null, "labels": {"suite": "checkout", "build": "1234"},
              "feedback_count": 0}
Run = RunSummary + {"result": CompareResult, "options": {...as submitted...}, "feedback": [Feedback],
                    "provenance": {...}, "source_sha256": "...", "target_sha256": "...",
                    "source_original": "/api/runs/<id>/artifacts/source-original.png", "target_original": "..."}
```
Inside a stored `result`, every `pages[].image_url` and `overlays[].image_url` is rewritten to
`/api/runs/<run_id>/artifacts/...`, and a `result.json` copy sits in the run folder, so history never depends on the
scratch `.artifacts` directory. A job's run id is derived from the job id (`job_X` -> `run_X`), which makes
completion idempotent: a crash between saving the run and marking the job done cannot produce a duplicate run.
Ids carry 16 hex characters of entropy (`<prefix>_<utc stamp>_<hex16>`); 4-character ids from 0.1 remain readable.
`POST /api/compare` now also accepts `options.labels` (string map) and returns `run_id` inside the result;
`options.persist: false` skips storage (manual scratch compares).

### Jobs (background execution)
- `POST /api/jobs` → 202 `{"job": Job}`. Body is either multipart (`source`, `target`, `options`, `labels`) or JSON:
  ```json
  {"source": {"name": "design.png", "content_base64": "..."} | {"name": "...", "path": "<relative path inside the inbox>"},
   "target": {...}, "options": {...}, "labels": {"suite": "checkout"},
   "idempotency_key": "build-1234-checkout"}
  ```
  `path` inputs are only accepted relative to the configured inbox (no absolute paths, no `..`, no symlinks);
  the file is copied into `.data` at enqueue time. `idempotency_key` returns the existing job on repeat.
  This applies while the job record remains; terminal job retention defaults to 7 days. A retained failed
  job is also returned on repeat. A deliberate new execution needs a new key.
- `GET /api/jobs?status=queued|running|done|failed&limit=50` → `{"jobs": [Job]}`
- `GET /api/jobs/{job_id}` → `Job`
- `POST /api/jobs/{job_id}/cancel` → `Job` (atomic: only a still-queued job flips to `cancelled`; token-protected)

Validation: `limit` must be a positive integer, `options`/`labels` objects (labels: scalar values),
`idempotency_key`/`batch` strings; anything else is `400`. Store failures surface as `500` with the error text,
and `GET /api/health.store` / `GET /api/automation.store` report store health.

```json
Job = {"id": "job_...", "status": "queued|running|done|failed|cancelled", "created_at": "...", "started_at": null,
       "finished_at": null, "attempts": 1, "run_id": null, "error": null, "origin": "api|intake",
       "labels": {...}, "idempotency_key": null, "source_name": "...", "target_name": "..."}
```
Worker: one in-process thread by default (`COMPARER_WORKERS`, max 4), picks up `queued` jobs oldest first.
Recovery: on start, jobs left `running` by a crashed process go back to `queued` (max `COMPARER_JOB_ATTEMPTS`,
default 2, then `failed`). Everything the worker needs is in the store, so restarts are safe.

### Intake (folder harness)
Configured with `COMPARER_INBOX=/path/to/inbox`. The poller (bounded: every `COMPARER_INTAKE_INTERVAL` s,
default 5, only when enabled) looks for `*.json` manifests:
```json
{"pairs": [{"source": "approved/checkout.png", "target": "shots/checkout.png",
            "labels": {"suite": "checkout", "build": "1234"}, "options": {"engines": ["ocr", "text", "pixel"]}}],
 "batch": "build-1234", "idempotency_prefix": "build-1234"}
```
Paths are relative to the inbox (no absolute paths, no `..`, no symlinked files **or directories**; manifests
capped at 1 MB / 200 pairs). The whole manifest is validated first; then each pair becomes a job
(`origin: intake`, idempotency key `<prefix>:<source>:<target>`) with inputs copied into `.data`; **only after
every job is durably stored** is the manifest renamed `<name>.json.done`. A validation failure creates nothing.
A **storage failure part-way through** leaves the jobs already stored in place (partially durable) and marks the
manifest `.failed` with a sibling `.error.txt`; rename it back to `.json` to retry, and idempotency keys make
the retry create only the missing jobs, never duplicates. Polling is serialized, so a manual
`POST /api/automation/poll` during a scheduled pass returns `{"busy": true}` instead of double-enqueuing.

- `GET /api/automation` → `{"intake": {"enabled": true, "inbox": "...", "last_poll": "...", "manifests_seen": 3, "errors": []},
  "worker": {"running": true, "workers": 1, "queued": 0, "running_jobs": 0, "done": 12, "failed": 0},
  "store": {"kind": "sqlite", "ok": true, "runs": 12}}`
- `POST /api/automation/poll` → triggers one intake pass immediately (for tests/demos).

### Feedback
- `POST /api/runs/{run_id}/feedback` →
  ```json
  {"finding_id": "f3" | null, "verdict": "correct|false_positive|missed|wrong_severity|acceptable_difference|other",
   "expected_category": "text_changed" | null, "expected_severity": "high" | null,
   "comment": "…", "reviewer": "free text or SSO id supplied by the UI"}
  ```
  returns `Feedback = body + {"id": "fb_...", "created_at": "..."}`. `expected_category` / `expected_severity` are
  validated against the finding enums; `comment` is capped at 4000 characters, `reviewer` at 200.
- `GET /api/runs/{run_id}/feedback` → `[Feedback]`
- `GET /api/feedback/export?format=jsonl&since=<iso>` → one JSON object per line:
  ```json
  {"feedback_id": "fb_...", "run_id": "run_...", "finding_id": "f3", "finding": {...finding as reported...} | null,
   "verdict": "false_positive", "expected": {"category": null, "severity": null}, "comment": "...", "reviewer": "...",
   "context": {"source_kind": "image", "target_kind": "image", "engines": ["ocr","text"], "labels": {...}, "verdict": "mismatch",
               "source_text_excerpt": "...", "target_text_excerpt": "..."},
   "provenance": {"engines": [{"name": "ocr", "backend": "pytesseract", "version": "..."}], "vision": {"provider": "openai", "model": "..."} | null,
                  "rules": 2, "guidance": true, "comparer_version": "0.2.0", "options": {...as submitted...},
                  "source_sha256": "...", "target_sha256": "..."},
   "created_at": "..."}
  ```
  `feedback_id` dedupes re-exports; the SHA-256 of both originals ties a row to exact input bytes.
  This is the dataset for evaluation or fine-tuning preparation. The service never trains or uploads anything.

## Cleanup & retention

Data is bounded by policy, applied by a maintenance thread (every `COMPARER_CLEANUP_INTERVAL` s, default 600,
first pass shortly after start), by `POST /api/automation/cleanup[?dry_run=1]` (token-protected) and by
`python -m comparer cleanup [--dry-run]`. **The CLI is for a stopped server**: it checks `.data/server.lock`
and refuses (exit 2) while a live server owns the data directory, because a second process cannot see the
server's in-flight writes; use the endpoint instead, or `--force` if you accept that. Cleanup only ever
removes directories named like comparer ids (`run_…`, `job_…`, `cmp_…`); anything else under the data or
scratch roots is left alone. `GET /api/automation.cleanup` shows the policy, the last report,
and current disk usage of `.data` and the scratch directory.

| rule | environment setting | default | effect |
|---|---|---|---|
| immediate | — | always | scratch overlays are deleted as soon as a run has its own copy; job input copies are deleted when the job completes |
| run age | `COMPARER_RETENTION_DAYS` | 30 | runs older than this are pruned (record + folder) |
| run count | `COMPARER_MAX_RUNS` | 500 | keep only the newest N runs |
| size budget | `COMPARER_MAX_DATA_MB` | 2048 | counts bytes under `.data/runs` only (not the store file or job inputs); prunes oldest runs until it fits |
| job records | `COMPARER_JOB_RETENTION_DAYS` | 7 | done/failed/cancelled jobs and any leftover input copies removed |
| scratch TTL | `COMPARER_SCRATCH_TTL_MINUTES` | 120 | `.artifacts/cmp_*` from `persist:false` compares and CLI runs |
| inbox | `COMPARER_INBOX_TTL_DAYS` | 7 | acknowledged manifests (`.done`, `.failed`, `.error.txt`) removed; producer files are never deleted |
| orphans | `COMPARER_ORPHAN_GRACE_SECONDS` | 900 | run/job folders without a record, only once older than the grace period; folders being written right now and ids of running jobs are never touched |
| feedback | `COMPARER_KEEP_FEEDBACK` | 1 | feedback rows survive run pruning (they carry the finding + provenance), so the training export is not lost |

Set run age/count/size, job age, or inbox age to `0` to disable that individual limit. Scratch TTL has a minimum of **1 minute** (`0` is coerced to 1); the cleanup interval has a minimum of 30 seconds.

All values can also live in the `COMPARER_CONFIG` file (`retention_days`, `max_runs`, `max_data_mb`,
`job_retention_days`, `scratch_ttl_minutes`, `inbox_ttl_days`, `cleanup_interval`, `keep_feedback_on_prune`).
**Defaults are destructive by design** (30 days / 500 runs / 2 GB, feedback kept); the UI shows the active policy.
The report lists what was (or would be) removed:
`{"runs_pruned": [...], "jobs_pruned": [...], "job_inputs_removed": n, "scratch_removed": n, "orphans_removed": n,
"inbox_manifests_removed": n, "errors": [], "data_dir_mb": 12.4}`.

## Security
- Loopback bind by default. `COMPARER_TOKEN` (optional): when set, job creation/cancellation, run deletion,
  manual intake polling, cleanup, and feedback export require `Authorization: Bearer <token>`; the UI proxy
  adds it server-side. This token does not protect every read or feedback write and is not user authentication.
- File inputs from the network are always bytes (multipart/base64) or inbox-relative paths. Absolute paths,
  `..`, symlinks and URLs are rejected with 400.
- No external call is made unless a vision provider is configured *and* requested per run.

## Adapters (protocols in `comparer/adapters.py`)
| protocol | built in | extension |
|---|---|---|
| `Store` (run, job, and feedback records) | `sqlite` (stdlib, default, `.data/comparer.db`) and `jsonfiles` (one JSON per record under `.data/store/`) | subclass `Store`, set `COMPARER_STORE=module:Class`; Postgres/Mongo are **not** shipped, only the interface. Artifact bytes remain in local run/job folders. |
| `Source` (where inputs come from) | `inbox` folder manifests; HTTP push via `/api/jobs` | subclass `Source` for S3/CI artifacts/etc.; register with `COMPARER_SOURCES=module:Class` |
| vision `Provider` (`COMPARER_VISION_PROVIDER` pins one **strictly**: if the pinned name is not configured or fails to load, vision is disabled and `/api/health` + `/api/config` say why; it never falls back to another provider's key) | gemini, openai-compatible, anthropic, ollama | `COMPARER_PROVIDER_PLUGIN="<name>=<module>:<function>"` (comma-separate several). Signature: `fn(model, base_url, s_imgs, s_txt, t_imgs, t_txt, prompt="") -> str` where images are `(page_index, mime, base64)` and the return value is the raw model reply (JSON per API.md / the guidance prompt). The plugin reads its own credentials from the environment, is listed in `/api/config.vision.provider_plugins`, and is selectable via `options.vision.provider`. Bad specs are reported in `/api/automation.plugin_errors`. Reference: `tests/plugins_demo.py: echo_provider`. |

Adapter loading is explicit. A **store** that is configured but cannot be opened fails startup with a clear error
(never a silent switch to another store, which would split history). A **source** plugin that fails to load is
reported in `/api/automation.plugin_errors` and skipped. `tests/plugins_demo.py` is the reference for both hooks.

`openai` also counts as configured with only `OPENAI_BASE_URL` set (keyless local servers such as vLLM, LM Studio,
Ollama's `/v1`); the bearer header is then a placeholder.

## Storage layout (`services/comparer/.data`, gitignored)
```
.data/comparer.db            sqlite store (or .data/store/*.json with jsonfiles)
.data/runs/<run_id>/         originals (source.*, target.*), rendered pages, overlays, result.json
.data/jobs/<job_id>/         inputs copied at enqueue time (API uploads and inbox files); removed when the job completes
.data/server.lock            pid of the running server; `python -m comparer cleanup` refuses to run while it is live
```
