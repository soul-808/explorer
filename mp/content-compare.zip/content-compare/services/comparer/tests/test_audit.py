"""Focused tests for the correctness audit requested on the bus (2026-09-17)."""
import base64
import io
import json
import os
import sys
import unittest
import zipfile
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from comparer import deps, loaders, pipeline  # noqa: E402
from comparer.engines import ocr, vision_llm  # noqa: E402
from comparer.models import Locus  # noqa: E402
import fixtures  # noqa: E402

HAS_PIL = deps.pillow() is not None
HAS_OCR = ocr.availability()[0] == "ok"
TMP = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".tmp-artifacts")


def run(sname, sbytes, tname, tbytes, **opts):
    return pipeline.compare(sname, sbytes, tname, tbytes, opts, artifact_dir=TMP).to_dict()


class EngineSelection(unittest.TestCase):
    def test_empty_engines_list_means_none(self):
        r = run("a.txt", b"hello", "b.txt", b"hello", engines=[])
        self.assertEqual(r["verdict"]["status"], "inconclusive")
        self.assertTrue(all(e["status"] == "skipped" for e in r["engines"]))

    def test_unknown_engine_is_reported(self):
        r = run("a.txt", b"hello", "b.txt", b"hello", engines=["text", "bogus"])
        self.assertEqual(r["stats"]["unknown_engines"], ["bogus"])
        self.assertEqual(r["verdict"]["status"], "match")


class EmptyOrUnreadable(unittest.TestCase):
    def test_empty_vs_empty_is_inconclusive(self):
        r = run("a.txt", b"", "b.txt", b"")
        self.assertEqual(r["verdict"]["status"], "inconclusive")

    def test_whitespace_only_is_inconclusive(self):
        r = run("a.txt", b"  \n\t ", "b.txt", b"   ")
        self.assertEqual(r["verdict"]["status"], "inconclusive")
        self.assertTrue(r["stats"]["coverage"]["source"]["empty"])

    def test_garbage_pdf_is_inconclusive(self):
        r = run("a.pdf", b"%PDF-1.4 garbage", "b.pdf", b"%PDF-1.4 garbage")
        self.assertEqual(r["verdict"]["status"], "inconclusive")

    def test_text_vs_empty_is_not_a_match(self):
        r = run("a.txt", b"Save 20%", "b.txt", b"")
        self.assertNotEqual(r["verdict"]["status"], "match")


class ResponseShape(unittest.TestCase):
    def test_pages_include_text_preview(self):
        r = run("deck.docx", fixtures.docx_bytes(["Alpha", "Beta"]), "b.txt", b"Alpha\nBeta")
        self.assertIn("Alpha", r["source"]["pages"][0]["text"])
        self.assertIn("Beta", r["target"]["pages"][0]["text"])
        self.assertFalse(r["source"]["pages"][0]["text_truncated"])

    def test_coverage_stats_present(self):
        r = run("a.txt", b"x y z", "b.txt", b"x y z")
        cov = r["stats"]["coverage"]
        self.assertEqual(cov["source"]["text"], "native")
        self.assertFalse(cov["target"]["image"])

    def test_bbox_is_clamped(self):
        ctx = pipeline.Context(loaders.load("a.txt", b"x"), loaders.load("b.txt", b"x"), {})
        f = ctx.finding("visual_diff", "low", "t", 0.5, "m", source=Locus(0, (-0.2, 0.5, 2.0, 0.3)))
        self.assertEqual(f.source.bbox, (0.0, 0.5, 1.0, 0.3))
        f = ctx.finding("visual_diff", "low", "t", 0.5, "m", source=Locus(0, (1.2, 0.5, 0.1, 0.3)))
        self.assertIsNone(f.source.bbox)


class DocxHeadersFooters(unittest.TestCase):
    def test_header_footer_text_extracted(self):
        base = fixtures.docx_bytes(["Body copy"])
        buf = io.BytesIO()
        with zipfile.ZipFile(io.BytesIO(base)) as zin, zipfile.ZipFile(buf, "w") as zout:
            for item in zin.infolist():
                zout.writestr(item, zin.read(item.filename))
            hdr = ('<w:hdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
                   '<w:p><w:r><w:t>Confidential header</w:t></w:r></w:p></w:hdr>')
            ftr = hdr.replace("hdr", "ftr").replace("Confidential header", "Page footer legal line")
            zout.writestr("word/header1.xml", hdr)
            zout.writestr("word/footer1.xml", ftr)
        doc = loaders.load("d.docx", buf.getvalue())
        t = doc.full_text()
        self.assertIn("Confidential header", t)
        self.assertIn("Page footer legal line", t)
        self.assertLess(t.index("Confidential header"), t.index("Body copy"))
        self.assertGreater(t.index("Page footer legal line"), t.index("Body copy"))


class PageHandling(unittest.TestCase):
    def test_page_selection(self):
        # a 2-page "document" built from txt can't exist, so use docx vs pdf if a pdf backend exists
        if not (deps.module("pypdfium2") or deps.module("pypdf") or deps.binary("pdftotext")):
            self.skipTest("no pdf backend")
        pdf = fixtures.pdf_bytes(["One", "Two"])
        r = run("a.pdf", pdf, "b.pdf", pdf, pages={"source": [0], "target": [0]})
        self.assertEqual(len(r["source"]["pages"]), 1)
        self.assertEqual(r["verdict"]["status"], "match")

    def test_single_text_page_vs_multipage_uses_whole_stream(self):
        # simulate: docx (1 page) vs a target with 2 pages of text
        src = loaders.load("deck.docx", fixtures.docx_bytes(["Alpha one", "Beta two"]))
        tgt = loaders.load("t.txt", b"Alpha one")
        from comparer.models import Page
        tgt.pages.append(Page(index=1, text="Beta two", text_source="native"))
        ctx = pipeline.Context(src, tgt, {})
        from comparer.engines import text
        findings = text.run(ctx)
        self.assertEqual(findings, [], [f.message for f in findings])
        self.assertEqual(ctx.stats["text_mode"], "whole_document")

    def test_max_pages_truncation_note(self):
        if not deps.module("pypdfium2"):
            self.skipTest("needs pypdfium2")
        with mock.patch.object(loaders, "MAX_PAGES", 1):
            # two-page pdf: concatenate two single-page docs is non-trivial; assert the note logic via a 1-page doc
            doc = loaders.load("a.pdf", fixtures.pdf_bytes(["x"]))
            self.assertEqual(len(doc.pages), 1)


def multipage_pdf(page_texts):
    """Real independent pages, so differences beyond a processing cap are testable."""
    kids = " ".join(f"{4 + 2*i} 0 R" for i in range(len(page_texts)))
    objects = ["<< /Type /Catalog /Pages 2 0 R >>",
               f"<< /Type /Pages /Kids [{kids}] /Count {len(page_texts)} >>",
               "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"]
    for i, text in enumerate(page_texts):
        stream = f"BT /F1 12 Tf 10 40 Td ({text}) Tj ET"
        objects.extend([
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 100] /Contents {5 + 2*i} 0 R /Resources << /Font << /F1 3 0 R >> >> >>",
            f"<< /Length {len(stream)} >>\nstream\n{stream}\nendstream"])
    output = "%PDF-1.4\n"
    offsets = []
    for i, obj in enumerate(objects, 1):
        offsets.append(len(output))
        output += f"{i} 0 obj\n{obj}\nendobj\n"
    xref = len(output)
    output += f"xref\n0 {len(objects)+1}\n0000000000 65535 f \n"
    output += "".join(f"{offset:010d} 00000 n \n" for offset in offsets)
    output += f"trailer\n<< /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n"
    return output.encode("ascii")


class CoverageLimits(unittest.TestCase):
    def test_change_only_on_page_eleven_cannot_be_a_match(self):
        if not (deps.module("pypdfium2") or deps.module("pypdf") or deps.binary("pdftotext")):
            self.skipTest("no PDF reader")
        a = multipage_pdf(["Same approved copy"] * 10 + ["Save 20 percent"])
        b = multipage_pdf(["Same approved copy"] * 10 + ["Save 25 percent"])
        with mock.patch.object(loaders, "MAX_PAGES", 10):
            capped = run("a.pdf", a, "b.pdf", b, engines=["text"], render_overlays=False)
        self.assertEqual(capped["verdict"]["status"], "inconclusive")
        self.assertTrue(capped["stats"]["coverage_limits"])
        with mock.patch.object(loaders, "MAX_PAGES", 11):
            complete = run("a.pdf", a, "b.pdf", b, engines=["text"], render_overlays=False)
        self.assertEqual(complete["verdict"]["status"], "mismatch")
        self.assertTrue(any(f["target"]["page"] == 10 for f in complete["findings"] if f["target"]))

    def test_pypdf_fallback_records_cap(self):
        pypdf = deps.module("pypdf")
        if pypdf is None:
            self.skipTest("no pypdf")
        from comparer.models import Document
        doc = Document("capped.pdf", "pdf")
        with mock.patch.object(loaders, "MAX_PAGES", 1):
            loaders._pdf_pypdf(doc, multipage_pdf(["First", "Second"]), pypdf)
        self.assertEqual(doc.total_pages, 2)
        self.assertEqual(len(doc.pages), 1)
        self.assertTrue(doc.coverage_limits)

    def test_unknown_poppler_page_count_is_conservative_at_cap(self):
        if not deps.binary("pdftotext"):
            self.skipTest("no Poppler")
        binary = deps.binary
        with mock.patch.object(deps, "module", return_value=None), \
                mock.patch.object(deps, "binary", side_effect=lambda name: None if name in ("pdfinfo", "pdftoppm") else binary(name)), \
                mock.patch.object(loaders, "MAX_PAGES", 1):
            data = multipage_pdf(["First", "Second"])
            r = run("a.pdf", data, "b.pdf", data, engines=["text"], render_overlays=False)
        self.assertEqual(r["verdict"]["status"], "inconclusive")
        self.assertIn("could not be verified", " ".join(r["stats"]["coverage_limits"]))

    def test_model_text_limit_cannot_establish_match(self):
        reply = {"choices": [{"message": {"content": '{"match":true,"summary":"same","findings":[]}'}}]}
        with mock.patch.dict(os.environ, {"COMPARER_VISION_PROVIDER": "openai", "COMPARER_VISION_MODEL": "test", "OPENAI_API_KEY": "test"}), \
                mock.patch.object(vision_llm, "MAX_TEXT_PER_SIDE", 8), \
                mock.patch.object(vision_llm, "_post", return_value=reply):
            r = run("a.txt", b"Same prefix. Approved ending.", "b.txt", b"Same prefix. Wrong ending.", engines=["vision_llm"], render_overlays=False)
        self.assertEqual(r["verdict"]["status"], "inconclusive")
        self.assertIn("truncated", " ".join(r["stats"]["coverage_limits"]))

    def test_model_image_limit_records_unsent_page(self):
        from comparer.models import Document, Page
        doc = Document("pages.pdf", "pdf", pages=[Page(index=i, image_bytes=b"placeholder", image_format="png") for i in range(3)])
        warnings, limits = [], []
        with mock.patch.object(vision_llm, "MAX_IMAGES_PER_SIDE", 2):
            images, _ = vision_llm._side_parts(doc, warnings, "source", limits)
        self.assertEqual([p[0] for p in images], [0, 1])
        self.assertIn("page 3 not sent", " ".join(limits))


class VisionSecurity(unittest.TestCase):
    def setUp(self):
        self.env = {k: os.environ.pop(k) for k in list(os.environ) if k.startswith(("COMPARER_VISION", "GEMINI_", "OPENAI_", "ANTHROPIC_", "OLLAMA_"))}

    def tearDown(self):
        os.environ.update(self.env)

    def test_request_cannot_pick_unconfigured_provider(self):
        r = run("a.txt", b"x", "b.txt", b"x", engines=["vision_llm"], vision={"provider": "openai", "model": "m"})
        v = next(e for e in r["engines"] if e["name"] == "vision_llm")
        self.assertEqual(v["status"], "skipped")
        self.assertIn("not configured", v["message"])

    def test_request_base_url_is_ignored(self):
        os.environ["OPENAI_API_KEY"] = "sk-test"
        captured = {}
        def fake_post(url, body, headers):
            captured["url"] = url
            return {"choices": [{"message": {"content": '{"summary":"ok","match":true,"findings":[]}'}}]}
        with mock.patch.object(vision_llm, "_post", fake_post):
            r = run("a.txt", b"x", "b.txt", b"x", engines=["vision_llm"],
                    vision={"provider": "openai", "model": "m", "base_url": "http://evil.example/steal"})
        self.assertTrue(captured["url"].startswith("https://api.openai.com/"), captured)
        self.assertIn("base_url ignored", " ".join(r["stats"].get("warnings", [])))

    def test_no_provider_means_no_call(self):
        with mock.patch.object(vision_llm, "_post", side_effect=AssertionError("must not be called")):
            r = run("a.txt", b"x", "b.txt", b"x", engines=["vision_llm"], vision={"model": "m"})
        self.assertEqual(next(e for e in r["engines"] if e["name"] == "vision_llm")["status"], "skipped")

    def test_model_allowlist(self):
        os.environ["OPENAI_API_KEY"] = "sk-test"
        os.environ["COMPARER_VISION_MODELS"] = "allowed-model"
        with mock.patch.object(vision_llm, "_post", side_effect=AssertionError("must not be called")):
            r = run("a.txt", b"x", "b.txt", b"x", engines=["vision_llm"], vision={"model": "other"})
        v = next(e for e in r["engines"] if e["name"] == "vision_llm")
        self.assertIn("allow-list", v["message"])


@unittest.skipUnless(HAS_PIL, "Pillow")
class Orientation(unittest.TestCase):
    def test_exif_orientation_applied(self):
        from PIL import Image
        im = Image.new("RGB", (300, 100), (255, 255, 255))
        exif = Image.Exif(); exif[0x0112] = 6  # rotate 90
        buf = io.BytesIO(); im.save(buf, format="JPEG", exif=exif.tobytes())
        doc = loaders.load("p.jpg", buf.getvalue())
        self.assertEqual((doc.pages[0].width, doc.pages[0].height), (100, 300))

    @unittest.skipUnless(HAS_OCR, "OCR")
    def test_ocr_only_identical_blank_images_not_confident_match(self):
        from PIL import Image
        blank = fixtures.png_bytes(Image.new("RGB", (400, 200), (255, 255, 255)))
        r = run("a.png", blank, "b.png", blank, engines=["ocr", "text"])
        # nothing was read on either side: text engine must skip, verdict inconclusive
        self.assertEqual(r["verdict"]["status"], "inconclusive")

    @unittest.skipUnless(HAS_OCR, "OCR")
    def test_ocr_match_confidence_scaled(self):
        src = fixtures.png_bytes(fixtures.render_card(fixtures.SOURCE_LINES))
        r = run("a.png", src, "b.png", src, engines=["ocr", "text"])
        self.assertEqual(r["verdict"]["status"], "match")
        self.assertIsNotNone(r["stats"]["coverage"]["source"]["ocr_confidence"])
        self.assertLess(r["verdict"]["confidence"], 0.7)


if __name__ == "__main__":
    unittest.main()


class ReviewRegressions(unittest.TestCase):
    """Items from codex's REVIEW entries on the bus."""

    def _env(self):
        saved = {k: os.environ.pop(k) for k in list(os.environ) if k.startswith(("COMPARER_VISION", "GEMINI_", "OPENAI_", "ANTHROPIC_", "OLLAMA_"))}
        os.environ["OPENAI_API_KEY"] = "sk-test"
        return saved

    def test_malformed_model_output_is_failed_not_match(self):
        saved = self._env()
        try:
            with mock.patch.object(vision_llm, "_post", return_value={"choices": [{"message": {"content": "Sure! They look the same."}}]}):
                r = run("a.txt", b"x", "b.txt", b"x", engines=["vision_llm"], vision={"model": "m"})
            v = next(e for e in r["engines"] if e["name"] == "vision_llm")
            self.assertEqual(v["status"], "failed")
            self.assertEqual(r["verdict"]["status"], "inconclusive")
        finally:
            for k in list(os.environ):
                if k.startswith(("COMPARER_VISION", "OPENAI_")): os.environ.pop(k)
            os.environ.update(saved)

    def test_explicit_match_false_without_findings_is_mismatch(self):
        saved = self._env()
        try:
            content = json.dumps({"summary": "layout differs", "match": False, "findings": []})
            with mock.patch.object(vision_llm, "_post", return_value={"choices": [{"message": {"content": content}}]}):
                r = run("a.txt", b"x", "b.txt", b"x", engines=["vision_llm"], vision={"model": "m"})
            self.assertEqual(r["verdict"]["status"], "mismatch")
            self.assertEqual(r["findings"][0]["engine"], "vision_llm")
        finally:
            for k in list(os.environ):
                if k.startswith(("COMPARER_VISION", "OPENAI_")): os.environ.pop(k)
            os.environ.update(saved)

    def test_low_severity_finding_is_still_mismatch(self):
        src = loaders.load("a.txt", b"x"); tgt = loaders.load("b.txt", b"x")
        from comparer.models import CompareResult, EngineReport
        r = CompareResult("cmp_x", "now", src, tgt, engines=[EngineReport("pixel", "ok")], stats={"coverage": pipeline._coverage(src, tgt)})
        ctx = pipeline.Context(src, tgt, {})
        r.findings = [ctx.finding("visual_diff", "low", "pixel", 0.5, "tiny")]
        self.assertEqual(pipeline._verdict(r)["status"], "mismatch")
        r.findings = [ctx.finding("llm_observation", "info", "vision_llm", 0.5, "note")]
        self.assertEqual(pipeline._verdict(r)["status"], "match")

    def test_artifact_route_rejects_traversal_and_bad_ids(self):
        import threading, urllib.request, urllib.error
        from http.server import ThreadingHTTPServer
        from comparer.server import Handler
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        port = httpd.server_address[1]
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        try:
            for path in ("/api/artifacts/../server.py", "/api/artifacts/..%2F..%2Fpyproject.toml/x.png",
                         "/api/artifacts/notcmp/source-0.png", "/api/artifacts/cmp_20260917T150000_abcd/../../pyproject.toml",
                         "/api/artifacts/cmp_20260917T150000_abcd/evil.sh"):
                with self.assertRaises(urllib.error.HTTPError, msg=path) as cm:
                    urllib.request.urlopen(f"http://127.0.0.1:{port}{path}")
                self.assertEqual(cm.exception.code, 404, path)
            # CORS: localhost origin allowed, foreign origin rejected on POST
            body = json.dumps({"source": {"name": "a.txt", "content_base64": base64.b64encode(b"x").decode()},
                               "target": {"name": "b.txt", "content_base64": base64.b64encode(b"x").decode()},
                               "options": {"render_overlays": False}}).encode()
            req = urllib.request.Request(f"http://127.0.0.1:{port}/api/compare", data=body,
                                         headers={"Content-Type": "application/json", "Origin": "http://127.0.0.1:3100"})
            with urllib.request.urlopen(req) as resp:
                self.assertEqual(resp.headers["Access-Control-Allow-Origin"], "http://127.0.0.1:3100")
            req = urllib.request.Request(f"http://127.0.0.1:{port}/api/compare", data=body,
                                         headers={"Content-Type": "application/json", "Origin": "https://evil.example"})
            with self.assertRaises(urllib.error.HTTPError) as cm:
                urllib.request.urlopen(req)
            self.assertEqual(cm.exception.code, 403)
        finally:
            httpd.shutdown(); httpd.server_close()

    def test_ignore_whitespace_false_is_reported_unsupported(self):
        r = run("a.txt", b"a b", "b.txt", b"a  b", text={"ignore_whitespace": False})
        self.assertIn("not supported", " ".join(r["stats"]["warnings"]))

    def test_docx_zip_bomb_capped(self):
        with mock.patch.object(loaders, "MAX_ZIP_EXPANDED", 10):
            doc = loaders.load("d.docx", fixtures.docx_bytes(["hello world"]))
        self.assertTrue(any("cap" in n for n in doc.notes), doc.notes)
        self.assertEqual(doc.full_text(), "")

    def test_unreadable_page_blocks_global_match(self):
        src = loaders.load("a.txt", b"same"); tgt = loaders.load("b.txt", b"same")
        from comparer.models import Page
        src.pages.append(Page(index=1)); tgt.pages.append(Page(index=1))  # unreadable second pages
        ctx = pipeline.Context(src, tgt, {})
        from comparer.models import CompareResult, EngineReport
        r = CompareResult("cmp_x", "now", src, tgt, engines=[EngineReport("text", "ok")], stats={"coverage": pipeline._coverage(src, tgt)})
        self.assertEqual(pipeline._verdict(r)["status"], "inconclusive")


@unittest.skipUnless(HAS_PIL, "Pillow")
class SsimAndPages(unittest.TestCase):
    def _imgs(self):
        from PIL import Image, ImageDraw
        a = Image.new("RGB", (300, 200), (255, 255, 255))
        b = Image.new("RGB", (300, 200), (255, 255, 255))
        d = ImageDraw.Draw(b)
        for x in range(0, 300, 20):
            d.line([(x, 0), (x, 200)], fill=(0, 0, 0), width=6)
        return fixtures.png_bytes(a), fixtures.png_bytes(b)

    @unittest.skipUnless(deps.module("skimage.metrics") is not None, "scikit-image")
    def test_ssim_only_different_images_is_mismatch(self):
        a, b = self._imgs()
        r = run("a.png", a, "b.png", b, engines=["ssim"])
        self.assertEqual(r["verdict"]["status"], "mismatch")
        self.assertTrue(any(f["engine"] == "ssim" for f in r["findings"]))
        self.assertLess(r["stats"]["ssim"], 0.9)

    @unittest.skipUnless(deps.module("skimage.metrics") is not None, "scikit-image")
    def test_ssim_only_identical_images_is_match(self):
        a, _ = self._imgs()
        r = run("a.png", a, "b.png", a, engines=["ssim"])
        self.assertEqual(r["verdict"]["status"], "match")
        self.assertEqual(r["stats"]["ssim"], 1.0)

    def test_pixel_only_missing_page_is_flagged(self):
        a, _ = self._imgs()
        src = loaders.load("a.png", a); tgt = loaders.load("b.png", a)
        from comparer.models import Page
        src.pages.append(Page(index=1, image=src.pages[0].image, width=300, height=200))
        ctx = pipeline.Context(src, tgt, {})
        from comparer.engines import pixel
        findings = pixel.run(ctx)
        self.assertTrue(any("only in the source" in f.message for f in findings))
        self.assertEqual(findings[-1].source.page, 1)

    def test_pixel_uses_real_page_indexes_after_selection(self):
        if not deps.module("pypdfium2"):
            self.skipTest("pypdfium2")
        pdf = fixtures.pdf_bytes(["One", "Two"])
        # two single-page pdfs can't select page 1; emulate by loading and re-indexing
        src = loaders.load("a.pdf", pdf); tgt = loaders.load("b.pdf", pdf)
        src.pages[0].index = 3; tgt.pages[0].index = 3
        from PIL import ImageDraw
        ImageDraw.Draw(tgt.pages[0].image).rectangle([10, 10, 200, 200], fill=(0, 0, 0))
        ctx = pipeline.Context(src, tgt, {})
        from comparer.engines import pixel
        findings = pixel.run(ctx)
        self.assertTrue(findings)
        self.assertEqual({f.target.page for f in findings}, {3})

    def test_coverage_gaps_become_warnings(self):
        r = run("a.txt", b"x", "b.txt", b"")
        self.assertTrue(any("no readable" in w for w in r["stats"]["warnings"]))
