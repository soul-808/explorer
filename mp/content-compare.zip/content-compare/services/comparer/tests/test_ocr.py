"""OCR quality on layouts that trip naive tesseract use: large display numbers, light-on-dark
buttons, two columns. All skipped without an OCR backend."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from comparer import deps, loaders, pipeline  # noqa: E402
from comparer.engines import ocr, textnorm  # noqa: E402
from comparer.models import Word  # noqa: E402
import fixtures  # noqa: E402

HAS_OCR = ocr.availability()[0] == "ok" and ocr.availability()[1] == "pytesseract"
TMP = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".tmp-artifacts")


def ocr_text(png):
    doc = loaders.load("x.png", png)
    ctx = pipeline.Context(doc, doc, {})
    ocr.run(ctx)
    return textnorm.normalize(doc.pages[0].text)


class ReadingOrder(unittest.TestCase):
    def test_columns_do_not_interleave(self):
        # left column: two lines; right column: two lines; plus a tall display word spanning both right lines
        w = lambda t, x, y, wd, h: Word(t, (x, y, wd, h), 0.9)
        words = [w("4.25%", 0.09, 0.46, 0.2, 0.08), w("ANNUAL", 0.09, 0.56, 0.06, 0.02), w("YIELD", 0.16, 0.56, 0.05, 0.02),
                 w("A", 0.54, 0.47, 0.01, 0.02), w("better", 0.56, 0.47, 0.05, 0.02),
                 w("everyday", 0.54, 0.51, 0.07, 0.02), w("savings.", 0.62, 0.51, 0.06, 0.02)]
        out = [x.text for x in ocr.reading_order(words)]
        self.assertEqual(out, ["4.25%", "ANNUAL", "YIELD", "A", "better", "everyday", "savings."])

    def test_merge_prefers_fewer_confident_tokens(self):
        a = [Word("4", (0.1, 0.5, 0.04, 0.08), 0.96), Word("2", (0.15, 0.5, 0.02, 0.08), 0.52), Word("5", (0.2, 0.5, 0.04, 0.08), 0.74), Word("%", (0.25, 0.5, 0.04, 0.08), 0.9)]
        b = [Word("4.25%", (0.1, 0.5, 0.2, 0.08), 0.95)]
        self.assertEqual([x.text for x in ocr.merge_passes(a, b)], ["4.25%"])
        # a lone secondary word elsewhere is kept
        b.append(Word("extra", (0.6, 0.6, 0.05, 0.02), 0.9))
        self.assertEqual(sorted(x.text for x in ocr.merge_passes(a, b)), ["4.25%", "extra"])


@unittest.skipUnless(HAS_OCR, "pytesseract")
class BannerOCR(unittest.TestCase):
    def test_reads_rate_button_and_columns(self):
        t = ocr_text(fixtures.png_bytes(fixtures.render_banner()))
        self.assertIn("4.25%", t)
        self.assertIn("open an account", t)
        squashed = t.replace(" ", "")   # tesseract may fuse tightly kerned pairs ("Abetter"); order is what matters
        self.assertIn("abetterplaceforyoureverydaysavings", squashed)
        self.assertIn("makeyournextchapteralittlebrighter", squashed)
        self.assertLess(squashed.index("4.25%"), squashed.index("abetterplace"))
        self.assertNotIn("(0)", t)

    def test_rate_change_is_high_severity_and_button_change_found(self):
        src = fixtures.png_bytes(fixtures.render_banner())
        tgt = fixtures.png_bytes(fixtures.render_banner(rate="4.75%", cta="Start saving", disclaimer=False))
        r = pipeline.compare("a.png", src, "b.png", tgt, {"engines": ["ocr", "text"]}, artifact_dir=TMP).to_dict()
        msgs = {f["message"]: f for f in r["findings"]}
        rate = next(f for m, f in msgs.items() if "4.75%" in m)
        self.assertEqual(rate["category"], "text_changed")
        self.assertIn(rate["severity"], ("high", "medium"))
        self.assertNotIn("noise", rate["message"])
        self.assertTrue(any("start saving" in m for m in msgs))
        self.assertTrue(any(f["category"] == "text_missing" and "terms and conditions" in m for m, f in msgs.items()))
        # no false positives beyond the three real changes
        real = [f for f in r["findings"] if f["severity"] in ("high", "medium")]
        self.assertLessEqual(len(real), 4, [f["message"] for f in real])

    def test_identical_banner_no_text_findings(self):
        src = fixtures.png_bytes(fixtures.render_banner())
        r = pipeline.compare("a.png", src, "b.png", src, {"engines": ["ocr", "text"]}, artifact_dir=TMP).to_dict()
        self.assertEqual(r["findings"], [])


if __name__ == "__main__":
    unittest.main()
