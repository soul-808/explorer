"""Reference plugins proving the extension hooks work: an in-memory Store and a static Source.
Load with COMPARER_STORE=plugins_demo:MemoryStore and COMPARER_SOURCES=plugins_demo:StaticSource."""
from comparer.adapters import Source, Store
from comparer.store_json import JsonFilesStore


class MemoryStore(JsonFilesStore):
    """Same behaviour as the JSON store but in a temp dir: shows the constructor contract (path)."""
    kind = "memory-demo"

    def __init__(self, path):
        import tempfile
        super().__init__(tempfile.mkdtemp(prefix="comparer-memstore-"))


class StaticSource(Source):
    """Emits one fixed pair the first time it is polled."""
    kind = "static-demo"
    polls = 0

    def poll(self):
        StaticSource.polls += 1
        if StaticSource.polls > 1:
            return []
        return [{"source": ("a.txt", b"Save 20%"), "target": ("b.txt", b"Save 25%"),
                 "labels": {"from": "plugin"}, "options": {"engines": ["text"]},
                 "idempotency_key": "static:1", "batch": "plugin-batch"}]


class BrokenStore(Store):
    kind = "broken"

    def __init__(self, path):
        pass

    def open(self):
        raise RuntimeError("cannot connect to fake database")


def echo_provider(model, base_url, s_imgs, s_txt, t_imgs, t_txt, prompt=""):
    """Reference vision provider plugin: never calls a network. Returns a valid base-pass reply,
    or a valid guidance-pass reply when the prompt is the second-pass one."""
    import json
    echo_provider.calls.append({"model": model, "images": len(s_imgs) + len(t_imgs), "prompt_head": (prompt or "")[:40]})
    if "SECOND-PASS" in (prompt or ""):
        return json.dumps({"decisions": []})
    return json.dumps({"summary": f"echo:{model}", "match": False,
                       "findings": [{"category": "llm_observation", "severity": "low", "message": "plugin saw both sides"}]})


echo_provider.calls = []
