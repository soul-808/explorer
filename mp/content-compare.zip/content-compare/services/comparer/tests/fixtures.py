"""Generate deterministic sample assets (no binary fixtures in git)."""
from __future__ import annotations

import io
import zipfile

SOURCE_LINES = ["Summer Sale", "Save 20% on all plans", "Offer ends June 30", "Terms and conditions apply"]
TARGET_LINES = ["Summer Sale", "Save 25% on all plans", "Offer ends June 30", ""]  # price changed, disclaimer missing


def render_card(lines, size=(900, 560), accent=(46, 99, 221), badge=True):
    from PIL import Image, ImageDraw, ImageFont
    im = Image.new("RGB", size, (250, 250, 252))
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, size[0], 90], fill=accent)
    if badge:
        d.ellipse([size[0] - 140, 130, size[0] - 40, 230], fill=(240, 90, 60))
    try:
        big = ImageFont.load_default(size=46); body = ImageFont.load_default(size=30); small = ImageFont.load_default(size=22)
    except TypeError:
        big = body = small = ImageFont.load_default()
    d.text((60, 22), lines[0], fill=(255, 255, 255), font=big)  # light-on-dark header
    y = 210
    for i, line in enumerate(lines[1:]):
        font = small if i == len(lines) - 2 else body
        d.text((60, y), line, fill=(20, 20, 30), font=font)
        y += 80
    return im


BANNER_COPY = ["Savings, with a little more possibility.", "Make your next chapter a little brighter.",
               "4.25%", "ANNUAL PERCENTAGE YIELD", "A better place for your everyday savings.",
               "No monthly fees. No minimum balance.", "Open an account", "Offer ends June 30, 2026.",
               "APY is variable and may change. Terms and conditions apply."]


def render_banner(rate="4.25%", cta="Open an account", disclaimer=True, size=(1000, 740)):
    """Two-column banner with a large display number and a light-on-dark button: the layout
    shapes that trip up naive OCR (glyph splitting, swallowed lines, missed button text)."""
    from PIL import Image, ImageDraw, ImageFont
    im = Image.new("RGB", size, (250, 250, 247))
    d = ImageDraw.Draw(im)
    d.rectangle([46, 118, 954, 600], fill=(241, 244, 232))
    def font(px):
        try:
            return ImageFont.load_default(size=px)
        except TypeError:
            return ImageFont.load_default()
    dark = (30, 60, 40); grey = (80, 90, 80)
    d.text((90, 160), "Savings, with a little", fill=dark, font=font(40))
    d.text((90, 208), "more possibility.", fill=dark, font=font(40))
    d.text((90, 270), "Make your next chapter a little brighter.", fill=grey, font=font(20))
    d.text((90, 330), rate, fill=dark, font=font(78))
    d.text((94, 418), "ANNUAL PERCENTAGE YIELD", fill=grey, font=font(14))
    d.text((538, 348), "A better place for your", fill=dark, font=font(19))
    d.text((538, 374), "everyday savings.", fill=dark, font=font(19))
    d.text((538, 416), "No monthly fees.", fill=grey, font=font(18))
    d.text((538, 440), "No minimum balance.", fill=grey, font=font(18))
    d.rectangle([90, 490, 337, 548], fill=(47, 109, 75))
    d.text((118, 508), cta, fill=(255, 255, 255), font=font(20))
    d.text((360, 512), "Offer ends June 30, 2026.", fill=grey, font=font(15))
    if disclaimer:
        d.text((54, 638), "APY is variable and may change. Terms and conditions apply.", fill=dark, font=font(17))
    return im


def png_bytes(im) -> bytes:
    buf = io.BytesIO(); im.save(buf, format="PNG"); return buf.getvalue()


def docx_bytes(paragraphs) -> bytes:
    body = "".join(f"<w:p><w:r><w:t xml:space=\"preserve\">{p}</w:t></w:r></w:p>" for p in paragraphs)
    document = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
                f"<w:body>{body}</w:body></w:document>")
    ctypes = ('<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
              '<Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
              '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ctypes)
        z.writestr("_rels/.rels", rels)
        z.writestr("word/document.xml", document)
    return buf.getvalue()


def pdf_bytes(lines) -> bytes:
    """Minimal single-page PDF with Helvetica text (no library needed)."""
    content = "BT /F1 24 Tf 60 700 Td " + " ".join(f"({l.replace('(', '').replace(')', '')}) Tj 0 -40 Td" for l in lines) + " ET"
    objs = [
        "<< /Type /Catalog /Pages 2 0 R >>",
        "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
        f"<< /Length {len(content)} >>\nstream\n{content}\nendstream",
        "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]
    out = "%PDF-1.4\n"
    offsets = []
    for i, o in enumerate(objs, 1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n{o}\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n" + "".join(f"{o:010d} 00000 n \n" for o in offsets)
    out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n"
    return out.encode("latin-1")


if __name__ == "__main__":
    import os, sys
    out = sys.argv[1] if len(sys.argv) > 1 else "samples"
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "design.png"), "wb") as f: f.write(png_bytes(render_card(SOURCE_LINES)))
    with open(os.path.join(out, "app-screenshot.png"), "wb") as f: f.write(png_bytes(render_card(TARGET_LINES, badge=False)))
    with open(os.path.join(out, "copy-deck.docx"), "wb") as f: f.write(docx_bytes(SOURCE_LINES))
    with open(os.path.join(out, "copy-deck.txt"), "w") as f: f.write("\n".join(SOURCE_LINES))
    with open(os.path.join(out, "approved.pdf"), "wb") as f: f.write(pdf_bytes(SOURCE_LINES))
    print("wrote samples to", out)
