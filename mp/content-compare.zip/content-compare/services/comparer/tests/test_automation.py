"""Automation layer: stores, jobs, worker recovery, inbox intake, feedback export, HTTP routes."""
import base64
import json
import os
import shutil
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from comparer import automation, server  # noqa: E402
from comparer.automation import Automation, ConfigError, build_config  # noqa: E402
import fixtures  # noqa: E402

SRC = "\n".join(fixtures.SOURCE_LINES).encode()
TGT = "\n".join(fixtures.TARGET_LINES).encode()


def make_auto(tmp, store="sqlite", **extra):
    env = {"COMPARER_DATA_DIR": tmp, "COMPARER_STORE": store, "COMPARER_WORKERS": "0", **extra}
    return Automation(build_config(env))


class StoreCases:
    STORE = "sqlite"

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.auto = make_auto(self.tmp, self.STORE)

    def tearDown(self):
        self.auto.stop(); shutil.rmtree(self.tmp, ignore_errors=True)

    def _job(self, key=None, src=SRC, tgt=TGT):
        job, created = self.auto.enqueue(("a.txt", src), ("b.txt", tgt), {"engines": ["text"]}, {"suite": "x"}, key)
        return job, created

    def test_job_lifecycle_produces_run(self):
        job, created = self._job()
        self.assertTrue(created); self.assertEqual(job["status"], "queued")
        done = self.auto.process_one()
        self.assertEqual(done["status"], "done"); self.assertTrue(done["run_id"].startswith("run_"))
        run = self.auto.store.get_run(done["run_id"])
        self.assertEqual(run["origin"], "job"); self.assertEqual(run["verdict"]["status"], "mismatch")
        self.assertEqual(run["labels"], {"suite": "x"}); self.assertEqual(run["job_id"], job["id"])
        self.assertIn("findings", run["result"])
        runs, cursor = self.auto.store.list_runs()
        self.assertEqual([r["id"] for r in runs], [run["id"]]); self.assertIsNone(cursor)
        self.assertNotIn("result", runs[0])
        self.assertIsNone(self.auto.process_one())     # queue empty

    def test_idempotency_key(self):
        j1, c1 = self._job("build-1:a:b"); j2, c2 = self._job("build-1:a:b")
        self.assertTrue(c1); self.assertFalse(c2); self.assertEqual(j1["id"], j2["id"])
        self.assertEqual(self.auto.store.job_counts(), {"queued": 1})

    def test_cancel_only_when_queued(self):
        job, _ = self._job()
        self.assertEqual(self.auto.cancel(job["id"])["status"], "cancelled")
        self.assertIsNone(self.auto.process_one())
        job, _ = self._job(); self.auto.process_one()
        self.assertEqual(self.auto.cancel(job["id"])["status"], "done")

    def test_recover_running_after_crash(self):
        job, _ = self._job()
        claimed = self.auto.store.claim_next_job("w1")
        self.assertEqual(claimed["status"], "running"); self.assertEqual(claimed["attempts"], 1)
        self.assertEqual(self.auto.store.recover_running(max_attempts=2), 1)
        self.assertEqual(self.auto.store.get_job(job["id"])["status"], "queued")
        self.auto.store.claim_next_job("w1")
        self.assertEqual(self.auto.store.recover_running(max_attempts=2), 1)
        self.assertEqual(self.auto.store.get_job(job["id"])["status"], "failed")

    def test_failed_job_retries_then_fails(self):
        job, _ = self._job()
        os.remove(job["paths"]["source"])      # make execution fail
        j = self.auto.process_one(); self.assertEqual(j["status"], "queued"); self.assertIn("retry", j["error"])
        j = self.auto.process_one(); self.assertEqual(j["status"], "failed")

    def test_feedback_and_export(self):
        self._job(); done = self.auto.process_one()
        rid = done["run_id"]
        fid = self.auto.store.get_run(rid)["result"]["findings"][0]["id"]
        fb = self.auto.add_feedback(rid, {"finding_id": fid, "verdict": "false_positive", "comment": "ok", "reviewer": "qa"})
        self.assertTrue(fb["id"].startswith("fb_")); self.assertEqual(fb["finding"]["id"], fid)
        with self.assertRaises(ConfigError):
            self.auto.add_feedback(rid, {"verdict": "nope"})
        with self.assertRaises(ConfigError):
            self.auto.add_feedback(rid, {"finding_id": "f999", "verdict": "correct"})
        with self.assertRaises(KeyError):
            self.auto.add_feedback("run_00000000T000000_0000", {"verdict": "correct"})
        rows = list(self.auto.export_feedback())
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["verdict"], "false_positive"); self.assertEqual(rows[0]["context"]["source_kind"], "txt")
        self.assertEqual(self.auto.store.get_run(rid)["feedback_count"], 1)
        self.assertEqual(self.auto.store.list_runs()[0][0]["feedback_count"], 1)

    def test_delete_run(self):
        self._job(); done = self.auto.process_one()
        self.assertTrue(self.auto.store.delete_run(done["run_id"]))
        self.assertIsNone(self.auto.store.get_run(done["run_id"]))
        self.assertFalse(self.auto.store.delete_run(done["run_id"]))

    def test_list_runs_paging_and_filters(self):
        for i in range(3):
            self._job(); self.auto.process_one()
        page1, cur = self.auto.store.list_runs(limit=2)
        self.assertEqual(len(page1), 2); self.assertIsNotNone(cur)
        page2, cur2 = self.auto.store.list_runs(limit=2, cursor=cur)
        self.assertEqual(len(page2), 1); self.assertIsNone(cur2)
        self.assertEqual(self.auto.store.list_runs(origin="manual")[0], [])
        self.assertEqual(len(self.auto.store.list_runs(status="mismatch")[0]), 3)


class SqliteStoreTests(StoreCases, unittest.TestCase):
    STORE = "sqlite"


class JsonFilesStoreTests(StoreCases, unittest.TestCase):
    STORE = "jsonfiles"


class Intake(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(); self.inbox = os.path.join(self.tmp, "inbox"); os.makedirs(self.inbox)
        self.auto = make_auto(os.path.join(self.tmp, "data"), COMPARER_INBOX=self.inbox)

    def tearDown(self):
        self.auto.stop(); shutil.rmtree(self.tmp, ignore_errors=True)

    def _put(self, rel, data):
        p = os.path.join(self.inbox, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "wb") as f:
            f.write(data)

    def test_manifest_becomes_jobs_and_runs(self):
        self._put("approved/a.txt", SRC); self._put("shots/b.txt", TGT)
        with open(os.path.join(self.inbox, "build-1.json"), "w") as f:
            json.dump({"batch": "build-1", "pairs": [{"source": "approved/a.txt", "target": "shots/b.txt", "labels": {"suite": "s"}}]}, f)
        out = self.auto.poll_once()
        self.assertEqual(out["created"], 1); self.assertEqual(out["errors"], [])
        self.assertTrue(os.path.exists(os.path.join(self.inbox, "build-1.json.done")))
        job = self.auto.store.list_jobs()[0]
        self.assertEqual(job["origin"], "intake"); self.assertEqual(job["idempotency_key"], "build-1:approved/a.txt:shots/b.txt")
        done = self.auto.process_one()
        self.assertEqual(self.auto.store.get_run(done["run_id"])["origin"], "intake")
        # re-dropping the same manifest is a duplicate
        with open(os.path.join(self.inbox, "build-1.json"), "w") as f:
            json.dump({"batch": "build-1", "pairs": [{"source": "approved/a.txt", "target": "shots/b.txt"}]}, f)
        out = self.auto.poll_once()
        self.assertEqual((out["created"], out["skipped_duplicates"]), (0, 1))

    def test_traversal_symlink_and_missing_are_rejected(self):
        outside = os.path.join(self.tmp, "secret.txt")
        with open(outside, "w") as f:
            f.write("secret")
        os.symlink(outside, os.path.join(self.inbox, "link.txt"))
        src = self.auto.sources[0]
        for bad in ("../secret.txt", "/etc/passwd", "link.txt", "missing.txt", "a/../../secret.txt"):
            with self.assertRaises(ConfigError, msg=bad):
                src.resolve(bad)
        with open(os.path.join(self.inbox, "bad.json"), "w") as f:
            json.dump({"pairs": [{"source": "../secret.txt", "target": "link.txt"}]}, f)
        out = self.auto.poll_once()
        self.assertEqual(out["created"], 0)
        self.assertTrue(os.path.exists(os.path.join(self.inbox, "bad.json.failed")))
        self.assertTrue(os.path.exists(os.path.join(self.inbox, "bad.json.error.txt")))
        self.assertTrue(self.auto.sources[0].status()["errors"])


class HttpBase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(); self.inbox = os.path.join(self.tmp, "inbox"); os.makedirs(self.inbox)
        self.auto = make_auto(os.path.join(self.tmp, "data"), COMPARER_INBOX=self.inbox, COMPARER_TOKEN="s3cret")
        server.AUTOMATION = self.auto
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        self.base = f"http://127.0.0.1:{self.httpd.server_address[1]}"
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def tearDown(self):
        self.httpd.shutdown(); self.httpd.server_close(); server.AUTOMATION = None
        self.auto.stop(); shutil.rmtree(self.tmp, ignore_errors=True)

    def call(self, method, path, body=None, headers=None, raw=False):
        data = json.dumps(body).encode() if isinstance(body, (dict, list)) else body
        req = urllib.request.Request(self.base + path, data=data, method=method,
                                     headers={"Content-Type": "application/json", **(headers or {})})
        try:
            with urllib.request.urlopen(req) as r:
                payload = r.read()
                return r.status, (payload if raw else (json.loads(payload) if payload else None))
        except urllib.error.HTTPError as e:
            payload = e.read()
            return e.code, (json.loads(payload) if payload else None)

    def b64(self, b):
        return base64.b64encode(b).decode()


class HttpRoutes(HttpBase):
    def test_manual_compare_is_recorded_and_visible(self):
        code, out = self.call("POST", "/api/compare", {"source": {"name": "a.txt", "content_base64": self.b64(SRC)},
                                                      "target": {"name": "b.txt", "content_base64": self.b64(TGT)},
                                                      "options": {"engines": ["text"], "labels": {"campaign": "summer"}}})
        self.assertEqual(code, 200); rid = out["run_id"]; self.assertTrue(rid.startswith("run_"))
        code, runs = self.call("GET", "/api/runs?origin=manual")
        self.assertEqual([r["id"] for r in runs["runs"]], [rid]); self.assertEqual(runs["runs"][0]["labels"], {"campaign": "summer"})
        code, run = self.call("GET", f"/api/runs/{rid}")
        self.assertEqual(code, 200); self.assertEqual(run["result"]["id"], out["id"])
        code, data = self.call("GET", f"/api/runs/{rid}/artifacts/source-original.txt", raw=True)
        self.assertEqual(code, 200); self.assertEqual(data, SRC)
        self.assertEqual(self.call("GET", f"/api/runs/{rid}/artifacts/../../secret")[0], 404)
        # persist:false
        code, out = self.call("POST", "/api/compare", {"source": {"name": "a.txt", "content_base64": self.b64(SRC)},
                                                      "target": {"name": "b.txt", "content_base64": self.b64(SRC)},
                                                      "options": {"engines": ["text"], "persist": False}})
        self.assertNotIn("run_id", out)
        self.assertEqual(len(self.call("GET", "/api/runs")[1]["runs"]), 1)

    def test_jobs_routes_and_token(self):
        body = {"source": {"name": "a.txt", "content_base64": self.b64(SRC)}, "target": {"name": "b.txt", "content_base64": self.b64(TGT)},
                "options": {"engines": ["text"]}, "idempotency_key": "k1", "labels": {"suite": "s"}}
        self.assertEqual(self.call("POST", "/api/jobs", body)[0], 401)
        auth = {"Authorization": "Bearer s3cret"}
        code, out = self.call("POST", "/api/jobs", body, auth)
        self.assertEqual(code, 202); job = out["job"]; self.assertNotIn("paths", job)
        code, out = self.call("POST", "/api/jobs", body, auth)
        self.assertEqual(code, 200); self.assertFalse(out["created"])
        code, out = self.call("GET", f"/api/jobs/{job['id']}")
        self.assertEqual(out["status"], "queued")
        self.auto.process_one()
        code, out = self.call("GET", "/api/jobs?status=done")
        self.assertEqual(len(out["jobs"]), 1); rid = out["jobs"][0]["run_id"]
        # inbox-relative path input
        with open(os.path.join(self.inbox, "x.txt"), "wb") as f:
            f.write(SRC)
        code, out = self.call("POST", "/api/jobs", {"source": {"path": "x.txt"}, "target": {"path": "x.txt"}, "options": {"engines": ["text"]}}, auth)
        self.assertEqual(code, 202)
        code, out = self.call("POST", "/api/jobs", {"source": {"path": "../x.txt"}, "target": {"path": "x.txt"}}, auth)
        self.assertEqual(code, 400)
        # feedback + export
        code, fb = self.call("POST", f"/api/runs/{rid}/feedback", {"verdict": "correct", "reviewer": "qa"})
        self.assertEqual(code, 201)
        self.assertEqual(self.call("GET", f"/api/runs/{rid}/feedback")[1][0]["id"], fb["id"])
        self.assertEqual(self.call("GET", "/api/feedback/export")[0], 401)
        code, data = self.call("GET", "/api/feedback/export", headers=auth, raw=True)
        self.assertEqual(code, 200); self.assertEqual(json.loads(data.decode().strip())["verdict"], "correct")
        # automation + config + delete
        code, st = self.call("GET", "/api/automation")
        self.assertEqual(st["worker"]["done"], 1); self.assertTrue(st["intake"]["enabled"]); self.assertTrue(st["store"]["ok"])
        code, cfg = self.call("GET", "/api/config")
        self.assertEqual(cfg["store"]["kind"], "sqlite"); self.assertTrue(cfg["automation"]["token_required"])
        self.assertNotIn("s3cret", json.dumps(cfg))
        self.assertEqual(self.call("DELETE", f"/api/runs/{rid}")[0], 401)
        self.assertEqual(self.call("DELETE", f"/api/runs/{rid}", headers=auth)[0], 204)
        self.assertEqual(self.call("GET", f"/api/runs/{rid}")[0], 404)
        code, out = self.call("POST", "/api/automation/poll", b"", auth)
        self.assertEqual(code, 200); self.assertIn("created", out)

    def test_worker_thread_end_to_end(self):
        auto = make_auto(os.path.join(self.tmp, "data2"), COMPARER_WORKERS="1")
        try:
            auto.start()
            job, _ = auto.enqueue(("a.txt", SRC), ("b.txt", TGT), {"engines": ["text"]})
            import time
            for _ in range(100):
                j = auto.store.get_job(job["id"])
                if j["status"] == "done":
                    break
                time.sleep(0.1)
            self.assertEqual(j["status"], "done")
            self.assertTrue(auto.status()["worker"]["running"])
        finally:
            auto.stop()

    def test_explicit_store_failure_is_loud(self):
        with self.assertRaises(ConfigError):
            make_auto(os.path.join(self.tmp, "data3"), store="nonexistent.module:Store")
        with self.assertRaises(ConfigError):
            make_auto(os.path.join(self.tmp, "data3"), store="plugins_demo:BrokenStore")

    def test_store_and_source_plugins_via_hooks(self):
        import plugins_demo
        plugins_demo.StaticSource.polls = 0
        auto = make_auto(os.path.join(self.tmp, "data4"), store="plugins_demo:MemoryStore", COMPARER_SOURCES="plugins_demo:StaticSource")
        try:
            self.assertEqual(auto.store.kind, "memory-demo"); self.assertEqual(auto.plugin_errors, [])
            self.assertEqual([s.kind for s in auto.sources], ["static-demo"])
            out = auto.poll_once(); self.assertEqual(out["created"], 1)
            done = auto.process_one(); self.assertEqual(done["status"], "done")
            run = auto.store.get_run(done["run_id"]); self.assertEqual(run["labels"], {"from": "plugin"}); self.assertEqual(run["batch"], "plugin-batch")
            self.assertEqual(auto.poll_once()["created"], 0)
        finally:
            auto.stop()

    def test_bad_source_plugin_reported_not_fatal(self):
        auto = make_auto(os.path.join(self.tmp, "data5"), COMPARER_SOURCES="nonexistent.mod:Source")
        try:
            self.assertTrue(auto.plugin_errors); self.assertEqual(auto.sources, [])
            self.assertIn("nonexistent.mod", auto.status()["plugin_errors"][0])
        finally:
            auto.stop()

    def test_config_file_and_env_override(self):
        cfg_path = os.path.join(self.tmp, "brand.json")
        with open(cfg_path, "w") as f:
            json.dump({"brand": {"name": "Acme Review", "accent": "#123456", "logo_url": "javascript:alert(1)", "tagline": "QA"},
                       "workers": 0, "store": "jsonfiles"}, f)
        cfg = build_config({"COMPARER_CONFIG": cfg_path, "COMPARER_DATA_DIR": os.path.join(self.tmp, "d6"), "COMPARER_BRAND_ACCENT": "#abcdef"})
        self.assertEqual(cfg["brand"]["name"], "Acme Review"); self.assertEqual(cfg["brand"]["accent"], "#abcdef")
        self.assertIsNone(cfg["brand"]["logo_url"]); self.assertEqual(cfg["brand"]["tagline"], "QA")
        self.assertEqual(cfg["store"], "jsonfiles"); self.assertTrue(cfg["store_explicit"])
        with open(cfg_path, "w") as f:
            f.write("not json")
        with self.assertRaises(Exception):
            build_config({"COMPARER_CONFIG": cfg_path})

    def test_export_has_provenance_hashes_and_ids(self):
        auto = make_auto(os.path.join(self.tmp, "data7"))
        try:
            job, _ = auto.enqueue(("a.txt", SRC), ("b.txt", TGT), {"engines": ["text"], "rules": [{"id": "r", "type": "ignore_category", "value": "text_extra"}]}, {})
            done = auto.process_one(); rid = done["run_id"]
            run = auto.store.get_run(rid)
            import hashlib
            self.assertEqual(run["source_sha256"], hashlib.sha256(SRC).hexdigest())
            self.assertEqual(run["provenance"]["rules"], 1); self.assertIsNone(run["provenance"]["vision"])
            auto.add_feedback(rid, {"verdict": "acceptable_difference", "finding_id": run["result"]["findings"][0]["id"]})
            row = list(auto.export_feedback())[0]
            self.assertTrue(row["feedback_id"].startswith("fb_")); self.assertEqual(row["verdict"], "acceptable_difference")
            self.assertEqual(row["provenance"]["target_sha256"], hashlib.sha256(TGT).hexdigest())
            self.assertEqual(row["provenance"]["options"]["rules"][0]["id"], "r")
            self.assertEqual(row["finding"]["id"], row["finding_id"])
        finally:
            auto.stop()

    def test_openai_compatible_without_key(self):
        from comparer.engines import vision_llm
        saved = {k: os.environ.pop(k) for k in list(os.environ) if k.startswith(("COMPARER_VISION", "GEMINI_", "OPENAI_", "ANTHROPIC_", "OLLAMA_"))}
        try:
            self.assertEqual(vision_llm.configured_providers(), [])
            os.environ["OPENAI_BASE_URL"] = "http://127.0.0.1:1234/v1"
            self.assertEqual(vision_llm.configured_providers(), ["openai"])
        finally:
            os.environ.pop("OPENAI_BASE_URL", None); os.environ.update(saved)


if __name__ == "__main__":
    unittest.main()


class PersistenceHazards(unittest.TestCase):
    """Regressions for the persistence review (bus, 16:42Z)."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp(); self.inbox = os.path.join(self.tmp, "inbox"); os.makedirs(self.inbox)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _auto(self, store="sqlite", **extra):
        return make_auto(os.path.join(self.tmp, "data-" + store), store, COMPARER_INBOX=self.inbox, **extra)

    def _put(self, rel, data):
        p = os.path.join(self.inbox, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "wb") as f:
            f.write(data)

    def test_manifest_ack_only_after_durable_enqueue(self):
        auto = self._auto()
        try:
            self._put("a.txt", SRC); self._put("b.txt", TGT)
            with open(os.path.join(self.inbox, "m.json"), "w") as f:
                json.dump({"pairs": [{"source": "a.txt", "target": "b.txt"}, {"source": "a.txt", "target": "missing.txt"}]}, f)
            out = auto.poll_once()
            self.assertEqual(out["created"], 0)                                   # nothing enqueued from a partially invalid manifest
            self.assertTrue(os.path.exists(os.path.join(self.inbox, "m.json.failed")))
            self.assertEqual(auto.store.job_counts(), {})
            # store failure during enqueue keeps the manifest visible as failed
            self._put("m2.json", json.dumps({"pairs": [{"source": "a.txt", "target": "b.txt"}]}).encode())
            from unittest import mock
            with mock.patch.object(auto.store, "create_job", side_effect=RuntimeError("disk full")):
                out = auto.poll_once()
            self.assertEqual(out["created"], 0)
            self.assertTrue(os.path.exists(os.path.join(self.inbox, "m2.json.failed")))
            with open(os.path.join(self.inbox, "m2.json.error.txt")) as f:
                self.assertIn("disk full", f.read())
            # retry after the store recovers: rename back and poll again -> enqueued, acknowledged
            os.replace(os.path.join(self.inbox, "m2.json.failed"), os.path.join(self.inbox, "m2.json"))
            out = auto.poll_once()
            self.assertEqual(out["created"], 1)
            self.assertTrue(os.path.exists(os.path.join(self.inbox, "m2.json.done")))
        finally:
            auto.stop()

    def test_symlinked_directory_rejected_and_caps(self):
        auto = self._auto()
        try:
            outside = os.path.join(self.tmp, "outside"); os.makedirs(outside)
            with open(os.path.join(outside, "x.txt"), "wb") as f:
                f.write(SRC)
            os.symlink(outside, os.path.join(self.inbox, "linkdir"))
            with self.assertRaises(ConfigError):
                auto.sources[0].resolve("linkdir/x.txt")
            self._put("a.txt", SRC)
            with open(os.path.join(self.inbox, "big.json"), "w") as f:
                json.dump({"pairs": [{"source": "a.txt", "target": "a.txt"}] * 500}, f)
            auto.poll_once()
            with open(os.path.join(self.inbox, "big.json.error.txt")) as f:
                self.assertIn("cap", f.read())
        finally:
            auto.stop()

    def test_stored_result_urls_point_at_run_not_scratch(self):
        if not HAS_PIL_IMAGES():
            self.skipTest("Pillow")
        auto = self._auto()
        try:
            src = fixtures.png_bytes(fixtures.render_card(fixtures.SOURCE_LINES))
            tgt = fixtures.png_bytes(fixtures.render_card(fixtures.TARGET_LINES, badge=False))
            job, _ = auto.enqueue(("a.png", src), ("b.png", tgt), {"engines": ["pixel"]})
            done = auto.process_one(); run = auto.store.get_run(done["run_id"])
            urls = [p["image_url"] for s in ("source", "target") for p in run["result"][s]["pages"]] + \
                   [o["image_url"] for s in ("source", "target") for o in run["result"]["overlays"][s]]
            self.assertTrue(urls)
            self.assertTrue(all(u.startswith(f"/api/runs/{run['id']}/artifacts/") for u in urls), urls)
            self.assertTrue(os.path.isfile(auto.run_artifact_path(run["id"], "target-0-annotated.png")))
            self.assertTrue(os.path.isfile(auto.run_artifact_path(run["id"], "result.json")))
            # scratch artifacts can vanish; history is self-contained
            shutil.rmtree(os.path.join(automation.pipeline.ARTIFACT_DIR, run["result"]["id"]), ignore_errors=True)
            self.assertTrue(os.path.isfile(auto.run_artifact_path(run["id"], "target-0.png")))
        finally:
            auto.stop()

    def test_run_id_assigned_only_after_save(self):
        auto = self._auto()
        try:
            from unittest import mock
            d = {"id": "cmp_20260917T000000_0000000000000000", "created_at": "2026-09-17T00:00:00Z",
                 "source": {"name": "a.txt", "kind": "txt", "pages": []}, "target": {"name": "b.txt", "kind": "txt", "pages": []},
                 "engines": [], "verdict": {"status": "match"}, "findings": [], "overlays": {"source": [], "target": []}, "stats": {}}
            with mock.patch.object(auto.store, "save_run", side_effect=RuntimeError("db locked")):
                with self.assertRaises(RuntimeError):
                    auto.record_run(d, {})
            self.assertNotIn("run_id", d)
        finally:
            auto.stop()

    def _concurrent(self, store):
        auto = self._auto(store)
        try:
            results = []
            def go():
                results.append(auto.enqueue(("a.txt", SRC), ("b.txt", TGT), {"engines": ["text"]}, {}, "same-key"))
            threads = [threading.Thread(target=go) for _ in range(16)]
            [t.start() for t in threads]; [t.join() for t in threads]
            self.assertEqual(len(results), 16)
            self.assertEqual(sum(1 for _, created in results if created), 1)
            self.assertEqual(len({j["id"] for j, _ in results}), 1)
            self.assertEqual(auto.store.job_counts(), {"queued": 1})
            # cancel vs claim race: whichever wins, the job ends in exactly one terminal state
            job = results[0][0]
            outcomes = []
            def cancel():
                outcomes.append(("cancel", auto.cancel(job["id"])["status"]))
            def claim():
                c = auto.store.claim_next_job("w"); outcomes.append(("claim", c["status"] if c else None))
            t1, t2 = threading.Thread(target=cancel), threading.Thread(target=claim)
            t1.start(); t2.start(); t1.join(); t2.join()
            final = auto.store.get_job(job["id"])["status"]
            self.assertIn(final, ("cancelled", "running"))
            if final == "cancelled":
                self.assertIn(("claim", None), outcomes)
        finally:
            auto.stop()

    def test_concurrent_enqueue_and_cancel_sqlite(self):
        self._concurrent("sqlite")

    def test_concurrent_enqueue_and_cancel_jsonfiles(self):
        self._concurrent("jsonfiles")

    def test_direct_duplicate_key_in_store_is_valueerror(self):
        for store in ("sqlite", "jsonfiles"):
            auto = self._auto(store)
            try:
                job, _ = auto.enqueue(("a.txt", SRC), ("b.txt", TGT), {}, {}, "k")
                dup = dict(job, id="job_20260917T000000_ffffffffffffffff")
                with self.assertRaises(ValueError):
                    auto.store.create_job(dup)
            finally:
                auto.stop()

    def test_job_completion_is_idempotent_after_crash(self):
        auto = self._auto()
        try:
            job, _ = auto.enqueue(("a.txt", SRC), ("b.txt", TGT), {"engines": ["text"]})
            claimed = auto.store.claim_next_job("w1")
            from unittest import mock
            # crash right after save_run: update_job never runs
            real_update = auto.store.update_job
            calls = {"n": 0}
            def flaky(job_id, **fields):
                if fields.get("status") == "done" and calls["n"] == 0:
                    calls["n"] += 1
                    raise RuntimeError("process died")
                return real_update(job_id, **fields)
            with mock.patch.object(auto.store, "update_job", side_effect=flaky):
                j = auto.run_job(claimed)
            self.assertEqual(j["status"], "queued")                  # failure after save -> retry, not a lost job
            self.assertEqual(auto.store.count_runs(), 1)
            done = auto.process_one()
            self.assertEqual(done["status"], "done"); self.assertEqual(done["run_id"], Automation.run_id_for_job(job["id"]))
            self.assertEqual(auto.store.count_runs(), 1)          # no duplicate run
            self.assertIn("previous attempt", done["error"])
        finally:
            auto.stop()

    def test_ids_have_entropy_and_regex_accepts_both(self):
        self.assertEqual(len(automation.new_id("job").split("_")[-1]), 16)
        for rx in (server.RUN_RE, server.JOB_RE, server.ID_RE):
            pfx = rx.pattern[1:4]
            self.assertTrue(rx.match(f"{pfx}_20260917T000000_abcd"))
            self.assertTrue(rx.match(f"{pfx}_20260917T000000_" + "a" * 16))
            self.assertFalse(rx.match(f"{pfx}_20260917T000000_abcde"))
            self.assertFalse(rx.match(f"{pfx}_20260917T000000_../x"))

    def test_feedback_validation(self):
        auto = self._auto()
        try:
            auto.enqueue(("a.txt", SRC), ("b.txt", TGT), {"engines": ["text"]}); rid = auto.process_one()["run_id"]
            for bad in ({"verdict": "correct", "expected_severity": "urgent"}, {"verdict": "correct", "expected_category": "nope"},
                        {"verdict": "correct", "comment": ["x"]}):
                with self.assertRaises(ConfigError, msg=bad):
                    auto.add_feedback(rid, bad)
            fb = auto.add_feedback(rid, {"verdict": "wrong_severity", "expected_severity": "low", "comment": "x" * 5000})
            self.assertEqual(len(fb["comment"]), 4000)
        finally:
            auto.stop()


def HAS_PIL_IMAGES():
    from comparer import deps
    return deps.pillow() is not None


class HttpValidation(HttpBase):
    def test_bad_query_and_bodies_are_400(self):
        auth = {"Authorization": "Bearer s3cret"}
        self.assertEqual(self.call("GET", "/api/runs?limit=abc")[0], 400)
        self.assertEqual(self.call("GET", "/api/jobs?limit=-1")[0], 400)
        good = {"source": {"name": "a.txt", "content_base64": self.b64(SRC)}, "target": {"name": "b.txt", "content_base64": self.b64(TGT)}}
        self.assertEqual(self.call("POST", "/api/jobs", {**good, "options": []}, auth)[0], 400)
        self.assertEqual(self.call("POST", "/api/jobs", {**good, "labels": {"a": {"nested": 1}}}, auth)[0], 400)
        self.assertEqual(self.call("POST", "/api/jobs", {**good, "idempotency_key": {"x": 1}}, auth)[0], 400)
        self.assertEqual(self.call("POST", "/api/jobs", [], auth)[0], 400)
        code, out = self.call("POST", "/api/jobs", good, auth)
        self.assertEqual(code, 202)
        self.assertEqual(self.call("POST", f"/api/jobs/{out['job']['id']}/cancel", b"")[0], 401)   # token on cancel
        self.assertEqual(self.call("POST", f"/api/jobs/{out['job']['id']}/cancel", b"", auth)[1]["status"], "cancelled")
        code, h = self.call("GET", "/api/health")
        self.assertEqual(h["store"]["kind"], "sqlite"); self.assertTrue(h["store"]["ok"])


class Cleanup(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(); self.inbox = os.path.join(self.tmp, "inbox"); os.makedirs(self.inbox)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _auto(self, store="sqlite", **extra):
        return make_auto(os.path.join(self.tmp, "data-" + store), store, COMPARER_INBOX=self.inbox, **extra)

    def _run(self, auto, key=None):
        job, _ = auto.enqueue(("a.txt", SRC), ("b.txt", TGT), {"engines": ["text"]}, {}, key)
        return auto.process_one(), job

    def test_scratch_and_job_inputs_removed_after_run(self):
        auto = self._auto()
        try:
            done, job = self._run(auto)
            run = auto.store.get_run(done["run_id"])
            self.assertFalse(os.path.exists(os.path.join(automation.pipeline.ARTIFACT_DIR, run["result"]["id"])))   # scratch gone
            self.assertFalse(os.path.exists(os.path.join(auto.cfg["data_dir"], "jobs", job["id"])))                  # inputs gone
            self.assertTrue(os.path.isfile(auto.run_artifact_path(run["id"], "source-original.txt")))                 # run keeps originals
        finally:
            auto.stop()

    def _cleanup_cases(self, store):
        auto = self._auto(store, COMPARER_MAX_RUNS="2", COMPARER_JOB_RETENTION_DAYS="0.0000001", COMPARER_INBOX_TTL_DAYS="0.0000001")
        try:
            ids = [self._run(auto, f"k{i}")[0]["run_id"] for i in range(4)]
            rid = ids[-1]
            auto.add_feedback(ids[0], {"verdict": "correct"})
            # orphans: run folder without record, job folder without job, stale scratch, old manifests
            for sub in ("runs/run_20200101T000000_deadbeefdeadbeef", "jobs/job_20200101T000000_deadbeefdeadbeef"):
                d = os.path.join(auto.cfg["data_dir"], sub); os.makedirs(d); os.utime(d, (0, 0))   # past the orphan grace period
            stale = os.path.join(automation.pipeline.ARTIFACT_DIR, "cmp_20200101T000000_deadbeefdeadbeef"); os.makedirs(stale, exist_ok=True)
            os.utime(stale, (0, 0))
            for fn in ("old.json.done", "old.json.failed", "old.json.error.txt", "live.json"):
                with open(os.path.join(self.inbox, fn), "w") as f:
                    f.write("{}")
                os.utime(os.path.join(self.inbox, fn), (0, 0))
            import time; time.sleep(0.05)
            dry = auto.cleanup(dry_run=True)
            self.assertEqual(sorted(dry["runs_pruned"]), sorted(ids[:2]))
            self.assertEqual(auto.store.count_runs(), 4)                       # dry run changes nothing
            rep = auto.cleanup()
            self.assertEqual(sorted(rep["runs_pruned"]), sorted(ids[:2]))
            self.assertEqual(auto.store.count_runs(), 2)
            self.assertIsNotNone(auto.store.get_run(rid))
            self.assertFalse(os.path.exists(os.path.join(auto.cfg["data_dir"], "runs", ids[0])))
            self.assertEqual(len(list(auto.store.iter_feedback())), 1)          # feedback kept for training export
            self.assertEqual(len(rep["jobs_pruned"]), 4)                        # terminal jobs past retention
            self.assertEqual(auto.store.job_counts(), {})
            self.assertGreaterEqual(rep["job_inputs_removed"], 1); self.assertEqual(rep["orphans_removed"], 1)
            self.assertGreaterEqual(rep["scratch_removed"], 1); self.assertFalse(os.path.exists(stale))
            self.assertEqual(rep["inbox_manifests_removed"], 3)
            self.assertTrue(os.path.exists(os.path.join(self.inbox, "live.json")))   # unprocessed manifests untouched
            self.assertIn("data_dir_mb", rep)
            self.assertEqual(auto.status()["cleanup"]["last"]["runs_pruned"], rep["runs_pruned"])
        finally:
            auto.stop()

    def test_cleanup_sqlite(self):
        self._cleanup_cases("sqlite")

    def test_cleanup_jsonfiles(self):
        self._cleanup_cases("jsonfiles")

    def test_size_budget_prunes_oldest(self):
        auto = self._auto(COMPARER_MAX_DATA_MB="1", COMPARER_MAX_RUNS="0", COMPARER_RETENTION_DAYS="0")
        try:
            ids = [self._run(auto, f"k{i}")[0]["run_id"] for i in range(3)]
            with open(os.path.join(auto.cfg["data_dir"], "runs", ids[1], "big.bin"), "wb") as f:
                f.write(b"\\0" * (1024 * 1024 + 10))     # over budget on its own
            rep = auto.cleanup()
            self.assertIn(ids[0], rep["runs_pruned"]); self.assertIn(ids[1], rep["runs_pruned"])   # oldest first until under budget
            self.assertNotIn(ids[2], rep["runs_pruned"])
        finally:
            auto.stop()

    def test_disabled_rules_keep_everything(self):
        auto = self._auto(COMPARER_MAX_RUNS="0", COMPARER_RETENTION_DAYS="0", COMPARER_MAX_DATA_MB="0", COMPARER_JOB_RETENTION_DAYS="0")
        try:
            for i in range(3):
                self._run(auto, f"k{i}")
            rep = auto.cleanup()
            self.assertEqual(rep["runs_pruned"], []); self.assertEqual(rep["jobs_pruned"], []); self.assertEqual(auto.store.count_runs(), 3)
        finally:
            auto.stop()


class CleanupRoute(HttpBase):
    def test_cleanup_endpoint_token_and_dry_run(self):
        self.assertEqual(self.call("POST", "/api/automation/cleanup", b"")[0], 401)
        code, rep = self.call("POST", "/api/automation/cleanup?dry_run=1", b"", {"Authorization": "Bearer s3cret"})
        self.assertEqual(code, 200); self.assertTrue(rep["dry_run"])
        code, st = self.call("GET", "/api/automation")
        self.assertIn("policy", st["cleanup"]); self.assertEqual(st["cleanup"]["policy"]["max_runs"], 500)


class ProviderPlugin(unittest.TestCase):
    def setUp(self):
        from comparer.engines import vision_llm
        self.vl = vision_llm
        self.saved = {k: os.environ.pop(k) for k in list(os.environ) if k.startswith(("COMPARER_VISION", "COMPARER_PROVIDER", "GEMINI_", "OPENAI_", "ANTHROPIC_", "OLLAMA_"))}
        self._reset()

    def _reset(self):
        for k in list(self.vl.PROVIDERS):
            if k not in ("gemini", "openai", "anthropic", "ollama"):
                del self.vl.PROVIDERS[k]
        self.vl.PLUGIN_ERRORS.clear(); self.vl._PLUGINS_LOADED = False

    def tearDown(self):
        for k in list(os.environ):
            if k.startswith(("COMPARER_VISION", "COMPARER_PROVIDER")):
                os.environ.pop(k)
        os.environ.update(self.saved); self._reset()

    def test_plugin_provider_is_used_for_both_passes(self):
        import plugins_demo
        plugins_demo.echo_provider.calls.clear()
        os.environ["COMPARER_PROVIDER_PLUGIN"] = "acme=plugins_demo:echo_provider"
        self.assertEqual(self.vl.configured_providers(), ["acme"])
        r = pipeline_compare(SRC, TGT, {"engines": ["text", "vision_llm"], "vision": {"provider": "acme", "model": "acme-v1"}, "rule_guidance": "be lenient"})
        v = next(e for e in r["engines"] if e["name"] == "vision_llm")
        self.assertEqual((v["status"], v["backend"], v["version"]), ("ok", "acme", "acme-v1"))
        self.assertTrue(any(f["message"] == "plugin saw both sides" for f in r["findings"]))
        self.assertEqual(len(plugins_demo.echo_provider.calls), 2)        # base pass + guidance pass
        self.assertEqual(r["rules_report"]["guidance"]["status"], "unevaluated")   # empty decisions
        # public config lists it without secrets
        auto = make_auto(tempfile.mkdtemp())
        try:
            cfg = auto.public_config()
            self.assertEqual(cfg["vision"]["provider_plugins"], ["acme"]); self.assertIn("acme", cfg["vision"]["providers_configured"])
        finally:
            auto.stop()

    def test_bad_plugin_spec_reported(self):
        os.environ["COMPARER_PROVIDER_PLUGIN"] = "nope,acme=missing.mod:fn,bad name=plugins_demo:echo_provider"
        self.assertEqual(self.vl.configured_providers(), [])
        self.assertEqual(len(self.vl.PLUGIN_ERRORS), 3)
        auto = make_auto(tempfile.mkdtemp())
        try:
            self.assertTrue(any("provider plugin" in e for e in auto.status()["plugin_errors"]))
        finally:
            auto.stop()


def pipeline_compare(sb, tb, options):
    from comparer import pipeline
    return pipeline.compare("a.txt", sb, "b.txt", tb, options, artifact_dir=tempfile.mkdtemp()).to_dict()


class CleanupRaces(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_cleanup_skips_fresh_and_active_folders(self):
        auto = make_auto(self.tmp)
        try:
            runs_dir = os.path.join(auto.cfg["data_dir"], "runs"); jobs_dir = os.path.join(auto.cfg["data_dir"], "jobs")
            fresh_run = os.path.join(runs_dir, "run_20260917T000000_aaaaaaaaaaaaaaaa"); os.makedirs(fresh_run)
            fresh_job = os.path.join(jobs_dir, "job_20260917T000000_bbbbbbbbbbbbbbbb"); os.makedirs(fresh_job)
            old_run = os.path.join(runs_dir, "run_20200101T000000_cccccccccccccccc"); os.makedirs(old_run); os.utime(old_run, (0, 0))
            rep = auto.cleanup()
            self.assertTrue(os.path.isdir(fresh_run)); self.assertTrue(os.path.isdir(fresh_job))   # inside grace: untouched
            self.assertFalse(os.path.isdir(old_run)); self.assertEqual(rep["orphans_removed"], 1)
            # an active run id is never pruned even when retention says so
            job, _ = auto.enqueue(("a.txt", SRC), ("b.txt", TGT), {"engines": ["text"]})
            done = auto.process_one(); rid = done["run_id"]
            auto.cfg["max_runs"] = 0; auto.cfg["retention_days"] = 100000   # everything is "too old"? no: retention_days prunes < now-100000d -> nothing
            auto.cfg["retention_days"] = 0.0000001
            with auto._active_lock:
                auto._active.add(rid)
            import time; time.sleep(0.02)
            rep = auto.cleanup()
            self.assertNotIn(rid, rep["runs_pruned"])
            with auto._active_lock:
                auto._active.discard(rid)
            rep = auto.cleanup()
            self.assertIn(rid, rep["runs_pruned"])
        finally:
            auto.stop()

    def test_record_run_store_failure_leaves_no_folder(self):
        auto = make_auto(self.tmp)
        try:
            from unittest import mock
            d = {"id": "cmp_20260917T000000_dddddddddddddddd", "created_at": "2026-09-17T00:00:00Z",
                 "source": {"name": "a.txt", "kind": "txt", "pages": []}, "target": {"name": "b.txt", "kind": "txt", "pages": []},
                 "engines": [], "verdict": {"status": "match"}, "findings": [], "overlays": {"source": [], "target": []}, "stats": {}}
            with mock.patch.object(auto.store, "save_run", side_effect=RuntimeError("db locked")):
                with self.assertRaises(RuntimeError):
                    auto.record_run(d, {}, source_bytes=b"x", target_bytes=b"y")
            self.assertFalse(os.path.isdir(os.path.join(auto.cfg["data_dir"], "runs", "run_20260917T000000_dddddddddddddddd")))
            self.assertEqual(auto._active, set())
        finally:
            auto.stop()

    def test_inbox_read_is_bounded(self):
        inbox = os.path.join(self.tmp, "inbox"); os.makedirs(inbox)
        auto = make_auto(os.path.join(self.tmp, "d"), COMPARER_INBOX=inbox)
        try:
            from unittest import mock
            with open(os.path.join(inbox, "big.bin"), "wb") as f:
                f.write(b"x" * 100)
            with mock.patch.object(automation, "INPUT_LIMIT", 50):
                with self.assertRaises(ConfigError):
                    auto.sources[0].read("big.bin")
        finally:
            auto.stop()


class StrictPinAndGuards(unittest.TestCase):
    def test_wrong_pin_with_cloud_key_present_disables_vision(self):
        from comparer.engines import vision_llm
        saved = {k: os.environ.pop(k) for k in list(os.environ) if k.startswith(("COMPARER_VISION", "COMPARER_PROVIDER", "GEMINI_", "OPENAI_", "ANTHROPIC_", "OLLAMA_"))}
        try:
            os.environ["GEMINI_API_KEY"] = "k"; os.environ["COMPARER_VISION_PROVIDER"] = "acme-internal"
            self.assertEqual(vision_llm.configured_providers(), [])
            self.assertIn("not a configured provider", vision_llm.pin_error())
            self.assertEqual(vision_llm.availability()[0], "unavailable")
            r = pipeline_compare(SRC, TGT, {"engines": ["vision_llm"], "vision": {"model": "m"}})
            v = next(e for e in r["engines"] if e["name"] == "vision_llm")
            self.assertEqual(v["status"], "skipped"); self.assertIn("acme-internal", v["message"])
            self.assertEqual(r["verdict"]["status"], "inconclusive")
            auto = make_auto(tempfile.mkdtemp())
            try:
                cfg = auto.public_config()["vision"]
                self.assertEqual(cfg["pinned"], "acme-internal"); self.assertIn("not a configured", cfg["error"]); self.assertEqual(cfg["providers_configured"], [])
            finally:
                auto.stop()
            os.environ["COMPARER_VISION_PROVIDER"] = "gemini"
            self.assertEqual(vision_llm.configured_providers(), ["gemini"]); self.assertIsNone(vision_llm.pin_error())
        finally:
            for k in list(os.environ):
                if k.startswith(("COMPARER_VISION", "GEMINI_")): os.environ.pop(k)
            os.environ.update(saved)

    def test_cleanup_only_touches_id_shaped_dirs(self):
        tmp = tempfile.mkdtemp()
        auto = make_auto(tmp)
        try:
            runs_dir = os.path.join(auto.cfg["data_dir"], "runs"); os.makedirs(runs_dir, exist_ok=True)
            keep = os.path.join(runs_dir, "customer-exports"); os.makedirs(keep); os.utime(keep, (0, 0))
            scratch_keep = os.path.join(automation.pipeline.ARTIFACT_DIR, "notes"); os.makedirs(scratch_keep, exist_ok=True); os.utime(scratch_keep, (0, 0))
            rep = auto.cleanup()
            self.assertTrue(os.path.isdir(keep)); self.assertTrue(os.path.isdir(scratch_keep))
            self.assertEqual(rep["orphans_removed"], 0)
        finally:
            auto.stop(); shutil.rmtree(tmp, ignore_errors=True); shutil.rmtree(scratch_keep, ignore_errors=True)

    def test_server_lock_blocks_cli_cleanup(self):
        tmp = tempfile.mkdtemp()
        auto = make_auto(tmp)
        try:
            auto.start()
            self.assertTrue(os.path.isfile(auto.lock_path()))
            other = make_auto(tmp)
            self.assertIsNone(auto.lock_holder())                      # a process never blocks itself
            # simulate a second process: holder pid is this (alive) process but a different Automation instance
            from unittest import mock
            with mock.patch("os.getpid", return_value=999999):
                self.assertIsNotNone(other.lock_holder())
            from comparer.__main__ import main
            import io, contextlib
            buf = io.StringIO()
            env = {"COMPARER_DATA_DIR": tmp, "COMPARER_WORKERS": "0"}
            with mock.patch.dict(os.environ, env), mock.patch("os.getpid", return_value=999999), contextlib.redirect_stdout(buf):
                code = main(["cleanup"])
            self.assertEqual(code, 2); self.assertIn("owns this data dir", buf.getvalue())
            buf = io.StringIO()
            with mock.patch.dict(os.environ, env), mock.patch("os.getpid", return_value=999999), contextlib.redirect_stdout(buf):
                self.assertEqual(main(["cleanup", "--dry-run"]), 0)   # dry run is always allowed
            other.stop()
            auto.stop()
            self.assertFalse(os.path.isfile(auto.lock_path()))            # released on stop
            # stale lock (dead pid) does not block
            with open(os.path.join(tmp, automation.LOCK_NAME), "w") as f:
                json.dump({"pid": 2**22 + 12345, "started_at": "x"}, f)
            self.assertIsNone(make_auto(tmp).lock_holder())
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
