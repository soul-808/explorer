import json
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from comparer import deps, loaders, pipeline  # noqa: E402
from comparer.engines import ocr, textnorm  # noqa: E402
import fixtures  # noqa: E402

HAS_PIL = deps.pillow() is not None
HAS_OCR = ocr.availability()[0] == "ok"
TMP = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".tmp-artifacts")


def run(sname, sbytes, tname, tbytes, **opts):
    return pipeline.compare(sname, sbytes, tname, tbytes, opts, artifact_dir=TMP).to_dict()


class TextNorm(unittest.TestCase):
    def test_curly_quotes_and_case_are_equivalent(self):
        self.assertEqual(textnorm.normalize("It’s “Great”"), "it's \"great\"")

    def test_similarity(self):
        self.assertEqual(textnorm.similarity("a b c", "a b c"), 1.0)
        self.assertLess(textnorm.similarity("save 20%", "save 25%"), 1.0)


class Loaders(unittest.TestCase):
    def test_detect_kind(self):
        self.assertEqual(loaders.detect_kind("x.png", b"\x89PNG\r\n"), "image")
        self.assertEqual(loaders.detect_kind("x.pdf", b"%PDF-1.4"), "pdf")
        self.assertEqual(loaders.detect_kind("deck.docx", fixtures.docx_bytes(["hi"])), "docx")
        self.assertEqual(loaders.detect_kind("copy.txt", b"hello"), "txt")

    def test_docx_text(self):
        doc = loaders.load("deck.docx", fixtures.docx_bytes(fixtures.SOURCE_LINES))
        self.assertEqual(doc.kind, "docx")
        self.assertIn("Save 20% on all plans", doc.full_text())

    def test_image_header_dims_without_pillow(self):
        png = b"\x89PNG\r\n\x1a\n" + b"\x00\x00\x00\rIHDR" + (640).to_bytes(4, "big") + (480).to_bytes(4, "big")
        self.assertEqual(loaders._image_dims(png)[:2], (640, 480))


class TextVsText(unittest.TestCase):
    def test_docx_vs_txt_flags_changes(self):
        tgt = "\n".join(fixtures.TARGET_LINES)
        r = run("deck.docx", fixtures.docx_bytes(fixtures.SOURCE_LINES), "copy.txt", tgt.encode())
        self.assertEqual(r["verdict"]["status"], "mismatch")
        cats = {f["category"] for f in r["findings"]}
        self.assertIn("text_changed", cats)
        self.assertIn("text_missing", cats)
        msgs = " ".join(f["message"] for f in r["findings"])
        self.assertIn("20%", msgs); self.assertIn("25%", msgs)
        text_engine = next(e for e in r["engines"] if e["name"] == "text")
        self.assertEqual(text_engine["status"], "ok")

    def test_identical_text_matches(self):
        t = "\n".join(fixtures.SOURCE_LINES).encode()
        r = run("a.txt", t, "b.txt", t)
        self.assertEqual(r["verdict"]["status"], "match")
        self.assertEqual(r["findings"], [])
        self.assertEqual(r["stats"]["text_similarity"], 1.0)

    def test_pixel_skipped_for_text_only(self):
        t = b"hello"
        r = run("a.txt", t, "b.txt", t)
        px = next(e for e in r["engines"] if e["name"] == "pixel")
        self.assertIn(px["status"], ("skipped", "unavailable"))

    def test_nothing_ran_is_inconclusive_not_match(self):
        t = b"hello"
        r = run("a.txt", t, "b.txt", t, engines=["ssim"])  # ssim can't run on text
        self.assertEqual(r["verdict"]["status"], "inconclusive")
        self.assertEqual(r["verdict"]["confidence"], 0.0)


@unittest.skipUnless(HAS_PIL, "Pillow not installed")
class ImageVsImage(unittest.TestCase):
    def setUp(self):
        self.src = fixtures.png_bytes(fixtures.render_card(fixtures.SOURCE_LINES))
        self.tgt = fixtures.png_bytes(fixtures.render_card(fixtures.TARGET_LINES, badge=False))

    def test_pixel_regions_and_overlays(self):
        r = run("design.png", self.src, "app.png", self.tgt, engines=["pixel"])
        self.assertEqual(r["verdict"]["status"], "mismatch")
        vis = [f for f in r["findings"] if f["category"] == "visual_diff"]
        self.assertGreaterEqual(len(vis), 2)  # badge removed + text lines changed
        for f in vis:
            x, y, w, h = f["target"]["bbox"]
            self.assertTrue(0 <= x <= 1 and 0 <= y <= 1 and 0 < w <= 1 and 0 < h <= 1)
        self.assertTrue(r["overlays"]["target"])
        path = os.path.join(TMP, "target-0-annotated.png")
        self.assertTrue(os.path.isfile(path))
        self.assertGreater(r["stats"]["pixel_diff_ratio"], 0)

    def test_identical_images_match(self):
        r = run("a.png", self.src, "b.png", self.src, engines=["pixel"])
        self.assertEqual(r["verdict"]["status"], "match")
        self.assertEqual([f for f in r["findings"] if f["category"] == "visual_diff"], [])

    def test_size_mismatch_flags_layout(self):
        from PIL import Image
        import io
        im = Image.open(io.BytesIO(self.src)).resize((900, 300))
        buf = io.BytesIO(); im.save(buf, format="PNG")
        r = run("a.png", self.src, "b.png", buf.getvalue(), engines=["pixel"])
        self.assertIn("layout_shift", {f["category"] for f in r["findings"]})

    @unittest.skipUnless(HAS_OCR, "no OCR backend")
    def test_ocr_text_diff_with_boxes(self):
        r = run("design.png", self.src, "app.png", self.tgt, engines=["ocr", "text"])
        self.assertEqual(r["verdict"]["status"], "mismatch")
        changed = [f for f in r["findings"] if f["category"] in ("text_changed", "text_missing")]
        self.assertTrue(changed)
        self.assertTrue(any("25" in f["message"] for f in changed), [f["message"] for f in changed])
        self.assertTrue(any(f["target"] and f["target"]["bbox"] for f in changed))

    @unittest.skipUnless(HAS_OCR, "no OCR backend")
    def test_docx_vs_screenshot(self):
        r = run("deck.docx", fixtures.docx_bytes(fixtures.SOURCE_LINES), "app.png", self.tgt, engines=["ocr", "text"])
        self.assertEqual(r["verdict"]["status"], "mismatch")
        f = next(f for f in r["findings"] if "25" in f["message"])
        self.assertIsNone(f["source"]["bbox"])          # docx has no geometry
        self.assertIsNotNone(f["target"]["bbox"])       # box lands on the screenshot


@unittest.skipUnless(deps.module("pypdfium2") or deps.module("pypdf") or deps.binary("pdftotext"), "no PDF backend")
class PdfSide(unittest.TestCase):
    def test_pdf_text_extracted(self):
        doc = loaders.load("approved.pdf", fixtures.pdf_bytes(fixtures.SOURCE_LINES))
        self.assertIn("Save 20%", doc.full_text())
        if deps.module("pypdfium2"):
            self.assertTrue(doc.pages[0].words, "pypdfium2 should yield word boxes")

    def test_pdf_vs_txt(self):
        r = run("approved.pdf", fixtures.pdf_bytes(fixtures.SOURCE_LINES), "copy.txt", "\n".join(fixtures.TARGET_LINES).encode())
        self.assertEqual(r["verdict"]["status"], "mismatch")


class Server(unittest.TestCase):
    def test_json_roundtrip_and_multipart(self):
        import base64, threading, urllib.request
        from http.server import ThreadingHTTPServer
        from comparer.server import Handler
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        port = httpd.server_address[1]
        th = threading.Thread(target=httpd.serve_forever, daemon=True); th.start()
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health") as r:
                h = json.loads(r.read())
            self.assertEqual(h["status"], "ok")
            self.assertTrue(any(e["name"] == "text" for e in h["engines"]))
            body = json.dumps({"source": {"name": "a.txt", "content_base64": base64.b64encode(b"Save 20%").decode()},
                               "target": {"name": "b.txt", "content_base64": base64.b64encode(b"Save 25%").decode()},
                               "options": {"render_overlays": False}}).encode()
            req = urllib.request.Request(f"http://127.0.0.1:{port}/api/compare", data=body, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req) as r:
                out = json.loads(r.read())
            self.assertEqual(out["verdict"]["status"], "mismatch")
            # multipart
            boundary = "----cmpboundary"
            def part(name, filename, data):
                return (f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"; filename=\"{filename}\"\r\n"
                        f"Content-Type: application/octet-stream\r\n\r\n").encode() + data + b"\r\n"
            mp = part("source", "a.txt", b"hello world") + part("target", "b.txt", b"hello world") + \
                 f"--{boundary}\r\nContent-Disposition: form-data; name=\"options\"\r\n\r\n".encode() + b'{"render_overlays": false}\r\n' + f"--{boundary}--\r\n".encode()
            req = urllib.request.Request(f"http://127.0.0.1:{port}/api/compare", data=mp,
                                         headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
            with urllib.request.urlopen(req) as r:
                out = json.loads(r.read())
            self.assertEqual(out["verdict"]["status"], "match")
            # bad body
            req = urllib.request.Request(f"http://127.0.0.1:{port}/api/compare", data=b"{}", headers={"Content-Type": "application/json"})
            with self.assertRaises(urllib.error.HTTPError) as cm:
                urllib.request.urlopen(req)
            self.assertEqual(cm.exception.code, 400)
        finally:
            httpd.shutdown(); httpd.server_close()


if __name__ == "__main__":
    unittest.main()
