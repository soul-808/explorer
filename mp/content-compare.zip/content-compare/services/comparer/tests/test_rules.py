"""SME rules stage."""
import json
import os
import sys
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from comparer import deps, pipeline, rules  # noqa: E402
from comparer.engines import ocr, vision_llm  # noqa: E402
import fixtures  # noqa: E402

TMP = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".tmp-artifacts")
BASE_REPLY = json.dumps({"summary": "ok", "match": False, "findings": []})
SRC = "\n".join(fixtures.SOURCE_LINES).encode()
TGT = "\n".join(fixtures.TARGET_LINES).encode()


def run(sb, tb, **opts):
    return pipeline.compare("a.txt", sb, "b.txt", tb, opts, artifact_dir=TMP).to_dict()


class Contract(unittest.TestCase):
    def test_no_rules_leaves_everything_flagged_and_base_equal(self):
        r = run(SRC, TGT)
        self.assertEqual(r["base_verdict"]["status"], "mismatch")
        self.assertEqual(r["verdict"]["status"], "mismatch")
        self.assertFalse(r["verdict"]["after_rules"])
        self.assertEqual([f["message"] for f in r["findings"]], [f["message"] for f in r["base_findings"]])
        self.assertTrue(all(f["disposition"] == "flagged" for f in r["findings"]))
        self.assertEqual(r["rules_report"]["guidance"]["status"], "not_provided")

    def test_allowed_change_ignores_but_keeps_evidence(self):
        r = run(SRC, TGT, rules=[{"id": "r1", "name": "price bump ok", "type": "allowed_change", "from": "20%", "to": "25%"}])
        changed = next(f for f in r["findings"] if f["category"] == "text_changed")
        self.assertEqual(changed["disposition"], "ignored")
        self.assertEqual(changed["rule_matches"][0]["rule_id"], "r1")
        self.assertEqual(len(r["findings"]), len(r["base_findings"]))     # nothing deleted
        self.assertEqual(r["verdict"]["status"], "mismatch")               # disclaimer still missing
        self.assertTrue(r["verdict"]["after_rules"])
        self.assertEqual(r["rules_report"]["counts"]["ignored"], 1)

    def test_all_ignored_becomes_match(self):
        r = run(SRC, TGT, rules=[{"id": "a", "type": "allowed_change", "from": "20%", "to": "25%"},
                                 {"id": "b", "type": "ignore_category", "value": "text_missing"}])
        self.assertEqual(r["verdict"]["status"], "match")
        self.assertEqual(r["base_verdict"]["status"], "mismatch")
        self.assertEqual(r["rules_report"]["counts"]["flagged"], 0)

    def test_required_text_violation_added(self):
        r = run(SRC, TGT, rules=[{"id": "legal", "name": "T&C line", "type": "required_text",
                                  "value": "Terms and conditions apply", "compliance": True, "severity": "high"}])
        v = [f for f in r["findings"] if f["category"] == "rule_violation"]
        self.assertEqual(len(v), 1)
        self.assertTrue(v[0]["rule_matches"][0]["compliance"])
        self.assertEqual(r["rules_report"]["counts"]["added"], 1)
        self.assertEqual(r["rules_report"]["counts"]["compliance_flagged"], 1)
        row = next(x for x in r["rules_report"]["rules"] if x["rule_id"] == "legal")
        self.assertEqual(row["status"], "violated")

    def test_required_text_satisfied(self):
        r = run(SRC, SRC, rules=[{"id": "legal", "type": "required_text", "value": "terms and CONDITIONS apply"}])
        row = r["rules_report"]["rules"][0]
        self.assertEqual(row["status"], "satisfied")
        self.assertEqual(r["verdict"]["status"], "match")

    def test_forbidden_text_literal(self):
        r = run(SRC, TGT, rules=[{"id": "nofree", "type": "forbidden_text", "value": "25%", "side": "target", "severity": "medium"}])
        v = [f for f in r["findings"] if f["category"] == "rule_violation"]
        self.assertEqual(len(v), 1)
        self.assertIn("25%", v[0]["message"])
        self.assertEqual(v[0]["target"]["text"], "25%")

    def test_regex_disabled_by_default_and_opt_in(self):
        r = run(SRC, TGT, rules=[{"id": "rx", "type": "forbidden_text", "pattern": r"\b25%"}])
        self.assertEqual(r["rules_report"]["rules"][0]["status"], "invalid")
        self.assertIn("COMPARER_ALLOW_REGEX", r["rules_report"]["rules"][0]["reason"])
        with mock.patch.object(rules, "ALLOW_REGEX", True):
            r = run(SRC, TGT, rules=[{"id": "rx", "type": "forbidden_text", "pattern": r"\b25%"}])
        self.assertEqual(r["rules_report"]["rules"][0]["status"], "violated")

    def test_text_rule_without_readable_text_is_unevaluated(self):
        r = run(SRC, b"", rules=[{"id": "legal", "type": "required_text", "value": "Terms"}])
        row = r["rules_report"]["rules"][0]
        self.assertEqual(row["status"], "unevaluated")
        self.assertFalse(any(f["category"] == "rule_violation" for f in r["findings"]))

    def test_allowed_change_requires_whole_span(self):
        # target changes "20%" -> "25%" AND drops the disclaimer; a broad rule must not cover unrelated text
        r = run(b"Save 20% today", b"Save 25% tomorrow", rules=[{"id": "ok", "type": "allowed_change", "from": "20%", "to": "25%"}])
        changed = [f for f in r["findings"] if f["category"] == "text_changed"]
        self.assertTrue(changed)
        # difflib merges into one replace block "20% today" -> "25% tomorrow": not a whole-span match
        self.assertTrue(all(f["disposition"] == "flagged" for f in changed), changed)
        r = run(b"Save 20% today", b"Save 25% today", rules=[{"id": "ok", "type": "allowed_change", "from": "20%", "to": "25%"}])
        self.assertEqual(r["verdict"]["status"], "match")

    def test_ignores_never_touch_rule_violations(self):
        r = run(SRC, TGT, rules=[{"id": "legal", "type": "required_text", "value": "Terms and conditions apply", "compliance": True},
                                 {"id": "cat", "type": "ignore_category", "value": "rule_violation"},
                                 {"id": "reg", "type": "ignore_region", "bbox": [0, 0, 1, 1]}])
        v = next(f for f in r["findings"] if f["category"] == "rule_violation")
        self.assertEqual(v["disposition"], "flagged")
        self.assertEqual(next(x for x in r["rules_report"]["rules"] if x["rule_id"] == "cat")["status"], "invalid")
        self.assertEqual(r["verdict"]["status"], "mismatch")

    def test_invalid_and_disabled_rules_reported(self):
        r = run(SRC, SRC, rules=[{"id": "x", "type": "nope"}, {"id": "y", "type": "required_text"},
                                 {"id": "z", "type": "ignore_region", "bbox": [0, 0, 2, 2]},
                                 {"id": "off", "type": "ignore_category", "value": "visual_diff", "enabled": False}])
        statuses = {row["rule_id"]: row["status"] for row in r["rules_report"]["rules"]}
        self.assertEqual(statuses, {"x": "invalid", "y": "invalid", "z": "invalid", "off": "skipped"})

    def test_rules_cannot_upgrade_inconclusive(self):
        r = run(b"", b"", rules=[{"id": "a", "type": "ignore_category", "value": "text_missing"}])
        self.assertEqual(r["verdict"]["status"], "inconclusive")

    def test_guidance_without_model_is_unevaluated(self):
        r = run(SRC, TGT, rule_guidance="price changes are fine")
        g = r["rules_report"]["guidance"]
        self.assertEqual(g["status"], "unevaluated")
        self.assertEqual(r["verdict"]["status"], "mismatch")

    def _with_model(self, replies, **opts):
        """Run with a fake OpenAI endpoint; `replies` is a list of reply strings consumed in order."""
        saved = {k: os.environ.pop(k) for k in list(os.environ) if k.startswith(("COMPARER_VISION", "GEMINI_", "OPENAI_", "ANTHROPIC_", "OLLAMA_"))}
        os.environ["OPENAI_API_KEY"] = "sk-test"
        calls = []
        def fake_post(url, body, headers):
            calls.append(json.dumps(body))
            return {"choices": [{"message": {"content": replies[min(len(calls) - 1, len(replies) - 1)]}}]}
        try:
            with mock.patch.object(vision_llm, "_post", fake_post):
                r = run(SRC, TGT, vision={"model": "m"}, **opts)
        finally:
            os.environ.pop("OPENAI_API_KEY", None); os.environ.update(saved)
        return r, calls

    def test_guidance_second_pass_suppresses_deterministic_finding(self):
        # engines: text only, so the only model call is the guidance pass
        first = run(SRC, TGT, engines=["text"])
        ids = {f["message"]: f["id"] for f in first["findings"]}
        price_id = next(i for m, i in ids.items() if "25%" in m)
        decision = json.dumps({"decisions": [{"id": price_id, "disposition": "ignored", "reason": "price changes allowed", "compliance": False},
                                             {"id": "f999", "disposition": "ignored", "reason": "bogus"}]})
        # every other known id gets a flagged decision with a reason so the pass is fully evaluated
        others = [{"id": i, "disposition": "flagged", "reason": "not covered"} for i in ids.values() if i != price_id]
        decision = json.dumps({"decisions": json.loads(decision)["decisions"] + others})
        r, calls = self._with_model([BASE_REPLY, decision], engines=["text", "vision_llm"], rule_guidance="price changes are fine")
        self.assertEqual(len(calls), 2)                              # base vision pass, then the guidance second pass
        self.assertNotIn("price changes are fine", calls[0])         # base pass never sees guidance
        self.assertIn("price changes are fine", calls[1])
        self.assertIn(price_id, calls[1])                            # all finding ids were sent
        g = r["rules_report"]["guidance"]
        self.assertEqual(g["status"], "evaluated")
        self.assertEqual(g["unknown_ids"], ["f999"])
        self.assertEqual(g["invalid"], 0)
        price = next(f for f in r["findings"] if f["id"] == price_id)
        self.assertEqual(price["disposition"], "ignored")
        self.assertEqual(price["rule_matches"][0]["rule_id"], "guidance")
        self.assertEqual(r["verdict"]["status"], "mismatch")        # disclaimer still flagged
        self.assertEqual([f["disposition"] for f in r["base_findings"]], ["flagged"] * len(r["base_findings"]))
        self.assertEqual(r["base_verdict"]["status"], "mismatch")

    def test_base_vision_prompt_has_no_guidance_and_invalid_reply_is_unevaluated(self):
        base_reply = json.dumps({"summary": "ok", "match": False, "findings": [{"category": "visual_diff", "severity": "low", "message": "logo shade"}]})
        r, calls = self._with_model([base_reply, "not json at all"], engines=["vision_llm"], rule_guidance="ignore logo colour")
        self.assertEqual(len(calls), 2)
        self.assertNotIn("ignore logo colour", calls[0])             # base pass is guidance-free
        self.assertIn("ignore logo colour", calls[1])
        self.assertEqual(r["rules_report"]["guidance"]["status"], "unevaluated")
        self.assertTrue(all(f["disposition"] == "flagged" for f in r["findings"]))
        self.assertEqual(r["verdict"]["status"], "mismatch")

    def test_invalid_decisions_and_long_guidance(self):
        first = run(SRC, TGT, engines=["text"])
        fid = first["findings"][0]["id"]
        decision = json.dumps({"decisions": [{"id": fid, "disposition": "maybe", "reason": "r"}, "garbage",
                                             {"id": fid, "disposition": "ignored"},               # no reason -> invalid
                                             {"id": fid, "disposition": "ignored", "reason": "ok"},
                                             {"id": fid, "disposition": "ignored", "reason": "dup"}]})
        r, calls = self._with_model([BASE_REPLY, decision], engines=["text", "vision_llm"], rule_guidance="x" * 12000)
        g = r["rules_report"]["guidance"]
        self.assertEqual(g["status"], "evaluated")
        self.assertEqual(g["decisions"], 1)          # one valid decision applied; bad shape, no reason, duplicate dropped
        self.assertEqual(g["invalid"], 4)
        self.assertTrue(any("rule_guidance cut" in w for w in r["stats"]["warnings"]))
        self.assertNotIn("x" * 10001, calls[1])
        decision = json.dumps({"decisions": [{"id": "nope", "disposition": "ignored"}]})
        r, _ = self._with_model([BASE_REPLY, decision], engines=["text", "vision_llm"], rule_guidance="y")
        self.assertEqual(r["rules_report"]["guidance"]["status"], "unevaluated")

    def test_empty_decisions_is_unevaluated_and_no_findings_is_skipped(self):
        r, calls = self._with_model([BASE_REPLY, json.dumps({"decisions": []})], engines=["text", "vision_llm"], rule_guidance="g")
        self.assertEqual(r["rules_report"]["guidance"]["status"], "unevaluated")
        self.assertTrue(all(f["disposition"] == "flagged" for f in r["findings"]))
        # identical sources: base pass runs (one call) and reports a clean match, so there are no findings
        # and the guidance pass is skipped without a second call
        clean = json.dumps({"summary": "same", "match": True, "findings": []})
        saved = {k: os.environ.pop(k) for k in list(os.environ) if k.startswith(("COMPARER_VISION", "OPENAI_"))}
        os.environ["OPENAI_API_KEY"] = "sk-test"
        calls = []
        def fake_post(url, body, headers):
            calls.append(json.dumps(body))
            return {"choices": [{"message": {"content": clean}}]}
        try:
            with mock.patch.object(vision_llm, "_post", fake_post):
                r = run(SRC, SRC, engines=["text", "vision_llm"], vision={"model": "m"}, rule_guidance="g")
        finally:
            os.environ.pop("OPENAI_API_KEY", None); os.environ.update(saved)
        self.assertEqual(len(calls), 1)
        self.assertEqual(r["rules_report"]["guidance"]["status"], "skipped")

    def test_model_flagged_vs_rule_ignored_conflict_keeps_rule(self):
        rule = [{"id": "ok", "type": "allowed_change", "from": "20%", "to": "25%"}]
        first = run(SRC, TGT, engines=["text"], rules=rule)
        pid = next(f["id"] for f in first["findings"] if f["category"] == "text_changed")
        decision = json.dumps({"decisions": [{"id": pid, "disposition": "flagged", "reason": "price looks wrong"}]})
        r, _ = self._with_model([BASE_REPLY, decision], engines=["text", "vision_llm"], rules=rule, rule_guidance="check prices")
        f = next(f for f in r["findings"] if f["id"] == pid)
        self.assertEqual(f["disposition"], "ignored")                        # explicit rule wins
        self.assertTrue(any("CONFLICT" in m["reason"] for m in f["rule_matches"]))
        self.assertEqual(r["rules_report"]["guidance"]["conflicts"][0]["id"], pid)

    def test_guidance_respects_vision_engine_toggle(self):
        saved = {k: os.environ.pop(k) for k in list(os.environ) if k.startswith(("COMPARER_VISION", "OPENAI_"))}
        os.environ["OPENAI_API_KEY"] = "sk-test"
        try:
            with mock.patch.object(vision_llm, "_post", side_effect=AssertionError("model must not be called")):
                r = run(SRC, TGT, engines=["text"], vision={"model": "m"}, rule_guidance="ignore prices")
        finally:
            os.environ.pop("OPENAI_API_KEY", None); os.environ.update(saved)
        g = r["rules_report"]["guidance"]
        self.assertEqual(g["status"], "unevaluated")
        self.assertIn("vision_llm engine not requested", g["reason"])

    def test_prompt_marks_findings_untrusted(self):
        r, calls = self._with_model([BASE_REPLY, json.dumps({"decisions": []})], engines=["text", "vision_llm"], rule_guidance="g")
        self.assertIn("untrusted data", calls[1])

    def test_guidance_cannot_ignore_rule_violation(self):
        first = run(SRC, TGT, engines=["text"], rules=[{"id": "legal", "type": "required_text", "value": "Terms and conditions apply"}])
        vid = next(f["id"] for f in first["findings"] if f["category"] == "rule_violation")
        decision = json.dumps({"decisions": [{"id": vid, "disposition": "ignored", "reason": "meh"}]})
        r, _ = self._with_model([BASE_REPLY, decision], engines=["text", "vision_llm"], rule_guidance="anything goes",
                                rules=[{"id": "legal", "type": "required_text", "value": "Terms and conditions apply"}])
        v = next(f for f in r["findings"] if f["category"] == "rule_violation")
        self.assertEqual(v["disposition"], "flagged")


@unittest.skipUnless(deps.pillow() is not None, "Pillow")
class Regions(unittest.TestCase):
    def test_ignore_region_on_pixel_finding(self):
        src = fixtures.png_bytes(fixtures.render_card(fixtures.SOURCE_LINES))
        tgt = fixtures.png_bytes(fixtures.render_card(fixtures.SOURCE_LINES, badge=False))
        r = pipeline.compare("a.png", src, "b.png", tgt, {"engines": ["pixel"],
                             "rules": [{"id": "badge", "name": "badge area is dynamic", "type": "ignore_region", "bbox": [0.8, 0.15, 0.2, 0.3], "side": "target"}]},
                             artifact_dir=TMP).to_dict()
        self.assertEqual(r["base_verdict"]["status"], "mismatch")
        self.assertEqual(r["verdict"]["status"], "match")
        self.assertEqual(r["findings"][0]["disposition"], "ignored")
        # a region that only partly covers the finding does not suppress it
        r = pipeline.compare("a.png", src, "b.png", tgt, {"engines": ["pixel"],
                             "rules": [{"id": "half", "type": "ignore_region", "bbox": [0.8, 0.15, 0.1, 0.3]}]},
                             artifact_dir=TMP).to_dict()
        self.assertEqual(r["findings"][0]["disposition"], "flagged")

    def test_ignore_region_does_not_suppress_text_findings(self):
        if ocr.availability()[0] != "ok":
            self.skipTest("OCR")
        src = fixtures.png_bytes(fixtures.render_card(fixtures.SOURCE_LINES))
        tgt = fixtures.png_bytes(fixtures.render_card(fixtures.TARGET_LINES, badge=False))
        r = pipeline.compare("a.png", src, "b.png", tgt, {"engines": ["ocr", "text"],
                             "rules": [{"id": "all", "type": "ignore_region", "bbox": [0, 0, 1, 1]}]}, artifact_dir=TMP).to_dict()
        self.assertTrue(all(f["disposition"] == "flagged" for f in r["findings"]))


if __name__ == "__main__":
    unittest.main()
