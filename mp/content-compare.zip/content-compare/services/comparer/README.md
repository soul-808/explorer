# comparer — Python comparison service

Takes two marketing assets (image, PDF, DOCX, TXT in any combination), finds
copy and visual differences, draws colour-coded boxes on the pages, and returns
a findings list. See [API.md](API.md) for the HTTP/JSON contract.

**Design rule:** nothing is required beyond the Python standard library. Every
engine is optional. A missing library reports `unavailable`, a crashing one
reports `failed`, and the run continues. If no comparison engine could run the
verdict is `inconclusive`, never a false `match`.

## Quick start

```bash
cd services/comparer

# 0. stdlib only — text comparison and model HTTP adapters; local image methods need Pillow
python3 -m comparer health

# 1. recommended (Pillow, pypdfium2, pypdf, pytesseract, numpy); tesseract binary is separate
python3 -m venv .venv && . .venv/bin/activate        # or: uv venv .venv && . .venv/bin/activate
pip install -e ".[recommended]"                        # or: uv pip install -e ".[recommended]"
#   macOS: brew install tesseract      Debian/Ubuntu: apt install tesseract-ocr      Windows: UB-Mannheim installer

# 2. run
python -m comparer serve                # http://127.0.0.1:8765
python -m comparer compare design.png app-screenshot.png --out ./out
python -m comparer health
```

The Next.js app in `apps/web` proxies to `127.0.0.1:8765`; start the service first.

Sample assets for a smoke test: `python tests/fixtures.py ./samples` writes a
designed card, an app screenshot with a changed price and a missing disclaimer,
plus the same copy as DOCX, TXT and PDF.

## Install profiles (`pip install -e ".[<profile>]"`)

| profile | adds | enables |
|---|---|---|
| *(none)* | — | text-vs-text diff, DOCX/TXT parsing, PDF text via `pdftotext` CLI if present, vision-LLM calls |
| `images` | Pillow | image decoding, pixel diff, annotated overlays, PDF rendering via `pdftoppm` CLI if present |
| `pdf` | pypdfium2, pypdf | PDF rendering + native text **with word boxes** |
| `ocr` | Pillow, pytesseract | OCR of screenshots/renders (needs the `tesseract` binary) |
| `ssim` | numpy, scikit-image | structural-similarity score |
| `ocr-onnx` | rapidocr-onnxruntime | OCR with no system binary (bundles PP-OCR models) |
| `ocr-easy` | easyocr | OCR via PyTorch (heavy) |
| `cv` | opencv-python-headless | reserved for future feature-based alignment |
| `pdf-mupdf` | PyMuPDF | opt-in PDF backend, **AGPL** (see below); also needs `COMPARER_ALLOW_PYMUPDF=1` |
| `recommended` | Pillow, pypdfium2, pypdf, pytesseract, numpy | the everyday set |
| `all` | everything permissive above | evaluation |

## Engines

| engine | what it does | needs | output |
|---|---|---|---|
| `ocr` (extractor) | word boxes + text for pages with an image but no native text. Tesseract runs four complementary passes: default layout, sparse text, sparse text at half scale (large display numbers such as `4.25%`), and crops of saturated colour regions (buttons, badges). Passes are merged by confidence, junk tokens dropped, and words ordered by lines, then column blocks. Known limits: tightly kerned pairs may fuse (`Abetter`), `APY is` may read `APYis`; the text engine reports those as low-severity spacing noise | Pillow + one OCR backend | enriches pages |
| `text` | token diff of source vs target text (native or OCR), quote/dash/case normalised; maps runs back to word boxes | stdlib | `text_missing`, `text_extra`, `text_changed` |
| `pixel` | absolute image difference clustered into regions on a coarse grid; flags geometry mismatch instead of diffing meaningless pixels | Pillow | `visual_diff`, `layout_shift`, `stats.pixel_diff_ratio` |
| `ssim` | structural similarity per page; whole-page finding below `options.ssim.threshold` (0.90) | numpy + scikit-image | `visual_diff`, `stats.ssim` |
| `vision_llm` | sends both sides to a vision model and parses its JSON findings | a provider (env) + a model name | any category, `stats.llm_summary` |

Confidence is a heuristic based on successful comparator count and finding severity; it is not a calibrated probability or a measured agreement score.
A match reached only through OCR is scaled down by the OCR confidence. Automatic PDF/model caps are recorded in `stats.coverage_limits`; a result with no flagged differences is inconclusive if those caps left content unexamined.

### SME rules stage (`comparer/rules.py`)

Runs after the engines. `options.rules` (required_text, forbidden_text, allowed_change,
ignore_region, ignore_category) are deterministic and need no model; `options.rule_guidance`
is free text handed to the vision model. Rules annotate findings with a `disposition`
(`flagged`/`ignored`) and `rule_matches`, add `rule_violation` findings, and never delete
evidence: `base_findings` and `base_verdict` stay in the response. See API.md.

### Vision-LLM configuration (off by default)

No model call happens unless a provider is configured **and** a model is named.
Keys are read on the server only.

| provider | env | notes |
|---|---|---|
| `gemini` | `GEMINI_API_KEY` | Google AI Studio REST |
| `openai` | `OPENAI_API_KEY` and/or `OPENAI_BASE_URL` | any OpenAI-compatible server: OpenAI, Azure gateways, vLLM, LM Studio, Ollama `/v1`; a base URL alone is enough for keyless local servers |
| `anthropic` | `ANTHROPIC_API_KEY` | Messages API |
| `ollama` | `OLLAMA_BASE_URL` (default `http://127.0.0.1:11434`) | native Ollama API, no key |

Pick the model per request (`options.vision.model`, or `--vision-model` on the
CLI) or globally with `COMPARER_VISION_MODEL`. `COMPARER_VISION_PROVIDER` pins
the provider when several keys are present. Nothing is hard-coded.

## Automation layer (v0.2)

`python -m comparer serve` now also starts the automation layer (disable with `--no-automation`).
Contract: [AUTOMATION_API.md](AUTOMATION_API.md).

- **History**: every manual comparison is stored as a *run* (`GET /api/runs`, `GET /api/runs/{id}`) with its
  originals and overlays under `.data/runs/<id>/`. Pass `options.persist: false` to skip.
- **Jobs**: `POST /api/jobs` queues a comparison; an in-process worker thread executes it and creates a run.
  Idempotency keys make CI retries safe; interrupted jobs are re-queued on restart.
- **Intake harness**: set `COMPARER_INBOX=/path/to/inbox`. Drop files plus a manifest (`*.json` listing
  source/target pairs relative to the inbox, with labels such as suite/build); the poller turns each pair
  into a job and renames the manifest `.done` or `.failed`. Nothing outside the inbox is ever read.
  Any producer works: a Playwright/Cypress run copying screenshots, a CI step, a designer's export script.
- **Feedback**: reviewers post verdicts on a run or a single finding (`POST /api/runs/{id}/feedback`);
  `GET /api/feedback/export` returns JSONL with the finding, the verdict and context, ready for evaluation
  or fine-tuning preparation. The service itself never trains or uploads anything.
- **Adapters**: `Store` (built in: `sqlite` default, `jsonfiles`), `Source` (built in: inbox folder),
  vision `Provider` (gemini, openai-compatible, anthropic, ollama). Others are extension points via
  `COMPARER_STORE=module:Class` / `COMPARER_SOURCES=module:Class`. A configured store that cannot open
  fails startup; it never silently switches stores. Failed source plugins are reported in
  `GET /api/automation` and skipped. Other database adapters require implementation.
- **Security**: loopback bind; optional `COMPARER_TOKEN` guards job creation/cancellation, run deletion,
  manual polls, cleanup, and feedback export. It is not user authentication or protection for all reads
  and feedback writes. Paths from the network are inbox-relative only (no absolute paths, `..` or symlinks).
- **Cleanup**: bounded by policy (age, count, size budget, job/scratch/inbox TTLs), applied by a maintenance
  thread, `POST /api/automation/cleanup` or `python -m comparer cleanup --dry-run`. Scratch overlays and job
  input copies are removed as soon as the run holds its own copy. Feedback survives pruning. See AUTOMATION_API.md.
- **White-label**: `COMPARER_BRAND_NAME`, `COMPARER_BRAND_LOGO`, `COMPARER_BRAND_ACCENT` surface through
  `GET /api/config` (never includes keys) for the UI to style itself.

Quick demo:
```bash
mkdir -p /tmp/inbox/approved /tmp/inbox/shots
COMPARER_INBOX=/tmp/inbox python -m comparer serve
# in another shell: copy files in, then drop a manifest
cat > /tmp/inbox/build-1.json <<'JSON'
{"batch": "build-1", "pairs": [{"source": "approved/checkout.png", "target": "shots/checkout.png",
                                "labels": {"suite": "checkout", "build": "1"}}]}
JSON
curl -s http://127.0.0.1:8765/api/runs | jq '.runs[0].verdict'
```

## Environment variables

| var | default | purpose |
|---|---|---|
| `COMPARER_HOST` / `COMPARER_PORT` | `127.0.0.1` / `8765` | bind address |
| `COMPARER_ARTIFACT_DIR` | `services/comparer/.artifacts` | rendered pages + overlays + result.json per run |
| `COMPARER_MAX_PAGES` | `10` | pages compared per PDF |
| `COMPARER_RENDER_DPI` | `110` | PDF render resolution |
| `COMPARER_MAX_BODY_MB` | `60` | upload cap |
| `COMPARER_CORS_ORIGIN` | `localhost` | browser origins allowed: any localhost/127.0.0.1 port by default; comma list or `*` |
| `COMPARER_MAX_ZIP_MB` | `200` | cap on DOCX expanded size |
| `COMPARER_MAX_GUIDANCE_CHARS` | `10000` | cap on free-form guidance sent to the model; overflow reported in `stats.warnings` |
| `COMPARER_ALLOW_REGEX` | unset | allow `pattern` regex in rules (catastrophic patterns can stall a worker; literal `value` is the default) |
| `COMPARER_VISION_MODELS` | unset | optional comma allow-list of model names clients may request |
| `COMPARER_VISION_BASE_URL` | unset | override endpoint for the configured provider (never from requests) |
| `COMPARER_VISION_MAX_IMAGES` / `COMPARER_VISION_MAX_TEXT` | `4` / `20000` | per-side limits sent to the model; overflow is reported in `stats.warnings` |
| `COMPARER_ALLOW_PYMUPDF` | unset | opt in to the AGPL PDF backend |
| `COMPARER_DATA_DIR` | `services/comparer/.data` | runs, job inputs, store file |
| `COMPARER_STORE` / `COMPARER_STORE_PATH` | `sqlite` / `.data/comparer.db` | `sqlite`, `jsonfiles`, or `module:Class` |
| `COMPARER_WORKERS` | `1` | background worker threads (0 disables execution, max 4) |
| `COMPARER_JOB_ATTEMPTS` | `2` | attempts before a job is marked failed |
| `COMPARER_INBOX` / `COMPARER_INTAKE_INTERVAL` | unset / `5` | intake folder and poll seconds |
| `COMPARER_SOURCES` | unset | comma list of `module:Class` Source plugins |
| `COMPARER_TOKEN` | unset | bearer token for protected automation routes |
| `COMPARER_MAX_INPUT_MB` | `30` | per-file cap for job and inbox inputs |
| `COMPARER_RETENTION_DAYS` / `COMPARER_MAX_RUNS` / `COMPARER_MAX_DATA_MB` | `30` / `500` / `2048` | run retention (0 disables) |
| `COMPARER_JOB_RETENTION_DAYS` / `COMPARER_SCRATCH_TTL_MINUTES` / `COMPARER_INBOX_TTL_DAYS` | `7` / `120` / `7` | job records, scratch artifacts, acknowledged manifests |
| `COMPARER_CLEANUP_INTERVAL` / `COMPARER_KEEP_FEEDBACK` / `COMPARER_ORPHAN_GRACE_SECONDS` | `600` / `1` / `900` | maintenance cadence; keep feedback when runs are pruned; age before a recordless folder counts as an orphan |
| `COMPARER_PROVIDER_PLUGIN` | unset | `name=module:function` custom vision provider(s); see AUTOMATION_API.md |
| `COMPARER_BRAND_NAME` / `_LOGO` / `_ACCENT` / `_TAGLINE` | Content Compare / unset / `#2f6d4b` / unset | white-label config exposed via `/api/config` |
| `COMPARER_CONFIG` | unset | JSON file with brand + settings; env vars override it; secrets never read from it |
| `COMPARER_VISION_*` | unset | see above |

## Dependency candidates and licences

Listed so an enterprise reviewer can check them against an internal
allow-list. **No claim is made here that any of these are approved** in any
particular Artifactory; verify with your own index.

| package | licence | role | notes |
|---|---|---|---|
| Pillow | MIT-CMU (HPND) | images, overlays | ubiquitous |
| pypdfium2 | Apache-2.0 / BSD-3 (PDFium) | PDF render + text boxes | Chromium's PDF engine, wheels for all platforms |
| pypdf | BSD-3 | PDF text fallback | pure Python |
| pytesseract | Apache-2.0 | OCR wrapper | needs the `tesseract` binary (Apache-2.0), packaged by brew/apt/choco |
| numpy | BSD-3 | arrays for ssim/rapidocr/easyocr | |
| scikit-image | BSD-3 | SSIM | pulls scipy |
| rapidocr-onnxruntime | Apache-2.0 | OCR, no system binary | bundles PP-OCRv4 models (Apache-2.0), onnxruntime (MIT) |
| easyocr | Apache-2.0 | OCR | PyTorch dependency, model download on first run |
| opencv-python-headless | Apache-2.0 | future alignment / feature matching | |
| PyMuPDF (fitz) | **AGPL-3.0** or commercial | opt-in PDF backend | fastest and richest, but copyleft; disabled unless `COMPARER_ALLOW_PYMUPDF=1` |
| poppler (`pdftoppm`, `pdftotext`) | GPL-2.0 (CLI, called as a subprocess) | PDF fallback when no Python PDF lib | system package, not a Python dependency |

Not used on purpose: `python-docx` (stdlib zip+xml covers our read-only need),
`pdf2image` (thin wrapper over poppler; we call the binary directly),
`imagehash`/`scikit-learn` (no need yet).

## Layout

```
comparer/
  __main__.py      CLI: health | compare | serve | cleanup
  server.py        stdlib ThreadingHTTPServer, manual + automation routes, token auth
  automation.py    run persistence, job worker, inbox intake, feedback export, /api/config
  adapters.py      Store / Source protocols + plugin loader
  store_sqlite.py  default Store (stdlib sqlite3, WAL)
  store_json.py    alternative Store (one JSON file per record)
  pipeline.py      orchestration, verdict, artifacts
  loaders.py       image / pdf / docx / txt -> pages (text, word boxes, images)
  overlay.py       draws boxes + labels with Pillow
  models.py        dataclasses + LEGEND colours
  deps.py          optional-dependency probing
  engines/         ocr, text, pixel, ssim, vision_llm (+ textnorm helpers)
tests/             unittest suite (also runs under pytest); fixtures.py generates samples
```

## Tests

```bash
python -m unittest discover -s tests      # stdlib runner, works in any profile
python -m pytest tests -q                 # if pytest is installed
```

Tests skip what the environment cannot support (e.g. OCR without tesseract),
so the suite is green in every profile.

## Adding an engine

Create `comparer/engines/<name>.py` with `NAME`, `availability()` and
`run(ctx)`, then add it to `EXTRACTORS` or `COMPARATORS` in
`engines/__init__.py`. Use `ctx.finding(...)`, `ctx.skip(...)`,
`ctx.unavailable(...)`, `ctx.report(...)`, and write numbers to `ctx.stats`.
Raise freely; the pipeline records `failed` and moves on.
