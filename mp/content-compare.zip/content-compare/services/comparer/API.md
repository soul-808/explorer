# Comparer service API (v1)

Python service owned by `claude-compare`. Runs with **zero third-party
dependencies** (stdlib HTTP server + Pillow-free fallbacks) and gets stronger
as optional engines are installed. Nothing is ever fatal: every engine reports
`ok | unavailable | failed | skipped`, and the verdict is `inconclusive` when
nothing ran.

Default bind: `http://127.0.0.1:8765`. All responses are JSON, UTF-8.

## GET /api/health

```json
{
  "status": "ok",
  "version": "0.1.0",
  "engines": [
    {"name": "text_extract", "status": "ok", "backend": "pymupdf", "version": "1.25.1"},
    {"name": "ocr",          "status": "unavailable", "message": "no OCR backend (pytesseract/rapidocr/easyocr)"},
    {"name": "pixel",        "status": "ok", "backend": "pillow"},
    {"name": "ssim",         "status": "unavailable"},
    {"name": "vision_llm",   "status": "skipped", "message": "no provider configured"}
  ],
  "supported_kinds": ["image", "pdf", "docx", "txt"]
}
```

## POST /api/compare

`multipart/form-data` with fields:

| field     | required | notes |
|-----------|----------|-------|
| `source`  | yes | reference file (the "truth": marketing design, copy deck, PDF, DOCX, TXT) |
| `target`  | yes | produced file (screenshot, rendered PDF, etc.) |
| `options` | no  | JSON string, see below |

Also accepts `application/json` `{ "source": {"name","content_base64"}, "target": {...}, "options": {...} }`.

`options` (all optional):

```json
{
  "engines": ["text", "ocr", "pixel", "ssim", "vision_llm"],   // subset to run; default = all available
  "vision": {"provider": "gemini|openai|anthropic|ollama", "model": "gemini-2.5-flash", "base_url": null},
  "text": {"ignore_case": true, "ignore_whitespace": true, "ignore_punctuation": false},
  "pixel": {"threshold": 32, "min_region_px": 24},
  "pages": {"source": [0], "target": [0]},                    // page indexes, default all (max 10)
  "render_overlays": true,
  "rules": [ ...see "SME rules" below... ],
  "rule_guidance": "free-form reviewer notes; interpreted only by a configured vision model"
}
```

Notes on options:
- `engines: []` means run **nothing** (result is `inconclusive`); omit the key to run everything available.
- `vision.provider` may only name a provider the **server** has configured via environment; `vision.base_url`
  is ignored (URLs and credentials never come from the request). `vision.model` is free unless the server sets
  `COMPARER_VISION_MODELS`.
- `text.ignore_whitespace: false` is reported as unsupported in `stats.warnings` (whitespace is always collapsed).

Response `CompareResult`:

```json
{
  "id": "cmp_20260917T150000_ab12",
  "created_at": "2026-09-17T15:00:00Z",
  "source": {"name": "design.png", "kind": "image", "notes": [],
             "pages": [{"index": 0, "width": 1440, "height": 900, "image_url": "/api/artifacts/cmp_.../source-0.png",
                        "text_source": "ocr:pytesseract", "text": "Summer Sale Save 20% ...", "text_chars": 71, "text_truncated": false}]},
  "target": {"name": "app.png",    "kind": "image", "notes": [], "pages": [ ...same shape... ]},
  "engines": [
    {"name": "text",       "status": "ok", "backend": "difflib", "duration_ms": 3},
    {"name": "ocr",        "status": "ok", "backend": "pytesseract", "duration_ms": 812},
    {"name": "pixel",      "status": "ok", "backend": "pillow", "duration_ms": 140},
    {"name": "ssim",       "status": "unavailable", "message": "scikit-image not installed"},
    {"name": "vision_llm", "status": "skipped", "message": "no provider configured"}
  ],
  "verdict":      {"status": "match | mismatch | inconclusive", "confidence": 0.0, "summary": "...", "counts": {"text_changed": 1}, "after_rules": false},
  "base_verdict": {"status": "mismatch", "confidence": 0.9, "summary": "...", "counts": {...}},   // before rules
  "stats": {"text_similarity": 0.96, "pixel_diff_ratio": 0.012, "ssim": null, "engines_ran": 3,
            "coverage": {"source": {"text": "native|ocr|none", "ocr_confidence": null, "pages": 1, "image": true, "unreadable_pages": [], "empty": false},
                         "target": {...}},
            "warnings": ["..."], "unknown_engines": []},
  "findings": [
    {
      "id": "f1",
      "category": "text_missing | text_extra | text_changed | visual_diff | layout_shift | llm_observation",
      "severity": "high | medium | low | info",
      "engine": "text",
      "confidence": 0.9,
      "message": "Source says \"Save 20%\" but target shows \"Save 25%\"",
      "source": {"page": 0, "bbox": [0.12, 0.30, 0.20, 0.04], "text": "Save 20%"},
      "target": {"page": 0, "bbox": [0.12, 0.30, 0.21, 0.04], "text": "Save 25%"},
      "disposition": "flagged | ignored",
      "rule_matches": [{"rule_id": "r1", "rule_name": "price bump ok", "reason": "allowed change '20%' -> '25%'", "compliance": false}]
    }
  ],
  "base_findings": [ ...the findings exactly as the engines produced them, before rules... ],
  "rules_report": {
    "rules": [{"rule_id": "r1", "name": "...", "type": "allowed_change", "status": "applied | no_match | satisfied | violated | invalid | skipped", "matches": 1, "compliance": false, "reason": "only for invalid/skipped"}],
    "guidance": {"status": "not_provided | evaluated | unevaluated", "reason": "..."},
    "counts": {"flagged": 2, "ignored": 1, "added": 1, "compliance_flagged": 1}
  },
  "overlays": {
    "source": [{"page": 0, "image_url": "/api/artifacts/cmp_.../source-0-annotated.png"}],
    "target": [{"page": 0, "image_url": "/api/artifacts/cmp_.../target-0-annotated.png"}]
  },
  "legend": {"text_missing": "#e5484d", "text_extra": "#f76b15", "text_changed": "#f5d90a",
             "visual_diff": "#d6409f", "layout_shift": "#8e4ec6", "llm_observation": "#3e63dd"}
}
```

- **Verdict rules:** any finding with severity above `info` makes the verdict `mismatch`. `inconclusive` means
  nothing could be verified: no comparison engine ran, a side was empty/unreadable, or some pages were unreadable
  while the rest matched. Rules can downgrade a `mismatch` to `match` but can never upgrade `inconclusive`.
- `verdict` counts only findings with `disposition: "flagged"`; `base_verdict` counts all `base_findings`.
  With no rules and no guidance, `findings` equals `base_findings` and both verdicts agree.
- `bbox` is `[x, y, w, h]` **normalized 0..1** relative to that page's rendered size, so the UI can draw
  boxes at any zoom. `source`/`target` may be `null` when the side has no geometry (e.g. DOCX/TXT).
- Text-only sources (DOCX/TXT/copy deck) still get findings; the box lands on the image side.
- Overlays are server-drawn PNGs with the same colors as `legend` and a numbered label matching `findings[].id`.
  If Pillow is missing, `overlays` is empty and the UI should draw boxes itself from `findings`.

## SME rules (`options.rules`, `options.rule_guidance`)

The base comparison is always run in full and kept in `base_findings`. Rules then annotate
(never delete) findings and may add `rule_violation` findings. Deterministic rules need no model.

```json
{
  "rules": [
    {"id": "legal-1", "name": "T&C line must be present", "type": "required_text",
     "value": "Terms and conditions apply", "side": "target", "severity": "high", "compliance": true},
    {"id": "ban-1",   "name": "no 'guaranteed'", "type": "forbidden_text", "pattern": "\\bguarantee(d|s)?\\b",
     "side": "target", "severity": "high", "compliance": true},
    {"id": "ok-1",    "name": "price bump approved", "type": "allowed_change", "from": "20%", "to": "25%"},
    {"id": "dyn-1",   "name": "hero badge is dynamic", "type": "ignore_region", "side": "target",
     "page": 0, "bbox": [0.80, 0.15, 0.20, 0.30]},
    {"id": "px-1",    "name": "ignore anti-aliasing noise", "type": "ignore_category", "value": "visual_diff",
     "enabled": false}
  ],
  "rule_guidance": "Prices may differ by region. Disclaimers must match verbatim. Ignore logo colour shifts."
}
```

| type | fields | effect |
|---|---|---|
| `required_text` | `value` (plain text, case/space-insensitive); `side` default `target` | if absent on that side, **adds** a `rule_violation` finding with the rule's `severity`; `unevaluated` when that side has no readable text |
| `forbidden_text` | same as above | for each occurrence, **adds** a `rule_violation` finding (with a box when the page has word boxes) |
| `allowed_change` | `from` and/or `to`: the finding's whole normalized source text must equal `from` and target text `to`; or `value` equal to either side | marks matching text findings `ignored`; broad blocks with unrelated changes stay flagged |
| `ignore_region` | `bbox` `[x,y,w,h]` normalized; optional `side`, `page` | marks `visual_diff` / `layout_shift` findings whose box is ≥95% inside the region `ignored`; never text or rule findings |
| `ignore_category` | `value` = a finding category (not `rule_violation`) | marks all findings of that category `ignored` |

`pattern` (regex) is accepted on text rules only when the server sets `COMPARER_ALLOW_REGEX=1`.

Common fields: `id` (default `ruleN`), `name`, `enabled` (default true), `severity` (`high|medium|low|info`,
default `high`, used for added violations), `compliance` (bool, surfaced in `rule_matches` and
`rules_report.counts.compliance_flagged`), `note` (free text echoed as the reason on violations).

`rule_guidance` triggers a **second model pass** after the base comparison and the deterministic rules: the
configured vision model receives the guidance, both assets, and the complete list of finding ids (text, pixel,
ssim, vision and rule violations) and returns one decision per id (`disposition`, `reason`, `compliance`).
Decisions appear as `rule_matches` with `rule_id: "guidance"`. The base vision pass never sees the guidance.
`rules_report.guidance.status` is `not_provided`, `skipped` (no findings, model not called), `evaluated`, or
`unevaluated` (no model, invalid reply, or no valid decision for a known id). It reports `decisions` applied,
`invalid` decisions dropped (bad disposition, missing reason, duplicate id), `missing` ids the model skipped,
`unknown_ids` it invented, `conflicts` (model said flagged where an explicit rule ignores; the explicit rule wins
and the disagreement is recorded on the finding), and `notes`. The prompt tells the model that asset text and
findings are untrusted data, not instructions. Guidance longer than 10,000 characters
is cut and reported in `stats.warnings`; the base engines never see it. If no vision model is configured or the reply is not valid decision JSON, `status` is `unevaluated`
and nothing changes. Guidance can never ignore a `rule_violation`.

Rule semantics worth knowing:
- `ignore_region` only suppresses `visual_diff` / `layout_shift`, and only when the finding box is ≥95% inside the region.
- `allowed_change` matches whole spans: the finding's source text must equal `from` and target text `to` (normalised).
  A replacement block that also contains unrelated changes stays flagged.
- `required_text` / `forbidden_text` report `unevaluated` when the checked side has no readable text.
- `pattern` (regex) is rejected unless the server sets `COMPARER_ALLOW_REGEX=1`; patterns are capped at 200 chars.
- Ignores never touch `rule_violation` findings; `ignore_category: rule_violation` is invalid.
- `options.ssim.threshold` (default 0.90): pages scoring below it produce a whole-page `visual_diff`, so SSIM
  alone flags structural differences below that threshold. Smaller visual changes may require pixel or copy comparison.

## GET /api/artifacts/{id}/{file}

Serves rendered pages / overlays (PNG) and `result.json`. `id` must match `cmp_YYYYMMDDTHHMMSS_xxxx` and `file`
one of `source|target-<n>[-annotated].png|jpg` or `result.json`; anything else is 404. Overlays draw only
`flagged` findings. Artifacts live under `services/comparer/.artifacts/` (gitignored).

## Browser access (CORS)

Default policy allows any `http://localhost:*` / `http://127.0.0.1:*` origin (the Next.js proxy or dev server) and
requests with no `Origin` header (curl, server-side proxy). Other origins get `403` on `POST` and no CORS headers.
Set `COMPARER_CORS_ORIGIN` to a comma list of origins to restrict further, or `*` to allow all.

## CLI (for environments without a server)

```
python -m comparer compare SOURCE TARGET [--out DIR] [--json] [--engines text,ocr,pixel] [--rules rules.json] [--guidance "..."]
python -m comparer health
python -m comparer serve [--host 127.0.0.1] [--port 8765]
```

## Engines and dependency tiers

| engine | tier 0 (stdlib) | tier 1 (common candidates) | tier 2 (newer) |
|---|---|---|---|
| text extract | txt, docx (zipfile+xml), pdf via `pdftotext` CLI if present | `pypdfium2`, `pypdf`; opt-in PyMuPDF | |
| ocr | none | `pytesseract` (+ tesseract binary) | `rapidocr-onnxruntime`, `easyocr` |
| pixel | none | `Pillow` (+ `numpy`) | `opencv-python-headless` |
| ssim | none | `scikit-image` | |
| vision_llm | `urllib` calls to Gemini / OpenAI-compatible / Anthropic / Ollama | | |

Vision providers read keys **server-side only** from env: `GEMINI_API_KEY`, `OPENAI_API_KEY`,
`OPENAI_BASE_URL`, `ANTHROPIC_API_KEY`, `OLLAMA_BASE_URL`. No model call is made unless a provider is
configured **and** `vision_llm` is requested.

## Coverage limits

Documents expose `total_pages` when known and `coverage_limits` when an automatic cap prevents full review.
`stats.coverage` also records the actual zero-based `page_indexes`; `stats.coverage_limits` aggregates loader
and model limits. If a capped result has no remaining flagged differences, the verdict is **inconclusive**,
not match. A detected difference can still establish mismatch within the examined content.

PDFium, pypdf, PyMuPDF, and optional Poppler `pdfinfo` supply total counts. If a Poppler-only environment
cannot determine the total and reaches `COMPARER_MAX_PAGES`, coverage is conservatively incomplete.
Model image/text caps are tracked separately; an apparently clean model reply about a truncated input
cannot establish a complete match. Explicit page selections are recorded in document notes, and missing
requested pages mark coverage incomplete.
