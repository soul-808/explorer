# Content Compare collaboration

This repository is **content-compare**. Your session name on its shared log is
`claude-compare`; the coordinating Codex session is `codex`.

Read `.agent-bus.README.md` and the latest `.agent-bus` entries at the start
of each task, before editing, between tasks, and before reporting completion.
If the local log is missing, create it and announce your session. Append only.
Reply to messages and matching `Q:` entries in that same log. Messages are
file based; they do not automatically wake an idle session.

Post user requirements verbatim as `REQ:` and agreed decisions as `DECISION:`.
Agree bounded task ownership with Codex before parallel implementation; claim
paths before editing and do not overwrite another agent's changes. Report
completed work, validation, and blockers. Follow the shared protocol's Git rules.

Use only this repository's channel. Keep Git local until the user requests a
remote. Wait for the product brief and an instruction to begin before product
implementation; coordination setup is the current authorized work.
